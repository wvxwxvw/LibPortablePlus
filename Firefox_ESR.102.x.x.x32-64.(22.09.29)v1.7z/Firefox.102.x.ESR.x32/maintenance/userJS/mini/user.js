/******
* Нумерация, если есть, соответствует arkenfox user.js
*    date: 18 July 2022
* version: 102
*     url: https://github.com/arkenfox/user.js
* license: MIT: https://github.com/arkenfox/user.js/blob/master/LICENSE.txt

       Подсказка:
       при необходимости измените параметр,
       или закомментируйте его и сбросьте в about:config.

******/

// START: internal custom pref to test for syntax errors
user_pref("_user.js.parrot", "ФИАСКО! user.js загружен не полностью, из-за синтаксической ошибки в нем.");

/* 0000: disable about:config warning
 * отключить предупреждение при входе в about:config ***/
user_pref("browser.aboutConfig.showWarning", false);

/*** [SECTION 0100]: STARTUP ***/
/* 0101: Не проверять является ли Firefox браузером по умолчанию (так же см. секцию ДРУГОЕ)
 * [SETTING] General>Startup>Always check if Firefox is your default browser ***/
user_pref("browser.shell.checkDefaultBrowser", false);
/* 0102: что открывать при запуске [SETUP-CHROME]
 * 0=blank, 1=home, 2=last visited page, 3=resume previous session
 * [NOTE] Восстановление сессий очищается с историей (2810) и не используется в PB
 * [SETTING] General>Startup>Restore previous session
 * [CHECK] (см. также 2813) ***/
   // user_pref("browser.startup.page", 0); // кнопка
/* 0104: set NEWTAB page
 * true=Activity Stream (default, see 0105), false=blank page
 * [SETTING] Home>New Windows and Tabs>New tabs
 * [CHECK] ***/
   // user_pref("browser.newtabpage.enabled", false);
user_pref("browser.newtab.preload", false);
/* 0105: disable some Activity Stream items
 * Домашняя страница / новая вкладка по умолчанию, анализирует ваше поведение
 * Идеальное решение - не использовать и не открывать ее.
 * [SETTING] Начало > Домашняя страница Firefox >...
 * [ПРИМ] Для новой вкладки можно использовать альтернативы советуемые Mozilla
 * https://addons.mozilla.org/ru/firefox/addon/tabliss/
 * https://addons.mozilla.org/ru/firefox/addon/new-tab-override/
 * (см. поиском Домашняя страница) ***/
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry", false);
user_pref("browser.newtabpage.activity-stream.feeds.snippets", false); // [DEFAULT: false]
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false); // [FF66+]
user_pref("browser.newtabpage.activity-stream.showSponsoredTopSites", false); // [FF83+]
/* 0106: clear default topsites
 * [NOTE] Это не мешает вам добавлять свои собственные ***/
user_pref("browser.newtabpage.activity-stream.default.sites", "");

/*** [SECTION 0300]: QUIETER FOX ***/
/** RECOMMENDATIONS ***/
/* 0320: disable recommendation pane in about:addons (uses Google Analytics) ***/
user_pref("extensions.getAddons.showPane", false); // [HIDDEN PREF]
/* 0321: disable recommendations in about:addons' Extensions and Themes panes [FF68+] ***/
user_pref("extensions.htmlaboutaddons.recommendations.enabled", false);
/* 0322: disable personalized Extension Recommendations in about:addons and AMO [FF65+]
 * [NOTE] не действует если Health Reports (0331) отключен
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to make personalized extension recommendations
 * [1] https://support.mozilla.org/kb/personalized-extension-recommendations ***/
user_pref("browser.discovery.enabled", false);

/** TELEMETRY ***/
/* 0330: disable new data submission [FF41+]
 * If disabled, no policy is shown or upload takes place, ever
 * [1] https://bugzilla.mozilla.org/1195552 ***/
user_pref("datareporting.policy.dataSubmissionEnabled", false);
/* 0331: disable Health Reports
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send technical... data ***/
user_pref("datareporting.healthreport.uploadEnabled", false);
/* 0332: disable telemetry
 * Параметр "unified" влияет на поведение параметра "enabled"
 * - Если "unified" false, то "enabled" управляет телеметрическим модулем.
 * - Если "unified" true, то "enabled только контролирует, следует ли
 * [NOTE] "toolkit.telemetry.enabled" is now LOCKED to reflect prerelease (true) or release builds (false) ***/
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.enabled", false); // see [NOTE]
user_pref("toolkit.telemetry.server", "data:,");
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.updatePing.enabled", false); // [FF56+]
user_pref("toolkit.telemetry.bhrPing.enabled", false); // [FF57+] Background Hang Reporter
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false); // [FF57+]
user_pref("toolkit.telemetry.cachedClientID", "");
/* 0333: disable Telemetry Coverage
 * [1] https://blog.mozilla.org/data/2018/08/20/effectively-measuring-search-in-firefox/ ***/
user_pref("toolkit.telemetry.coverage.opt-out", true); // [HIDDEN PREF]
user_pref("toolkit.coverage.opt-out", true); // [FF64+] [HIDDEN PREF]
user_pref("toolkit.coverage.endpoint.base", "");
/* 0334: disable PingCentre telemetry (used in several System Add-ons) [FF57+]
 * Defense-in-depth: currently covered by 0331 ***/
user_pref("browser.ping-centre.telemetry", false);

/** STUDIES ***/
/* 0340: disable Studies
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to install and run studies ***/
user_pref("app.shield.optoutstudies.enabled", false);
/* 0341: disable Normandy/Shield [FF60+]
 * Shield is a telemetry system that can push and test "recipes"
 * [ПРИМ] Эти префы не действует, если 0340 отключен ***/
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.api_url", "");

/** CRASH REPORTS ***/
/* 0350: disable Crash Reports ***/
user_pref("breakpad.reportURL", "");
user_pref("browser.tabs.crashReporting.sendReport", false); // [FF44+]
   // user_pref("browser.crashReports.unsubmittedCheck.enabled", false); // [FF51+] [DEFAULT: false]
/* 0351: enforce no submission of backlogged Crash Reports [FF58+]
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send backlogged crash reports  ***/
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false); // [DEFAULT: false]

/** OTHER ***/
/* 0360: disable Captive Portal detection
 * [1] https://www.eff.org/deeplinks/2017/08/how-captive-portals-interfere-wireless-security-and-privacy ***/
user_pref("captivedetect.canonicalURL", "");
user_pref("network.captive-portal-service.enabled", false); // [FF52+]
/* 0361: disable Network Connectivity checks [FF65+]
 * [1] https://bugzilla.mozilla.org/1460537 ***/
user_pref("network.connectivity-service.enabled", false);

/*** [SECTION 0400]: SAFE BROWSING (SB)
   "Safe Browsing делает много шагов для сохранения вашей конфиденциальности..."
   И т.д. и т.п. ... Fx 89 - Зашел на GitHub скачать Sabdboxie, а он меня не пустил.
   На GitHub!!! Потом правда пустил, но мне такая опека не нужна.
   Защиту от фишинга оставил.

   [1] https://feeding.cloud.geek.nz/posts/how-safe-browsing-works-in-firefox/
   [2] https://wiki.mozilla.org/Security/Safe_Browsing
   [3] https://support.mozilla.org/kb/how-does-phishing-and-malware-protection-work
***/
/* 0401: disable SB (Safe Browsing)
 * Это главные переключатели.
 * [SETTING] Privacy & Security>Security>... "Block dangerous and deceptive content" ***/
user_pref("browser.safebrowsing.malware.enabled", false);
user_pref("browser.safebrowsing.phishing.enabled", true);
/* 0402: disable SB checks for downloads (both local lookups + remote)
 * Это главный переключатель для параметров safebrowsing.downloads* (0403, 0404)
 * [SETTING] Privacy & Security>Security>... "Block dangerous downloads" ***/
user_pref("browser.safebrowsing.downloads.enabled", false);
/* 0403: disable SB checks for downloads (remote)
 * Чтобы проверить безопасность некоторых исполняемых файлов, Firefox отправляет
 * некоторую информацию о файле и его происхождении в службу Google Safe Browsing.
 * Служба Safe Browsing, которая помогает Firefox определить, следует ли блокировать файл.
 * [SETUP-SECURITY] Если вам нужна эта защита, то переопределите эти параметры ***/
user_pref("browser.safebrowsing.downloads.remote.enabled", false);
user_pref("browser.safebrowsing.downloads.remote.url", ""); // Defense-in-depth
/* 0404: disable SB checks for unwanted software
 * [SETTING] Privacy & Security>Security>... "Warn you about unwanted and uncommon software" ***/
user_pref("browser.safebrowsing.downloads.remote.block_potentially_unwanted", false);
user_pref("browser.safebrowsing.downloads.remote.block_uncommon", false);

/*** [SECTION 0600]: BLOCK IMPLICIT OUTBOUND [not explicitly asked for - e.g. clicked on] ***/
user_pref("_user.js.parrot", "0600 syntax error: BLOCK IMPLICIT OUTBOUND!");
/* 0601: disable link prefetching
 * [1] https://developer.mozilla.org/docs/Web/HTTP/Link_prefetching_FAQ ***/
user_pref("network.prefetch-next", false);
/* 0602: disable DNS prefetching
 * [1] https://developer.mozilla.org/docs/Web/HTTP/Headers/X-DNS-Prefetch-Control ***/
user_pref("network.dns.disablePrefetch", true);
   // user_pref("network.dns.disablePrefetchFromHTTPS", true); // [DEFAULT: true]
// 0603: disable predictor / prefetching
user_pref("network.predictor.enabled", false);
user_pref("network.predictor.enable-prefetch", false); // [FF48+] [DEFAULT: false]
/* 0604: disable link-mouseover opening connection to linked server
 * [1] https://news.slashdot.org/story/15/08/14/2321202/how-to-quash-firefoxs-silent-requests ***/
user_pref("network.http.speculative-parallel-limit", 0);
// 0605: disable mousedown speculative connections on bookmarks and history [FF98+]
user_pref("browser.places.speculativeConnect.enabled", false);
/* 0610: enforce no "Hyperlink Auditing" (click tracking)
 * [1] https://www.bleepingcomputer.com/news/software/major-browsers-to-prevent-disabling-of-click-tracking-privacy-risk/ ***/
user_pref("browser.send_pings", false); // [DEFAULT: false]

/*** [SECTION 0700]: DNS / DoH / PROXY / SOCKS / IPv6 ***/
/* 0701: disable IPv6
 * По IPv6 могут утекать MAC-адреса (и IP по VPN), если IPv6 вообще поддерживается
 * цепочкой роутер-провайдер-сайт, большинство сайтов возвращаются на IPv4
 * [STATS] по данным телеметрии Firefox за июль 2021, только ~10% подключений
 * используют IPv6
 * [NOTE] Это просто запасной вариант на уровне приложения. Отключать IPv6 надо
 * в ОС/сети и/или правильно настроить VPN. Если вы не маскируете IP - это не
 * имеет большого значения, если маскируете - то это для вас.
 * [NOTE] PHP defaults to IPv6 with "localhost". Use "php -S 127.0.0.1:PORT"
 * [TEST] https://ipleak.org/
 * [1] https://www.internetsociety.org/tag/ipv6-security/ (Myths 2,4,5,6) ***/
user_pref("network.dns.disableIPv6", true);
/* 0702: set the proxy server to do any DNS lookups when using SOCKS
 * При использовании SOCKS проксировать DNS-запросы
 * [1] https://trac.torproject.org/projects/tor/wiki/doc/TorifyHOWTO/WebBrowsers ***/
user_pref("network.proxy.socks_remote_dns", true);
/* 0704: disable GIO as a potential proxy bypass vector
 * Gvfs/GIO has a set of supported protocols like obex, network, archive, computer,
 * dav, cdda, gphoto2, trash, etc. By default only sftp is accepted (FF87+)
 * [1] https://bugzilla.mozilla.org/1433507
 * [2] https://en.wikipedia.org/wiki/GVfs
 * [3] https://en.wikipedia.org/wiki/GIO_(software) ***/
user_pref("network.gio.supported-protocols", ""); // [HIDDEN PREF]
/* 0705: disable proxy direct failover for system requests [FF91+]
 * [WARNING] Default true is a security feature against malicious extensions [1]
 * [SETUP-CHROME] If you use a proxy and you trust your extensions
 * [1] https://blog.mozilla.org/security/2021/10/25/securing-the-proxy-api-for-firefox-add-ons/ ***/
user_pref("network.proxy.failover_direct", false);
/* 0710: disable DNS-over-HTTPS (DoH) rollout [FF60+]
 * Основной переключатель DoH
 * 0 = отключить по умолчанию, 2 = TRR (Trusted Recursive Resolver) первым,
 * 3 = только TRR, 5 = отключить явно
 * [ПРИМ] Также смотрите 1212
 * тест - https://dnsleaktest.com/
 * [CHECK]-all ***/
   // user_pref("network.trr.mode", 3); // кнопка
// 0705a: Текущий DoH провайдер
   // user_pref("network.trr.uri", "https://firefox.dns.nextdns.io/"); // кнопка
/* 0705b: Учитывать или нет исключения системного HOSTS-файла при DoH соединениях
 * false - игнорировать, true - учитывать.
 * [ПРИМ] Для действительно переносного браузера предпочтительнее - false ***/
   // user_pref("network.trr.exclude-etc-hosts", false); // кнопка

/*** [SECTION 0800]: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS ***/
/* 0802: disable location bar domain guessing
 * Отключить угадывание домена (www, .com и т.п.)
 * Приводит к ошибкам переходов, лишним подключениям и утечке данных ***/
user_pref("browser.fixup.alternate.enabled", false);
/* 0805: отключить спекулятивные соединения строки адреса [FF56+]
 * [1] https://bugzilla.mozilla.org/1348275 ***/
user_pref("browser.urlbar.speculativeConnect.enabled", false);
/* 0806: отключить утечку отдельных слов из адресной строки на DNS "после поиска" [FF78+]
 * 0=never resolve single words, 1=heuristic (default), 2=always resolve
 * [1] https://bugzilla.mozilla.org/1642623 ***/
user_pref("browser.urlbar.dnsResolveSingleWordsAfterSearch", 0);
/* 0807: disable location bar contextual suggestions [FF92+]
 * [SETTING] Privacy & Security>Address Bar>Suggestions from...
 * [1] https://blog.mozilla.org/data/2021/09/15/data-and-firefox-suggest/ ***/
   // user_pref("browser.urlbar.suggest.quicksuggest.nonsponsored", false); // [FF95+] !!!
user_pref("browser.urlbar.suggest.quicksuggest.sponsored", false);


/*** [SECTION 1000]: DISK AVOIDANCE ***/
/* 1001: disable disk cache
 * [SETUP-CHROME] Дисковый кэш не нужен в портативке, а на SSD еще и вреден.
 * [NOTE] Смотрите также (2811) ***/
user_pref("browser.cache.disk.enable", false);
/* 1003: disable storing extra session data [SETUP-CHROME]
 * Сохранять ли доп. данные в сессии: содержимое форм, cookie и данные POST
 * 0=everywhere, 1=unencrypted sites, 2=nowhere
 * [CHECK]***/
   // user_pref("browser.sessionstore.privacy_level", 2); // кнопка
/* 1005: disable automatic Firefox start and session restore after reboot [FF62+] [WINDOWS]
 * отключить автозапуск Firefox и восстановление сеанса после перезагрузки системы
 * [1] https://bugzilla.mozilla.org/603903 ***/
user_pref("toolkit.winRegisterApplicationRestart", false);

/*** [SECTION 1400]: FONTS ***/
/* 1402: limit font visibility (Windows, Mac, some Linux) [FF94+]
 * Uses hardcoded lists with two parts: kBaseFonts + kLangPackFonts [1], bundled fonts are auto-allowed
 * In normal windows: uses the first applicable: RFP (4506) over TP over Standard
 * In Private Browsing windows: uses the most restrictive between normal and private
 * 1=only base system fonts, 2=also fonts from optional language packs, 3=also user-installed fonts
 * Ограничить видимость ваших шрифтов
 * [CHECK]-all ***/
user_pref("layout.css.font-visibility.private", 1);
user_pref("layout.css.font-visibility.standard", 1);
   // user_pref("layout.css.font-visibility.trackingprotection", 1); // кнопка

/*** [SECTION 1600]: HEADERS / REFERERS
                  full URI: https://example.com:8888/foo/bar.html?id=1234
     scheme+host+port+path: https://example.com:8888/foo/bar.html
          scheme+host+port: https://example.com:8888
   [1] https://feeding.cloud.geek.nz/posts/tweaking-referrer-for-privacy-in-firefox/
***/
/* 1601: CROSS-ORIGIN: когда отправлять реферер
 * 0=always (default), 1=only if base domains match, 2=only if hosts match
 * [SETUP-WEB] [ПРИМ] Если =2, то вызывает проблемы со старыми модемами/роутерами
 * и некоторыми сайтами (vimeo, icloud, instagram ...), пробуйте =1, или
 * переопределите на 0 и используйте Smart Referer (строгий режим + исключения),
 * только белый список отключите. Толерантный режим в Smart Referer аналогичен =1 здесь.
 * [CHECK] ***/
   // user_pref("network.http.referer.XOriginPolicy", 1); // кнопка
/* 1602: CROSS-ORIGIN: объем отправляемой информации [FF52+]
 * 0=send full URI (default), 1=scheme+host+port+path, 2=scheme+host+port
 * [CHECK] ***/
   // user_pref("network.http.referer.XOriginTrimmingPolicy", 2); // кнопка
/*** [SECTION 2000]: PLUGINS / MEDIA / WEBRTC ***/
/* 2001: disable WebRTC (Web Real-Time Communication)
 * [SETUP-WEB] WebRTC сливает налево ваш реальный IP-адрес под VPN и прокси на Windows7/8.
 * false - cломает возможность общения в режиме реального времени,
 * что для нас не страшно, так как кодек все равно удален и отключен.
 * [SETUP-HARDEN] Test first. Windows7/8 users only: behind a proxy who never use WebRTC
 * [TEST] https://browserleaks.com/webrtc ***/
user_pref("media.peerconnection.enabled", false);
/* 2002: force WebRTC inside the proxy [FF70+] ***/
user_pref("media.peerconnection.ice.proxy_only_if_behind_proxy", true);
/* 2003: force a single network interface for ICE candidates generation [FF42+]
 * When using a system-wide proxy, it uses the proxy interface
 * [TEST] https://browserleaks.com/webrtc ***/
user_pref("media.peerconnection.ice.default_address_only", true);
/* 2004: force exclusion of private IPs from ICE candidates [FF51+]
 * [SETUP-HARDEN] Это защитит ваш IP даже в ДОВЕРЕННЫХ сценариях после предоставления
 * доступа к устройству, но часто приводит к сбоям на платформах видеоконференцсвязи. ***/
user_pref("media.peerconnection.ice.no_host", true);

/*** GMP, CDM, DRM
   Все эти модули бесполезно занимают место в профиле ***/
/* 2020: disable GMP (Gecko Media Plugins)
 * [1] https://wiki.mozilla.org/GeckoMediaPlugins
 * Кодек для просмотра защищенного контента ***/
user_pref("media.gmp-provider.enabled", false);
// Не скачивать кодек и скрыть его в about:addons
   // user_pref("media.gmp-gmpopenh264.enabled", false); // есть в политиках
user_pref("media.gmp-gmpopenh264.visible", false);
/* 2021: disable widevine CDM (Content Decryption Module)
 * Не скачивать модуль и скрыть его в about:addons
 * Расшифровщик защищенного контента ***/
   // user_pref("media.gmp-widevinecdm.enabled", false); // есть в политиках
user_pref("media.gmp-widevinecdm.visible", false);

/* 2022: отключить весь контент DRM (EME: Encryption Media Extension)
 * Optionally hide the setting which also disables the DRM prompt
 * [SETUP-WEB] e.g. Netflix, Amazon Prime, Hulu, HBO, Disney+, Showtime, Starz, DirectTV
 * [SETTING] General>DRM Content>Play DRM-controlled content
 * [TEST] https://bitmovin.com/demos/drm
 * [1] https://www.eff.org/deeplinks/2017/10/drms-dead-canary-how-we-just-lost-web-what-we-learned-it-and-what-we-need-do-next ***/
user_pref("media.eme.enabled", false);
user_pref("browser.eme.ui.enabled", false);
/*** [SECTION 2400]: DOM (DOCUMENT OBJECT MODEL) ***/
/* 2403: блокировать всплывающие окна
 * [SETTING] Privacy & Security>Permissions>Block pop-up windows ***/
   // user_pref("dom.disable_open_during_load", true); // кнопка
// 2404: ограничить события, вызывающие всплывающие окна [SETUP-WEB]
   // user_pref("dom.popup_allowed_events", "click dblclick mousedown pointerdown"); // кнопка

/*** [SECTION 2600]: MISCELLANEOUS ***/
/* 2602: disable sending additional analytics to web servers
 * [1] https://developer.mozilla.org/docs/Web/API/Navigator/sendBeacon ***/
user_pref("beacon.enabled", false);
/* 2603: remove temp files opened with an external application
 * [1] https://bugzilla.mozilla.org/302433 ***/
user_pref("browser.helperApps.deleteTempFileOnExit", true);
// 2604: отключить создание thumbnail в папке профиля ***/
user_pref("browser.pagethumbnails.capturing_disabled", true); // [HIDDEN PREF]
// 2606: disable UITour backend so there is no chance that a remote page can use it
user_pref("browser.uitour.enabled", false);
user_pref("browser.uitour.url", "");
/* 2616: удалить специальные разрешения для определенных доменов Mozilla [FF35+]
 * [1] resource://app/defaults/permissions ***/
user_pref("permissions.manager.defaultsUrl", "");
// 2617: удалить белый список веб-каналов
user_pref("webchannel.allowObject.urlWhitelist", "");
/* 2662: disable webextension restrictions on certain mozilla domains (требуется 4503) [FF60+]
 * отключить ограничения webextension для определенных доменов Mozilla ***/
user_pref("extensions.webextensions.restrictedDomains", "");

/** SANITIZE ON SHUTDOWN : ALL OR NOTHING ***/
/* 2810: enable Firefox to clear items on shutdown (2811)
 * Включить очистку при завершении работы Firefox (2811)
 * [SETTING] Privacy & Security>History>Custom Settings>Clear history when Firefox closes
 * [CHECK] ***/
   // user_pref("privacy.sanitize.sanitizeOnShutdown", true); // кнопка
/* 2811: set/enforce what items to clear on shutdown (if 2810 is true) [SETUP-CHROME]
 * Элементы для очистки при завершении работы (если 2810 = true) [SETUP-CHROME]
 * These items do not use exceptions, it is all or nothing (1681701)
 * [NOTE] Если "history" - true, загрузки также будут очищены
 * [NOTE] "sessions": Active Logins: относится к HTTP Basic Authentication [1], а не логинам с помощью cookie
 * [NOTE] "offlineApps": Offline Website Data: localStorage, service worker cache, QuotaManager (IndexedDB, asm-cache)
 * [SETTING] Privacy & Security>History>Custom Settings>Clear history when Firefox closes>Settings
 * [1] https://en.wikipedia.org/wiki/Basic_access_authentication
 * [CHECK]-all (отключается в кнопке, еще см. 2810) ***/
user_pref("privacy.clearOnShutdown.cache", true);               // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.downloads", true);           // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.formdata", true);            // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.history", true);             // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.sessions", true);            // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.offlineApps", true);         // [DEFAULT: false]
user_pref("privacy.clearOnShutdown.cookies", true);             // [DEFAULT: true]
   // user_pref("privacy.clearOnShutdown.siteSettings", false); // [DEFAULT: false] масшиаб, разрешения...
/** SANITIZE MANUAL: ALL OR NOTHING ***/
/* 2812: reset default items to clear with Ctrl-Shift-Del (to match 2811) [SETUP-CHROME]
/* Сброс элементов при очистке по Ctrl-Shift-Del
 * Firefox помнит последний выбор, это будет возвращать указанные значения при каждом запуске.
 * [NOTE] Если 'history' - true, загрузки также будут очищены
 * [CHECK]-all, кроме паролей, загрузок и настроек сайтов ***/
user_pref("privacy.cpd.cache", true);                  // [DEFAULT: true]
user_pref("privacy.cpd.formdata", true);               // [DEFAULT: true]
user_pref("privacy.cpd.history", true);                // [DEFAULT: true]
user_pref("privacy.cpd.sessions", true);               // [DEFAULT: true]  Active Logins
user_pref("privacy.cpd.offlineApps", true);            // [DEFAULT: false]
user_pref("privacy.cpd.cookies", true);                // [DEFAULT: true]  Maybe Logins
user_pref("privacy.cpd.downloads", true);              // [DEFAULT: true]
   // user_pref("privacy.cpd.passwords", false);       // [DEFAULT: false] Not listed
   // user_pref("privacy.cpd.siteSettings", false);    // [DEFAULT: false]
/* 2813: clear Session Restore data when sanitizing on shutdown or manually [FF34+]
 * [SETUP-CHROME] Очистка данных восстановления сеанса при закрытии и при очистке через диалог
 * [NOTE] Не требуется, если восстановление сеанса не используется (0102) или уже очищено с историей (2811)
 * [NOTE] privacy.clearOnShutdown.openWindows предотвращает возобновление после сбоя (см. также 5008)
 * [NOTE] privacy.cpd.openWindows имеет ошибку, из-за которой открывается дополнительное окно
 * [CHECK] ***/
user_pref("privacy.clearOnShutdown.openWindows", true);
   // user_pref("privacy.cpd.openWindows", true);
/* 2814: сброс "диапазона времени очистки" в "очистить недавнюю историю" (2804)
 * Это будет возвращать указанное значение при каждом запуске.
 * 0=everything, 1=last hour, 2=last two hours, 3=last four hours, 4=today
 * [NOTE] Значения 5 (последние 5 минут) и 6 (последние 24 часа) не указаны в
 * выпадающем списке, и не гарантируется, что они будут работать ***/
user_pref("privacy.sanitize.timeSpan", 0);

/*** [SECTION 4500]: RFP (RESIST FINGERPRINTING)
   RFP охватывает широкий спектр текущих решений по снятию fingerprint.
   Это покупка по принципу "все или ничего": вы не можете выбирать, какие части вам нужны

   [WARNING] НЕ используйте расширения для изменения уже защищенных здесь метрик RFP

   [ПРИМ] Активация этого "нечто" сделает браузер непригодным для использования.
   Все это в той или иной степени, и без ущерба юзабельности, решается с помощью
   специальных расширений типа CanvasBlocker или Canvas Defender.

   Так что основной преф RPF отключен в этой версии документа, часть удалена,
   а другие оставлены совсем не с целью защиты от снятия fingerprint.
***/
/* 4501: enable privacy.resistFingerprinting [FF41+]
 * Основной переключатель.
 * [SETUP-WEB] RFP can cause some website breakage: mainly canvas, use a site exception via the urlbar
 * RFP also has a few side effects: mainly timezone is UTC0, and websites will prefer light theme
 * [1] https://bugzilla.mozilla.org/418986 ***/
user_pref("privacy.resistFingerprinting", false);
/* 4503: disable mozAddonManager Web API [FF57+]
 * [NOTE] На FF60+ cовместно с (2662) заставит работать расширения на AMO и т.п.
 * привилегированных страницах (например, переводчики). В итоге кнопка установки
 * на AMO всегда бедет в состоянии "Установить...". ***/
user_pref("privacy.resistFingerprinting.block_mozAddonManager", true); // [HIDDEN PREF]
/*** [SECTION 5000]: OPTIONAL OPSEC
   Disk avoidance, application data isolation, eyeballs...
***/
/* 5002: disable memory cache
 * [ПРИМ] Есть смысл отключать при малом объеме памяти и быстром интернете: false и 0 соответственно.
 * capacity: -1=determine dynamically (default), 0=none, n=memory capacity in kibibytes ***/
user_pref("browser.cache.memory.enable", true);
user_pref("browser.cache.memory.capacity", -1);

/*** [SECTION 5500]: OPTIONAL HARDENING
   Эти настройки потенциально могут вызвать поломки и проблемы с производительностью,
   в основном их отключение можно обнаружить с fingerpint, а модель угроз незначительна.
***/
/* 5504: disable asm.js [FF22+]
 * [1] http://asmjs.org/
 * [2] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=asm.js
 * [3] https://rh0dev.github.io/blog/2017/the-return-of-the-jit/
 * [CHECK] ***/
   // user_pref("javascript.options.asmjs", false); // кнопка
/* 5506: disable WebAssembly [FF52+]
 * Все чаще обнаруживаются уязвимости [1], в том числе известные и исправленные [2].
 * WASM обладает мощным низкоуровневым доступом, что делает некоторые атаки (brute-force)
 * и уязвимости более возможными
 * [STATS] Исп. ~0,2% сайтов, половина из которых для крипто-майнинга и вредоносной рекламы [2][3]
 * [ПРИМ] Ломает некоторые сайты, например https://bin.snopyta.org/ , но пока только он и попался.
 * [1] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=wasm
 * [2] https://spectrum.ieee.org/tech-talk/telecom/security/more-worries-over-the-security-of-web-assembly
 * [3] https://www.zdnet.com/article/half-of-the-websites-using-webassembly-use-it-for-malicious-purposes
 * [CHECK] ***/
   // user_pref("javascript.options.wasm", false); // кнопка

/*** [SECTION 6000]: DON'T TOUCH ***/
/* 6008: enforce no First Party Isolation [FF51+]
 * [WARNING] Заменено разделением сети (FF85+) и TCP (2701), включение FPI отключает их.
 * FPI больше не поддерживается ***/
user_pref("privacy.firstparty.isolate", false); // [DEFAULT: false]
/* 6011: enforce disabling of Web Compatibility Reporter [FF56+]
 * Web Compatibility Reporter adds a "Report Site Issue" button to send data to Mozilla
 * [WHY] To prevent wasting Mozilla's time with a custom setup ***/
user_pref("extensions.webcompat-reporter.enabled", false); // [DEFAULT: false]
/* 6050: prefsCleaner: reset items removed from arkenfox FF92+ ***/
   // user_pref("dom.caches.enabled", ""); // кнопка
// Защита window.opener
user_pref("dom.targetBlankNoOpener.enabled", "true");
// FPI больше не поддерживается
user_pref("privacy.firstparty.isolate.block_post_message", "false"); // сброс
// Убрать надпись "Не защищено" из адресной строки ***/
user_pref("security.insecure_connection_text.enabled", false); // сброс

/*** [SECTION 7000]: DON'T BOTHER ***/
/* 7010: disable HTTP Alternative Services [FF37+]
 * [WHY] Already isolated with network partitioning (FF85+)
 * Предотвращает возможность внешнего сканирования портов доступных вам ресурсов.
 * Изолирован с (privacy.partition.network_state) (FF85 +) или если FPI enabled (4000) ***/
   // user_pref("network.http.altsvc.enabled", false);
   // user_pref("network.http.altsvc.oe", false);
/* 7014: disable System Add-on updates
 * [WHY] It can compromise security. System addons ship with prefs, use those 
 * [ПРИМ] Лишнее для данной сборки ***/
user_pref("extensions.systemAddon.update.enabled", false); // [FF62+]
user_pref("extensions.systemAddon.update.url", ""); // [FF44+]
/* 7015: enable the DNT (Do Not Track) HTTP header
 * [WHY] DNT и так используется в ETP Strict (2701), но у нас ETP может быть и Custom ***/
user_pref("privacy.donottrackheader.enabled", true);
/* 7016: customize ETP settings
 * [WHY] Arkenfox only supports strict (2701)
 * [ПРИМ] Ну а мы поддерживаем custom (2701), с 1 или 5 здесь + очистка в (2811 и 2812),
 * для большинства случаев 1 проблем не доставляет, а в кнопке есть переключение блокировки/изоляции.
 * 0 = Принимать куки и данные сайта,
 * 1 = Блокировать все сторонние куки,
 * 2 = Блокировать все куки,
 * 3 = Блокировать куки с не посещенных сайтов,
 * 4 = Блокировать межсайтовые отслеживающие куки (default FF69+)
 * 5 = Блокировать межсайтовые отслеживающие куки, а другие изолировать (TCP)
 * [NOTE] В разрешениях для сайта можно установить исключения или использовать расширение
 * [NOTE] Категория "custom" гарантирует соблюдение префов Enhanced Tracking Protection
 * [SETTING] Privacy & Security>Enhanced Tracking Protection>Custom>Cookies
 * [1] https://blog.mozilla.org/security/2021/02/23/total-cookie-protection/
 * [CHECK] ***/
   // user_pref("network.cookie.cookieBehavior", 5); // кнопка
user_pref("network.http.referer.disallowCrossSiteRelaxingDefault", true);
user_pref("network.http.referer.disallowCrossSiteRelaxingDefault.top_navigation", true); // [FF100+]
user_pref("privacy.partition.network_state.ocsp_cache", true);
user_pref("privacy.query_stripping.enabled", true); // [FF101+] [ETP FF102+]
user_pref("privacy.trackingprotection.enabled", true);
user_pref("privacy.trackingprotection.socialtracking.enabled", true);
user_pref("privacy.trackingprotection.cryptomining.enabled", true); // [DEFAULT: true]
user_pref("privacy.trackingprotection.fingerprinting.enabled", true); // [DEFAULT: true]
/* 7017: disable service workers
 * [WHY] Уже изолирован (FF96+) с TCP (2701) за префом (2710)
 * или заблокирован с FPI в 3rd parties (FF95-)
 * Service workers по сути действуют как прокси между веб-приложениями,
 * браузером и сетью, управляются и сами управляют веб-страницами с которыми
 * связаны, перехватывая и изменяя запросы, и кэшируя ресурсы.
 * [NOTE] Работают только по HTTPS, не имеют доступа к DOM, не работают в PB.
 * [SETUP-WEB] Отключение service workers приведет к поломке редких сайтов.
 * При включении требуется true в (7018), (7019) и (dom.caches.enabled=true, см. 6050 или в кнопке)
 * [CHECK] ***/
   // user_pref("dom.serviceWorkers.enabled", false); // кнопка
/* 7018: disable Web Notifications
 * [WHY] Web Notifications находятся в (7002)
 * Могут использоваться service workers ***/
   // user_pref("dom.webnotifications.enabled", false); // [FF22+]
   // user_pref("dom.webnotifications.serviceworker.enabled", false); // [FF44+]
/* 7019: disable Push Notifications [FF44+]
 * Push - это API, который позволяет веб-сайтам отправлять вам (подписанные) сообщения, даже
 * когда сайт не загружен, путем отправки сообщений на ваш userAgentID через Push-сервер Mozilla.
 * [NOTE] Push требует, чтобы service workers (7017) подписывались и отображались, и включенных
 * desktop-notification (7002).
 * Само по себе отключение service workers не мешает Firefox опрашивать Mozilla Push Server.
 * Чтобы подписки запоминались, закомментируйте userAgentID и перезапустите Fx.
 * [1] https://support.mozilla.org/kb/push-notifications-firefox
 * [CHECK] ***/
   // user_pref("dom.push.enabled", false); // кнопка
   // user_pref("dom.push.userAgentID", ""); // если раскомментирован, подписки будут работать только до выхода

/*** [SECTION 9000]: PERSONAL
   Не связанные с проектом настройки, которые могут оказаться полезными.
***/
/* WELCOME & WHAT'S NEW NOTICES ***/
user_pref("browser.startup.homepage_override.mstone", "ignore"); // master switch
user_pref("startup.homepage_welcome_url", "");
user_pref("startup.homepage_welcome_url.additional", "");
user_pref("startup.homepage_override_url", ""); // What's New page after updates
/* UPDATES ***/
user_pref("browser.search.update", false); // disable search engine updates (e.g. OpenSearch)
      // [NOTE] Это не влияет на встроенные поисковые системы Mozilla или поисковые системы веб-расширений
user_pref("extensions.update.enabled", false); // disable extension and theme update checks
user_pref("extensions.update.autoUpdateDefault", false); // disable installing extension and theme updates
      // [SETTING] about:addons>Extensions>[cog-wheel-icon]>Update Add-ons Automatically (toggle)
// Отключить анимацию chrome - 0=нет, 1=да
   // user_pref("ui.prefersReducedMotion", 1); // кнопка [HIDDEN PREF]
/* UX FEATURES ***/
// Отключить и скрыть значки и меню
user_pref("browser.messaging-system.whatsNewPanel.enabled", false); // What's New toolbar icon [FF69+]
user_pref("extensions.pocket.enabled", false); // Pocket Account [FF46+]
   // user_pref("extensions.screenshots.disabled", true); // [FF55+] [CHECK]
user_pref("identity.fxaccounts.enabled", false); // Firefox Accounts & Sync [FF60+] [RESTART]
   // user_pref("reader.parse-on-load.enabled", false); // Reader View
/* OTHER ***/
user_pref("browser.bookmarks.max_backups", 2);
user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.addons", false); // disable CFR [FF67+]
      // [SETTING] General>Browsing>Recommend extensions as you browse
user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.features", false); // disable CFR [FF67+]

/*************************  ДРУГОЕ ********************************************/

// Параметры до сих пор существуют, отключаем на всякий
user_pref("app.update.BITS.enabled", false);
user_pref("app.update.checkInstallTime", false);
user_pref("app.update.service.enabled", false);
user_pref("app.update.staging.enabled", false);

// Не проверять является ли Firefox браузером по умолчанию при первом запуске
user_pref("browser.shell.didSkipDefaultBrowserCheckOnFirstRun", true);


/* Разделение сети (кэша) (TCP: Total Cookie Protection) замена FPI (Fx100+) ***/
   // user_pref("privacy.partition.network_state", true); // кнопка [DEFAULT: true]
// Отключить небезопасный активный контент на https страницах
   // user_pref("security.mixed_content.block_active_content", true); // кнопка [DEFAULT: true FF60+]
// Блокировать небезопасные (HTTP) загрузки на HTTPS страницах
   // user_pref("dom.block_download_insecure", false); // кнопка [DEFAULT: true]

/*** Внешний вид и поведение ***/

// Разрешить стили userChrome/userContent [FF68+]
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true); // [FF68+] (APPEARANCE)

/*** Домашняя страница (см. еще 0100) ***/

// Не показывать логотип поисковика
   // user_pref("browser.newtabpage.activity-stream.logowordmark.alwaysVisible", false);
/* При вводе в строке поиска не переключать фокус на адресную строку и
 * не дублировать поисковые предложения в ней ***/
user_pref("browser.newtabpage.activity-stream.improvesearch.handoffToAwesomebar", false);
// ID оттиска или впечатления (хз что это, домашней странице ID не нужен)
user_pref("browser.newtabpage.activity-stream.impressionId", "");

/* Темная тема панелей ***/
   // user_pref("browser.theme.toolbar-theme", 0); // [DEFAULT: 1] должно изменяться автоматически
// Тема контента (темная = 0, светлая = 1, авто = 2)
   // user_pref("browser.theme.content-theme", 2); // [DEFAULT: 2] может изменяться автоматически
/* Тема контента, та что в настройках
 * 0=темная, 1=Светлая, 2=системная, 3=Firefox
   // user_pref("layout.css.prefers-color-scheme.content-override", 0);

/*** Инструменты разработчика ***/

// темная тема
   // user_pref("devtools.theme", "dark");

/*** Оптимизация ***/

/* Сеть в отдельном процессе - оптимизирует начальную загрузку
 * тяжелых сайтов и глюки соединения ***/
user_pref("network.process.enabled", true); // [DEFAULT: true]

/* END: internal custom pref to test for syntax errors ***/
user_pref("_user.js.parrot", "УСПЕХ: user.js полностью загружен.");
