/******
* Нумерация, если есть, соответствует arkenfox user.js
*    date: 18 July 2022
* version: 102
*     url: https://github.com/arkenfox/user.js
* license: MIT: https://github.com/arkenfox/user.js/blob/master/LICENSE.txt

       Подсказка:
       Ищите и читайте теги "[SETUP]",
       при необходимости измените параметр,
       или закомментируйте его и сбросьте в about:config.

       Вот основные теги:
       [SETUP-SECURITY] это один пункт, прочтите его
            [SETUP-WEB] может привести к поломке некоторых сайтов
         [SETUP-CHROME] изменяет поведение самого Firefox (не веб-сайта)
                 [ПРИМ] мои примечания
                [CHECK] параметры которые у меня раскомментированы

* INDEX:

  0100: STARTUP
  0200: GEOLOCATION / LANGUAGE / LOCALE
  0300: QUIETER FOX
  0400: SAFE BROWSING
  0600: BLOCK IMPLICIT OUTBOUND
  0700: DNS / DoH / PROXY / SOCKS / IPv6
  0800: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS
  0900: PASSWORDS
  1000: DISK AVOIDANCE
  1200: HTTPS (SSL/TLS / OCSP / CERTS / HPKP)
  1400: FONTS
  1600: HEADERS / REFERERS
  1700: CONTAINERS
  2000: PLUGINS / MEDIA / WEBRTC
  2400: DOM (DOCUMENT OBJECT MODEL)
  2600: MISCELLANEOUS
  2700: ETP (ENHANCED TRACKING PROTECTION)
  2800: SHUTDOWN & SANITIZING
  4500: RFP (RESIST FINGERPRINTING)
  5000: OPTIONAL OPSEC
  5500: OPTIONAL HARDENING
  6000: DON'T TOUCH
  7000: DON'T BOTHER
  8000: DON'T BOTHER: FINGERPRINTING
  9000: PERSONAL
  9999: DEPRECATED / REMOVED / LEGACY / RENAMED
  ДРУГОЕ: Всякие полезные настройки

******/

// START: internal custom pref to test for syntax errors
user_pref("_user.js.parrot", "ФИАСКО! user.js загружен не полностью, из-за синтаксической ошибки в нем.");

/* 0000: disable about:config warning
 * отключить предупреждение при входе в about:config ***/
user_pref("browser.aboutConfig.showWarning", false);

/*** [SECTION 0100]: STARTUP ***/
user_pref("_user.js.parrot", "0100 syntax error: STARTUP!");
/* 0101: Не проверять является ли Firefox браузером по умолчанию (так же см. секцию ДРУГОЕ)
 * [SETTING] General>Startup>Always check if Firefox is your default browser ***/
user_pref("browser.shell.checkDefaultBrowser", false);
/* 0102: что открывать при запуске [SETUP-CHROME]
 * 0=blank, 1=home, 2=last visited page, 3=resume previous session
 * [NOTE] Восстановление сессий очищается с историей (2810) и не используется в PB
 * [SETTING] General>Startup>Restore previous session
 * [CHECK] (см. также 2813) ***/
   // user_pref("browser.startup.page", 0); // кнопка
/* 0103: set HOME+NEWWINDOW page
 * about:home=Activity Stream (default, see 0105), custom URL, about:blank
 * [SETTING] Home>New Windows and Tabs>Homepage and new windows ***/
   // user_pref("browser.startup.homepage", "about:blank");
/* 0104: set NEWTAB page
 * true=Activity Stream (default, see 0105), false=blank page
 * [SETTING] Home>New Windows and Tabs>New tabs
 * [CHECK] ***/
   // user_pref("browser.newtabpage.enabled", false);
user_pref("browser.newtab.preload", false);
/* 0105: disable some Activity Stream items
 * Домашняя страница / новая вкладка по умолчанию, анализирует ваше поведение
 * Идеальное решение - не использовать и не открывать ее.
 * [SETTING] Начало > Домашняя страница Firefox >...
 * [ПРИМ] Для новой вкладки можно использовать альтернативы советуемые Mozilla
 * https://addons.mozilla.org/ru/firefox/addon/tabliss/
 * https://addons.mozilla.org/ru/firefox/addon/new-tab-override/
 * (см. поиском Домашняя страница) ***/
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry", false);
user_pref("browser.newtabpage.activity-stream.feeds.snippets", false); // [DEFAULT: false]
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false); // [FF66+]
user_pref("browser.newtabpage.activity-stream.showSponsoredTopSites", false); // [FF83+]
/* 0106: clear default topsites
 * [NOTE] Это не мешает вам добавлять свои собственные ***/
user_pref("browser.newtabpage.activity-stream.default.sites", "");

/*** [SECTION 0200]: GEOLOCATION / LANGUAGE / LOCALE ***/
user_pref("_user.js.parrot", "0200 syntax error: GEOLOCATION / LANGUAGE / LOCALE!");
/* 0201: использовать сервис геолокации Mozilla вместо Google, если разрешение предоставлено [FF74+]
 * При желании включите запись в консоль, второй преф (defaults to false) ***/
user_pref("geo.provider.network.url", "https://location.services.mozilla.com/v1/geolocate?key=%MOZILLA_API_KEY%");
   // user_pref("geo.provider.network.logging.enabled", true); // [HIDDEN PREF]
// 0202: отключить использование сервиса геолокации ОС
user_pref("geo.provider.ms-windows-location", false); // [WINDOWS]
user_pref("geo.provider.use_corelocation", false); // [MAC]
user_pref("geo.provider.use_gpsd", false); // [LINUX]
/* 0203: disable region updates
 * [ПРИМ] это не мешает яндексу угадывать город нахождения ***/
user_pref("browser.region.network.url", ""); // [FF78+]
user_pref("browser.region.update.enabled", false); // [[FF79+]
/* 0204: set search region
 * [NOTE] Может быть не скрыт, если Firefox изменил настройки вашего региона (0203) ***/
   // user_pref("browser.search.region", "US"); // [HIDDEN PREF] // кнопка
/* 0210: язык для отображения веб-страниц
 * [SETTING] General>Language and Appearance>Language>Choose your preferred language...
 * [TEST] https://addons.mozilla.org/about ***/
   // user_pref("intl.accept_languages", "en-US, en"); // кнопка
/* 0211: применять US English независимо от языка системы
 * [SETUP-WEB] Может нарушить некоторые методы ввода
 * [TEST] https://arkenfox.github.io/TZP/tests/formatting.html ***/
   // user_pref("javascript.use_us_english_locale", true); // [HIDDEN PREF] // кнопка

/*** [SECTION 0300]: QUIETER FOX ***/
user_pref("_user.js.parrot", "0300 syntax error: QUIETER FOX!");
/** RECOMMENDATIONS ***/
/* 0320: disable recommendation pane in about:addons (uses Google Analytics) ***/
user_pref("extensions.getAddons.showPane", false); // [HIDDEN PREF]
/* 0321: disable recommendations in about:addons' Extensions and Themes panes [FF68+] ***/
user_pref("extensions.htmlaboutaddons.recommendations.enabled", false);
/* 0322: disable personalized Extension Recommendations in about:addons and AMO [FF65+]
 * [NOTE] не действует если Health Reports (0331) отключен
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to make personalized extension recommendations
 * [1] https://support.mozilla.org/kb/personalized-extension-recommendations ***/
user_pref("browser.discovery.enabled", false);

/** TELEMETRY ***/
/* 0330: disable new data submission [FF41+]
 * If disabled, no policy is shown or upload takes place, ever
 * [1] https://bugzilla.mozilla.org/1195552 ***/
user_pref("datareporting.policy.dataSubmissionEnabled", false);
/* 0331: disable Health Reports
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send technical... data ***/
user_pref("datareporting.healthreport.uploadEnabled", false);
/* 0332: disable telemetry
 * Параметр "unified" влияет на поведение параметра "enabled"
 * - Если "unified" false, то "enabled" управляет телеметрическим модулем.
 * - Если "unified" true, то "enabled только контролирует, следует ли
 * [NOTE] "toolkit.telemetry.enabled" is now LOCKED to reflect prerelease (true) or release builds (false) ***/
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.enabled", false); // see [NOTE]
user_pref("toolkit.telemetry.server", "data:,");
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.updatePing.enabled", false); // [FF56+]
user_pref("toolkit.telemetry.bhrPing.enabled", false); // [FF57+] Background Hang Reporter
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false); // [FF57+]
user_pref("toolkit.telemetry.cachedClientID", "");
/* 0333: disable Telemetry Coverage
 * [1] https://blog.mozilla.org/data/2018/08/20/effectively-measuring-search-in-firefox/ ***/
user_pref("toolkit.telemetry.coverage.opt-out", true); // [HIDDEN PREF]
user_pref("toolkit.coverage.opt-out", true); // [FF64+] [HIDDEN PREF]
user_pref("toolkit.coverage.endpoint.base", "");
/* 0334: disable PingCentre telemetry (used in several System Add-ons) [FF57+]
 * Defense-in-depth: currently covered by 0331 ***/
user_pref("browser.ping-centre.telemetry", false);

/** STUDIES ***/
/* 0340: disable Studies
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to install and run studies ***/
user_pref("app.shield.optoutstudies.enabled", false);
/* 0341: disable Normandy/Shield [FF60+]
 * Shield is a telemetry system that can push and test "recipes"
 * [ПРИМ] Эти префы не действует, если 0340 отключен ***/
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.api_url", "");

/** CRASH REPORTS ***/
/* 0350: disable Crash Reports ***/
user_pref("breakpad.reportURL", "");
user_pref("browser.tabs.crashReporting.sendReport", false); // [FF44+]
   // user_pref("browser.crashReports.unsubmittedCheck.enabled", false); // [FF51+] [DEFAULT: false]
/* 0351: enforce no submission of backlogged Crash Reports [FF58+]
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send backlogged crash reports  ***/
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false); // [DEFAULT: false]

/** OTHER ***/
/* 0360: disable Captive Portal detection
 * [1] https://www.eff.org/deeplinks/2017/08/how-captive-portals-interfere-wireless-security-and-privacy ***/
user_pref("captivedetect.canonicalURL", "");
user_pref("network.captive-portal-service.enabled", false); // [FF52+]
/* 0361: disable Network Connectivity checks [FF65+]
 * [1] https://bugzilla.mozilla.org/1460537 ***/
user_pref("network.connectivity-service.enabled", false);

/*** [SECTION 0400]: SAFE BROWSING (SB)
   "Safe Browsing делает много шагов для сохранения вашей конфиденциальности..."
   И т.д. и т.п. ... Fx 89 - Зашел на GitHub скачать Sabdboxie, а он меня не пустил.
   На GitHub!!! Потом правда пустил, но мне такая опека не нужна.
   Защиту от фишинга оставил.

   [1] https://feeding.cloud.geek.nz/posts/how-safe-browsing-works-in-firefox/
   [2] https://wiki.mozilla.org/Security/Safe_Browsing
   [3] https://support.mozilla.org/kb/how-does-phishing-and-malware-protection-work
***/
user_pref("_user.js.parrot", "0400 syntax error: SAFE BROWSING (SB)!");
/* 0401: disable SB (Safe Browsing)
 * Это главные переключатели.
 * [SETTING] Privacy & Security>Security>... "Block dangerous and deceptive content" ***/
user_pref("browser.safebrowsing.malware.enabled", false);
user_pref("browser.safebrowsing.phishing.enabled", true);
/* 0402: disable SB checks for downloads (both local lookups + remote)
 * Это главный переключатель для параметров safebrowsing.downloads* (0403, 0404)
 * [SETTING] Privacy & Security>Security>... "Block dangerous downloads" ***/
user_pref("browser.safebrowsing.downloads.enabled", false);
/* 0403: disable SB checks for downloads (remote)
 * Чтобы проверить безопасность некоторых исполняемых файлов, Firefox отправляет
 * некоторую информацию о файле и его происхождении в службу Google Safe Browsing.
 * Служба Safe Browsing, которая помогает Firefox определить, следует ли блокировать файл.
 * [SETUP-SECURITY] Если вам нужна эта защита, то переопределите эти параметры ***/
user_pref("browser.safebrowsing.downloads.remote.enabled", false);
user_pref("browser.safebrowsing.downloads.remote.url", ""); // Defense-in-depth
/* 0404: disable SB checks for unwanted software
 * [SETTING] Privacy & Security>Security>... "Warn you about unwanted and uncommon software" ***/
user_pref("browser.safebrowsing.downloads.remote.block_potentially_unwanted", false);
user_pref("browser.safebrowsing.downloads.remote.block_uncommon", false);
/* 0405: disable "ignore this warning" on SB warnings [FF45+]
 * Запретить переопределение в уведомлениях SB
 * [TEST] see https://github.com/arkenfox/user.js/wiki/Appendix-A-Test-Sites#-mozilla
 * [1] https://bugzilla.mozilla.org/1226490 ***/
   // user_pref("browser.safebrowsing.allowOverride", false);

/*** [SECTION 0600]: BLOCK IMPLICIT OUTBOUND [not explicitly asked for - e.g. clicked on] ***/
user_pref("_user.js.parrot", "0600 syntax error: BLOCK IMPLICIT OUTBOUND!");
/* 0601: disable link prefetching
 * [1] https://developer.mozilla.org/docs/Web/HTTP/Link_prefetching_FAQ ***/
user_pref("network.prefetch-next", false);
/* 0602: disable DNS prefetching
 * [1] https://developer.mozilla.org/docs/Web/HTTP/Headers/X-DNS-Prefetch-Control ***/
user_pref("network.dns.disablePrefetch", true);
   // user_pref("network.dns.disablePrefetchFromHTTPS", true); // [DEFAULT: true]
// 0603: disable predictor / prefetching
user_pref("network.predictor.enabled", false);
user_pref("network.predictor.enable-prefetch", false); // [FF48+] [DEFAULT: false]
/* 0604: disable link-mouseover opening connection to linked server
 * [1] https://news.slashdot.org/story/15/08/14/2321202/how-to-quash-firefoxs-silent-requests ***/
user_pref("network.http.speculative-parallel-limit", 0);
// 0605: disable mousedown speculative connections on bookmarks and history [FF98+]
user_pref("browser.places.speculativeConnect.enabled", false);
/* 0610: enforce no "Hyperlink Auditing" (click tracking)
 * [1] https://www.bleepingcomputer.com/news/software/major-browsers-to-prevent-disabling-of-click-tracking-privacy-risk/ ***/
user_pref("browser.send_pings", false); // [DEFAULT: false]

/*** [SECTION 0700]: DNS / DoH / PROXY / SOCKS / IPv6 ***/
user_pref("_user.js.parrot", "0700 syntax error: DNS / DoH / PROXY / SOCKS / IPv6!");
/* 0701: disable IPv6
 * По IPv6 могут утекать MAC-адреса (и IP по VPN), если IPv6 вообще поддерживается
 * цепочкой роутер-провайдер-сайт, большинство сайтов возвращаются на IPv4
 * [STATS] по данным телеметрии Firefox за июль 2021, только ~10% подключений
 * используют IPv6
 * [NOTE] Это просто запасной вариант на уровне приложения. Отключать IPv6 надо
 * в ОС/сети и/или правильно настроить VPN. Если вы не маскируете IP - это не
 * имеет большого значения, если маскируете - то это для вас.
 * [NOTE] PHP defaults to IPv6 with "localhost". Use "php -S 127.0.0.1:PORT"
 * [TEST] https://ipleak.org/
 * [1] https://www.internetsociety.org/tag/ipv6-security/ (Myths 2,4,5,6) ***/
user_pref("network.dns.disableIPv6", true);
/* 0702: set the proxy server to do any DNS lookups when using SOCKS
 * При использовании SOCKS проксировать DNS-запросы
 * [1] https://trac.torproject.org/projects/tor/wiki/doc/TorifyHOWTO/WebBrowsers ***/
user_pref("network.proxy.socks_remote_dns", true);
/* 0703: disable using UNC (Uniform Naming Convention) paths [FF61+]
 * [SETUP-CHROME] Может сломать расширения с профилями на сетевых ресурсах
 * [1] https://gitlab.torproject.org/tpo/applications/tor-browser/-/issues/26424 ***/
user_pref("network.file.disable_unc_paths", true); // [HIDDEN PREF]
/* 0704: disable GIO as a potential proxy bypass vector
 * Gvfs/GIO has a set of supported protocols like obex, network, archive, computer,
 * dav, cdda, gphoto2, trash, etc. By default only sftp is accepted (FF87+)
 * [1] https://bugzilla.mozilla.org/1433507
 * [2] https://en.wikipedia.org/wiki/GVfs
 * [3] https://en.wikipedia.org/wiki/GIO_(software) ***/
user_pref("network.gio.supported-protocols", ""); // [HIDDEN PREF]
/* 0705: disable proxy direct failover for system requests [FF91+]
 * [WARNING] Default true is a security feature against malicious extensions [1]
 * [SETUP-CHROME] If you use a proxy and you trust your extensions
 * [1] https://blog.mozilla.org/security/2021/10/25/securing-the-proxy-api-for-firefox-add-ons/ ***/
user_pref("network.proxy.failover_direct", false);
/* 0706: disable proxy bypass for system request failures [FF95+]
 * RemoteSettings, UpdateService, Telemetry [1]
 * [WARNING] If false, this will break the fallback for some security features
 * [SETUP-CHROME] If you use a proxy and you understand the security impact
 * [1] https://bugzilla.mozilla.org/buglist.cgi?bug_id=1732792,1733994,1733481 ***/
   // user_pref("network.proxy.allow_bypass", false); // [HIDDEN PREF FF95-96]
/* 0710: disable DNS-over-HTTPS (DoH) rollout [FF60+]
 * Основной переключатель DoH
 * 0 = отключить по умолчанию, 2 = TRR (Trusted Recursive Resolver) первым,
 * 3 = только TRR, 5 = отключить явно
 * [ПРИМ] Также смотрите 1212
 * тест - https://dnsleaktest.com/
 * [CHECK]-all ***/
   // user_pref("network.trr.mode", 3); // кнопка
// 0705a: Текущий DoH провайдер
   // user_pref("network.trr.uri", "https://firefox.dns.nextdns.io/"); // кнопка
/* 0705b: Учитывать или нет исключения системного HOSTS-файла при DoH соединениях
 * false - игнорировать, true - учитывать.
 * [ПРИМ] Для действительно переносного браузера предпочтительнее - false ***/
   // user_pref("network.trr.exclude-etc-hosts", false); // кнопка

/*** [SECTION 0800]: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS ***/
user_pref("_user.js.parrot", "0800 syntax error: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS!");
/* 0801: отключить поиск по enter в адресной строке
 * При вводе или вставке URL он отправляется на сервер поисковика по умолчанию.
 * Examples: "secretplace,com", "secretplace/com", "secretplace com", "secret place.com"
 * [NOTE] Это не влияет на кнопки поиска в выпадающем списке и ключи, настроенные в настройках
 * (например, "d" для DuckDuckGo)
 * [SETUP-CHROME] Если вы не вводите или редко вводите URL-адреса и используете приватный
 * поисковик, то преф возможно вам не нужен
 * [ПРИМ] Ломает поиск одним кликом ***/
   // user_pref("keyword.enabled", false);
/* 0802: disable location bar domain guessing
 * Отключить угадывание домена (www, .com и т.п.)
 * Приводит к ошибкам переходов, лишним подключениям и утечке данных ***/
user_pref("browser.fixup.alternate.enabled", false);
/* 0804: отключить поисковые предложения в строках адреса и поиска
 * [NOTE] Оба должны быть true для живого поиска
 * [SETUP-CHROME] при постоянном использовании приватной поисковой системы, возможно, не актуально
 * [SETTING] Search>Provide search suggestions | Show search suggestions in address bar results
 * [CHECK]-all ***/
   // user_pref("browser.search.suggest.enabled", false);
   // user_pref("browser.urlbar.suggest.searches", false);
/* 0805: отключить спекулятивные соединения строки адреса [FF56+]
 * [1] https://bugzilla.mozilla.org/1348275 ***/
user_pref("browser.urlbar.speculativeConnect.enabled", false);
/* 0806: отключить утечку отдельных слов из адресной строки на DNS "после поиска" [FF78+]
 * 0=never resolve single words, 1=heuristic (default), 2=always resolve
 * [1] https://bugzilla.mozilla.org/1642623 ***/
user_pref("browser.urlbar.dnsResolveSingleWordsAfterSearch", 0);
/* 0807: disable location bar contextual suggestions [FF92+]
 * [SETTING] Privacy & Security>Address Bar>Suggestions from...
 * [1] https://blog.mozilla.org/data/2021/09/15/data-and-firefox-suggest/ ***/
   // user_pref("browser.urlbar.suggest.quicksuggest.nonsponsored", false); // [FF95+] !!!
user_pref("browser.urlbar.suggest.quicksuggest.sponsored", false);
/* 0808: disable tab-to-search [FF85+]
 * Кроме того, вы можете исключить их на основе каждого движка, сняв флажок Options>Search
 * [SETTING] Privacy & Security>Address Bar>When using the address bar, suggest>Search engines ***/
   // user_pref("browser.urlbar.suggest.engines", false);
/* 0810: disable search and form history
 * Отключить историю поиска и форм
 * [SETUP-WEB] автозаполняемые формы могут быть прочитаны третьими лицами
 * [NOTE] Можно просто очищать formdata при выходе (2810)
 * [SETTING] Privacy & Security>History>Custom Settings>Remember search and form history
 * [1] https://blog.mindedsecurity.com/2011/10/autocompleteagain.html
 * [2] https://bugzilla.mozilla.org/381681
 * [CHECK] ***/
   // user_pref("browser.formfill.enable", false);
/* 0811: disable Form Autofill
 * [NOTE] Сохранение данных НЕ безопасно (так как используется текстовый файл JSON)
 * [NOTE] Эвристика контролирует автозаполнение форм без атрибутов @autocomplete
 * [SETTING] Privacy & Security>Forms and Autofill>Autofill addresses
 * [CHECK]-all ***/
user_pref("extensions.formautofill.addresses.enabled", false); // [FF55+]
user_pref("extensions.formautofill.available", "off"); // [FF56+]
user_pref("extensions.formautofill.creditCards.available", false); // [FF57+]
user_pref("extensions.formautofill.creditCards.enabled", false); // [FF56+]
user_pref("extensions.formautofill.heuristics.enabled", false); // [FF55+]
/* 0820: disable coloring of visited links
 * Отключить раскраску посещенных ссылок - CSS утечка истории
 * [SETUP-HARDEN] Массовое быстрое обнюхивание истории было смягчено в 2010 году [1][2].
 * Более дорогие атаки были смягчены в FF77+ [3]. RFP (4501) затрудняет атаки по времени.
 * Но не забывайте очищать историю при закрытии (2811).
 * Соц. инженерия [2#limits][4][5] и целевые атаки по времени все еще работают
 * [1] https://developer.mozilla.org/docs/Web/CSS/Privacy_and_the_:visited_selector
 * [2] https://dbaron.org/mozilla/visited-privacy
 * [3] https://bugzilla.mozilla.org/1632765
 * [4] https://earthlng.github.io/testpages/visited_links.html (see github wiki APPENDIX A on how to use)
 * [5] https://lcamtuf.blogspot.com/2016/08/css-mix-blend-mode-is-bad-for-keeping.html
 * [CHECK] ***/
   // user_pref("layout.css.visited_links_enabled", false);

/*** [SECTION 0900]: PASSWORDS
   [1] https://support.mozilla.org/kb/use-primary-password-protect-stored-logins-and-pas
***/
user_pref("_user.js.parrot", "0900 syntax error: PASSWORDS!");
/* 0903: disable auto-filling username & password form fields
 * Отключить автозаполнение полей имени и пароля
 * [NOTE] Имя и пароль остаются доступны при фокусе в поле ввода
 * [SETTING] Privacy & Security>Logins and Passwords>Autofill logins and passwords
 * [1] https://freedom-to-tinker.com/2017/12/27/no-boundaries-for-user-identities-web-trackers-exploit-browser-login-managers/
 * [2] https://homes.esat.kuleuven.be/~asenol/leaky-forms/ ***/
user_pref("signon.autofillForms", false);
// 0904: отключить захват форм для Менеджера паролей [FF51+]
   // user_pref("signon.formlessCapture.enabled", false);
/* 0905: ограничить (или отключить) диалоги учетных данных HTTP-аутентификации,
 * запускаемые субресурсами [FF41+], усиливает защиту от фишинга учетных данных
 * 0 = не разрешать субресурсам
 * 1 = не разрешать субдресурсам другого происхождения
 * 2 = разрешать субресурсам (default) ***/
user_pref("network.auth.subresource-http-auth-allow", 1);
/* 0906: enforce no automatic authentication on Microsoft sites [FF91+] [WINDOWS 10+]
 * [SETTING] Privacy & Security>Logins and Passwords>Allow Windows single sign-on for...
 * [1] https://support.mozilla.org/kb/windows-sso ***/
user_pref("network.http.windows-sso.enabled", false); // [DEFAULT: false]

/*** [SECTION 1000]: DISK AVOIDANCE ***/
user_pref("_user.js.parrot", "1000 syntax error: DISK AVOIDANCE!");
/* 1001: disable disk cache
 * [SETUP-CHROME] Дисковый кэш не нужен в портативке, а на SSD еще и вреден.
 * [NOTE] Смотрите также (2811) ***/
user_pref("browser.cache.disk.enable", false);
/* 1002: disable media cache from writing to disk in Private Browsing
 * [NOTE] MSE (Media Source Extensions) are already stored in-memory in PB ***/
user_pref("browser.privatebrowsing.forceMediaMemoryCache", true); // [FF75+]
user_pref("media.memory_cache_max_size", 65536);
/* 1003: disable storing extra session data [SETUP-CHROME]
 * Сохранять ли доп. данные в сессии: содержимое форм, cookie и данные POST
 * 0=everywhere, 1=unencrypted sites, 2=nowhere
 * [CHECK] ***/
   // user_pref("browser.sessionstore.privacy_level", 2); // кнопка
/* 1004: минимальный интервал между сохранениями сеанса
 * Увеличение может помочь на старых машинах и уменьшит запись на диск.
 * [SETUP-CHROME] Это может повлиять на запись "недавно закрытых вкладок" -
 * быстро открытая и закрытая вкладка не успеет записаться ***/
   // user_pref("browser.sessionstore.interval", 30000); // [DEFAULT: 15000]
// При простое
   // user_pref("browser.sessionstore.interval.idle", 3600000);
/* 1005: disable automatic Firefox start and session restore after reboot [FF62+] [WINDOWS]
 * отключить автозапуск Firefox и восстановление сеанса после перезагрузки системы
 * [1] https://bugzilla.mozilla.org/603903 ***/
user_pref("toolkit.winRegisterApplicationRestart", false);
/* 1006: disable favicons in shortcuts
 * URL shortcuts use a cached randomly named .ico file which is stored in your
 * profile/shortcutCache directory. The .ico remains after the shortcut is deleted
 * If set to false then the shortcuts use a generic Firefox icon ***/
user_pref("browser.shell.shortcutFavicons", false);

/*** [SECTION 1200]: HTTPS (SSL/TLS / OCSP / CERTS / HPKP)
   Your cipher and other settings can be used in server side fingerprinting
   [TEST] https://www.ssllabs.com/ssltest/viewMyClient.html
   [TEST] https://browserleaks.com/ssl
   [TEST] https://ja3er.com/
   [1] https://www.securityartwork.es/2017/02/02/tls-client-fingerprinting-with-bro/
***/
user_pref("_user.js.parrot", "1200 syntax error: HTTPS (SSL/TLS / OCSP / CERTS / HPKP)!");
/** SSL (Secure Sockets Layer) / TLS (Transport Layer Security) ***/
/* 1201: require safe negotiation
 * Блокирует соединения с серверами, которые не поддерживают RFC 5746 [2], поскольку они
 * потенциально уязвимы для атаки MiTM [3]. Сервер без RFC 5746 может быть защищен от атаки
 * если он отключает повторные переговоры, но проблема в том, что браузер не может этого знать.
 * Установка этого pref в true-единственный способ для браузера гарантировать, что не будет
 * никаких небезопасных повторных переговоров на канале между браузером и сервером.
 * [STATS] SSL Labs (July 2021) reports over 99% of sites have secure renegotiation [4]
 * [1] https://wiki.mozilla.org/Security:Renegotiation
 * [2] https://datatracker.ietf.org/doc/html/rfc5746
 * [3] https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2009-3555
 * [4] https://www.ssllabs.com/ssl-pulse/
 * [CHECK] ***/
   // user_pref("security.ssl.require_safe_negotiation", true); // кнопка
/* 1206: disable TLS1.3 0-RTT (round-trip time) [FF51+]
 * This data is not forward secret, as it is encrypted solely under keys derived using
 * the offered PSK. There are no guarantees of non-replay between connections
 * [1] https://github.com/tlswg/tls13-spec/issues/1001
 * [2] https://www.rfc-editor.org/rfc/rfc9001.html#name-replay-attacks-with-0-rtt
 * [3] https://blog.cloudflare.com/tls-1-3-overview-and-q-and-a/ ***/
user_pref("security.tls.enable_0rtt_data", false);

/** OCSP (Online Certificate Status Protocol)
   [1] https://scotthelme.co.uk/revocation-is-broken/
   [2] https://blog.mozilla.org/security/2013/07/29/ocsp-stapling-in-firefox/
***/
/* 1211: enforce OCSP fetching to confirm current validity of certificates
 * 0=disabled, 1=enabled (default), 2=enabled for EV certificates only
 * OCSP (не сшитый) отправляет информацию о посешенных сайтах в CA (центр сертификации)
 * Это компромисс между безопасностью (проверкой) и конфиденциальностью (утечкой адресов в CA)
 * [NOTE] Этот преф управляет только выборкой OCSP и не влияет на сшивание OCSP
 * [SETTING] Privacy & Security>Security>Certificates>Query OCSP responder servers...
 * [1] https://en.wikipedia.org/wiki/Ocsp ***/
user_pref("security.OCSP.enabled", 1); // [DEFAULT: 1]
/* 1212: set OCSP fetch failures (non-stapled, see 1211) to hard-fail [SETUP-WEB]
 * Когда нет доступа к центру сертификации, Firefox просто продолжает соединение (=soft-fail)
 * Установка этого префа в true заставит Firefox разорвать соединение (=hard-fail)
 * Soft-fail не имеет смысла при сбое связи OCSP: вы не знаете действителен ли сертификат или
 * отозван, или вы атакованы (злонамеренная блокировка серверов OCSP).
 * [1] https://blog.mozilla.org/security/2013/07/29/ocsp-stapling-in-firefox/
 * [2] https://www.imperialviolet.org/2014/04/19/revchecking.html
 * [ПРИМ] Если включен, то возможно именно он мешает префу network.trr.mode=3 ***/
   // user_pref("security.OCSP.require", true);

/** CERTS / HPKP (HTTP Public Key Pinning) ***/
/* 1221: disable Windows 8.1's Microsoft Family Safety cert [FF50+] [WINDOWS]
 * 0=disable detecting Family Safety mode and importing the root
 * 1=only attempt to detect Family Safety mode (don't import the root)
 * 2=detect Family Safety mode and import the root
 * [1] https://gitlab.torproject.org/tpo/applications/tor-browser/-/issues/21686 ***/
user_pref("security.family_safety.mode", 0);
/* 1223: enable strict pinning
 * PKP (Public Key Pinning) 0=disabled 1=allow user MiTM (such as your antivirus), 2=strict
 * [SETUP-WEB] Если у вас антивирус главный, то переключите значение на по умолчанию =1
 * [1] https://gitlab.torproject.org/tpo/applications/tor-browser/-/issues/16206 ***/
user_pref("security.cert_pinning.enforcement_level", 2);
/* 1224: enable CRLite [FF73+]
 * 0 = disabled
 * 1 = consult CRLite but only collect telemetry
 * 2 = consult CRLite and enforce both "Revoked" and "Not Revoked" results
 * 3 = consult CRLite and enforce "Not Revoked" results, but defer to OCSP for "Revoked" (FF99+, default FF100+)
 * [1] https://bugzilla.mozilla.org/buglist.cgi?bug_id=1429800,1670985,1753071
 * [2] https://blog.mozilla.org/security/tag/crlite/ ***/
user_pref("security.remote_settings.crlite_filters.enabled", true);
user_pref("security.pki.crlite_mode", 2);

/** MIXED CONTENT ***/
// 1241: отключить небезопасный пассивный контент (например, изображения) с http на страницах https [SETUP-WEB]
   // user_pref("security.mixed_content.block_display_content", true);
/* 1244: enable HTTPS-Only mode in all windows (включить режим только HTTPS) [FF76+]
 * Если верхний уровень HTTPS, то обновляются и небезопасные субресурсы (тихий сбой).
 * Если "https_only_mode" (all windows) = true, то "https_only_mode_pbm" (private windows only) игнорируется
 * [SETTING] to add site exceptions: Padlock>HTTPS-Only mode>On (after "Continue to HTTP Site")
 * [SETTING] Privacy & Security>HTTPS-Only Mode (and manage exceptions)
 * [TEST] http://example.com [upgrade]
 * [TEST] http://neverssl.com/ [no upgrade]
 * [ПРИМ] Если включаете это, то отключите HTTPS Everywhere, Smart HTTPS и т.п.,
 * иначе включать это смысла нет.
 * [ПРИМ] Если по https сайт недоступен, открывается заглушка с вопросом "перейти на http".
 * Но заглушка появляется где попало, в том числе на https сайтах, так как многие из них
 * используют перенаправление по http, например - https://forum.mozilla-russia.org,
 * после авторизации или при отправке сообщения. ***/
   // user_pref("dom.security.https_only_mode", true); // [FF76+]
   // user_pref("dom.security.https_only_mode_pbm", true); // [FF80+]
// 1245: enable HTTPS-Only mode for local resources [FF77+]
   // user_pref("dom.security.https_only_mode.upgrade_local", true);
/* 1246: disable HTTP background requests [FF82+]
 * При попытке обновления, если сервер не отвечает 3сек. (см. ниже), firefox
 * отправляет HTTP-запрос верхнего уровня без пути, чтобы проверить, поддерживает
 * ли сервер HTTPS или нет. Это делается, чтобы избежать тайм-аута в 90 секунд.
 * [1] https://bugzilla.mozilla.org/buglist.cgi?bug_id=1642387,1660945 ***/
   // user_pref("dom.security.https_only_mode_send_http_background_request", false);
/* [ПРИМ] Время задержки send_http_background_request, если включен 1246.
 * Чем медленнее ваше соединение или сетевой отклик, тем больше нужно ставить ***/
   // user_pref("dom.security.https_only_fire_http_request_background_timer_ms", 3000); // по умолчанию 3 сек.

/** UI (User Interface) ***/
/* 1270: display warning on the padlock for "broken security" (if 1201 is false)
 * предупреждение на "замке" для "сломанной безопасности" (если 1201 = false) ***/
user_pref("security.ssl.treat_unsafe_negotiation_as_broken", true);
/* 1271: диалог "добавить исключение безопасности" для предупреждений SSL
 * 0=do neither 1=pre-populate url 2=pre-populate url + pre-fetch cert (default) ***/
user_pref("browser.ssl_override_behavior", 1);
/* 1272: отображение доп. информации на страницах предупреждений о небезопасном подключении,
 * работает только тогда, когда можно добавить исключение
 * [TEST] https://expired.badssl.com/ ***/
user_pref("browser.xul.error_pages.expert_bad_cert", true);

/*** [SECTION 1400]: FONTS ***/
user_pref("_user.js.parrot", "1400 syntax error: FONTS!");
// 1401: disable rendering of SVG OpenType fonts
user_pref("gfx.font_rendering.opentype_svg.enabled", false);
/* 1402: limit font visibility (Windows, Mac, some Linux) [FF94+]
 * Uses hardcoded lists with two parts: kBaseFonts + kLangPackFonts [1], bundled fonts are auto-allowed
 * In normal windows: uses the first applicable: RFP (4506) over TP over Standard
 * In Private Browsing windows: uses the most restrictive between normal and private
 * 1=only base system fonts, 2=also fonts from optional language packs, 3=also user-installed fonts
 * Ограничить видимость ваших шрифтов
 * [CHECK]-all ***/
user_pref("layout.css.font-visibility.private", 1);
user_pref("layout.css.font-visibility.standard", 1);
   // user_pref("layout.css.font-visibility.trackingprotection", 1); // кнопка

/*** [SECTION 1600]: HEADERS / REFERERS
                  full URI: https://example.com:8888/foo/bar.html?id=1234
     scheme+host+port+path: https://example.com:8888/foo/bar.html
          scheme+host+port: https://example.com:8888
   [1] https://feeding.cloud.geek.nz/posts/tweaking-referrer-for-privacy-in-firefox/
***/
user_pref("_user.js.parrot", "1600 syntax error: HEADERS / REFERERS!");
/* 1601: CROSS-ORIGIN: когда отправлять реферер
 * 0=always (default), 1=only if base domains match, 2=only if hosts match
 * [SETUP-WEB] [ПРИМ] Если =2, то вызывает проблемы со старыми модемами/роутерами
 * и некоторыми сайтами (vimeo, icloud, instagram ...), пробуйте =1, или
 * переопределите на 0 и используйте Smart Referer (строгий режим + исключения),
 * только белый список отключите. Толерантный режим в Smart Referer аналогичен =1 здесь.
 * [CHECK] ***/
   // user_pref("network.http.referer.XOriginPolicy", 1); // кнопка
/* 1602: CROSS-ORIGIN: объем отправляемой информации [FF52+]
 * 0=send full URI (default), 1=scheme+host+port+path, 2=scheme+host+port
 * [CHECK] ***/
   // user_pref("network.http.referer.XOriginTrimmingPolicy", 2); // кнопка

/*** [SECTION 1700]: CONTAINERS
   Посмотрите Temporary Containers [2], если хотите действительно эффективно использовать контейнеры
   [1] https://wiki.mozilla.org/Security/Contextual_Identity_Project/Containers
   [2] https://addons.mozilla.org/firefox/addon/temporary-containers/
   [3] https://medium.com/@stoically/enhance-your-privacy-in-firefox-with-temporary-containers-33925cd6cd21
   [4] https://github.com/stoically/temporary-containers/wiki
***/
user_pref("_user.js.parrot", "1700 syntax error: CONTAINERS!");
/* 1701: enable Container Tabs and its UI setting [FF50+]
 * [SETTING] General>Tabs>Enable Container Tabs
 * https://wiki.mozilla.org/Security/Contextual_Identity_Project/Containers ***/
user_pref("privacy.userContext.enabled", true);
user_pref("privacy.userContext.ui.enabled", true);
/* 1702: set behaviour on "+ Tab" button to display container menu on left click [FF74+]
 * [NOTE] Меню всегда отображается при долгом нажатии ЛКМ или щелчке ПКМ
 * [SETTING] General>Tabs>Enable Container Tabs>Settings>Select a container for each new tab ***/
   // user_pref("privacy.userContext.newTabContainerOnLeftClick.enabled", true);

/*** [SECTION 2000]: PLUGINS / MEDIA / WEBRTC ***/
user_pref("_user.js.parrot", "2000 syntax error: PLUGINS / MEDIA / WEBRTC!");
/* 2001: disable WebRTC (Web Real-Time Communication)
 * [SETUP-WEB] WebRTC сливает налево ваш реальный IP-адрес под VPN и прокси на Windows7/8.
 * false - cломает возможность общения в режиме реального времени,
 * что для нас не страшно, так как кодек все равно удален и отключен.
 * [SETUP-HARDEN] Test first. Windows7/8 users only: behind a proxy who never use WebRTC
 * [TEST] https://browserleaks.com/webrtc ***/
user_pref("media.peerconnection.enabled", false);
/* 2002: force WebRTC inside the proxy [FF70+] ***/
user_pref("media.peerconnection.ice.proxy_only_if_behind_proxy", true);
/* 2003: force a single network interface for ICE candidates generation [FF42+]
 * When using a system-wide proxy, it uses the proxy interface
 * [TEST] https://browserleaks.com/webrtc ***/
user_pref("media.peerconnection.ice.default_address_only", true);
/* 2004: force exclusion of private IPs from ICE candidates [FF51+]
 * [SETUP-HARDEN] Это защитит ваш IP даже в ДОВЕРЕННЫХ сценариях после предоставления
 * доступа к устройству, но часто приводит к сбоям на платформах видеоконференцсвязи. ***/
user_pref("media.peerconnection.ice.no_host", true);

/*** GMP, CDM, DRM
   Все эти модули бесполезно занимают место в профиле ***/
/* 2020: disable GMP (Gecko Media Plugins)
 * [1] https://wiki.mozilla.org/GeckoMediaPlugins
 * Кодек для просмотра защищенного контента ***/
user_pref("media.gmp-provider.enabled", false);
// Не скачивать кодек и скрыть его в about:addons
   // user_pref("media.gmp-gmpopenh264.enabled", false); // есть в политиках
user_pref("media.gmp-gmpopenh264.visible", false);
/* 2021: disable widevine CDM (Content Decryption Module)
 * Не скачивать модуль и скрыть его в about:addons
 * Расшифровщик защищенного контента ***/
   // user_pref("media.gmp-widevinecdm.enabled", false); // есть в политиках
user_pref("media.gmp-widevinecdm.visible", false);

/* 2022: отключить весь контент DRM (EME: Encryption Media Extension)
 * Optionally hide the setting which also disables the DRM prompt
 * [SETUP-WEB] e.g. Netflix, Amazon Prime, Hulu, HBO, Disney+, Showtime, Starz, DirectTV
 * [SETTING] General>DRM Content>Play DRM-controlled content
 * [TEST] https://bitmovin.com/demos/drm
 * [1] https://www.eff.org/deeplinks/2017/10/drms-dead-canary-how-we-just-lost-web-what-we-learned-it-and-what-we-need-do-next ***/
user_pref("media.eme.enabled", false);
user_pref("browser.eme.ui.enabled", false);
/* 2030: disable autoplay of HTML5 media [FF63+]
 * отключить, насколько это возможно, автозапуск мультимедиа HTML5 [FF63+]
 * 0=Allow all, 1=Block non-muted media (default), 5=Block all
 * [NOTE] Исключения можно установить в разрешениях для сайта
 * (Информация о странице [Ctrl+I] >> Разрешения)
 * [SETTING] Privacy & Security>Permissions>Autoplay>Settings>Default for all websites ***/
user_pref("media.autoplay.default", 5);
/* 2031: disable autoplay of HTML5 media if you interacted with the site [FF78+]
 * Отключить автозапуск мультимедиа HTML5 при взаимодействии с сайтом
 * 0=sticky (default), 1=transient, 2=user
 * Firefox's Autoplay Policy Documentation (PDF) is linked below via SUMO
 * [NOTE] If you have trouble with some video sites, then add an exception (2030)
 * [ПРИМ] Автор рекомендует 2, но тогда ломается воспроизведение по клику на некоторых сайтах,
 * а исключения превращают такой сайт в нон-стоп шарманку
 * Если хотите блокировать автовоспроизведения на youtube, то пользуйтесь "Enhancer for YouTube".
 * https://addons.mozilla.org/ru/firefox/addon/enhancer-for-youtube/
 * [CHECK] ***/
   // user_pref("media.autoplay.blocking_policy", 1); // кнопка
/* Дополнительно, если 2031 =1
 * время задержки блокировки автозапуска следующего ролика на странице
 * Для страниц с лентой роликов ***/
user_pref("dom.user_activation.transient.timeout", 1000);

/*** [SECTION 2400]: DOM (DOCUMENT OBJECT MODEL) ***/
user_pref("_user.js.parrot", "2400 syntax error: DOM (DOCUMENT OBJECT MODEL)!");
/* 2401: отключить диалог подтверждения об уходе со страницы
 * Не предотвращает JS утечку события закрытия страницы.
 * [1] https://developer.mozilla.org/docs/Web/Events/beforeunload ***/
user_pref("dom.disable_beforeunload", true);
// 2402: запретить скриптам перемещать и изменять размер ОТКРЫТЫХ окон
user_pref("dom.disable_window_move_resize", true);
/* 2403: блокировать всплывающие окна
 * [SETTING] Privacy & Security>Permissions>Block pop-up windows ***/
   // user_pref("dom.disable_open_during_load", true); // кнопка
// 2404: ограничить события, вызывающие всплывающие окна [SETUP-WEB]
   // user_pref("dom.popup_allowed_events", "click dblclick mousedown pointerdown"); // кнопка

/*** [SECTION 2600]: MISCELLANEOUS ***/
user_pref("_user.js.parrot", "2600 syntax error: MISCELLANEOUS!");
/* 2601: prevent accessibility services from accessing your browser [RESTART]
 * [1] https://support.mozilla.org/kb/accessibility-services
 * Запретить "службам поддержки доступности" доступ к вашему браузеру ***/
user_pref("accessibility.force_disabled", 1);
/* 2602: disable sending additional analytics to web servers
 * [1] https://developer.mozilla.org/docs/Web/API/Navigator/sendBeacon ***/
user_pref("beacon.enabled", false);
/* 2603: remove temp files opened with an external application
 * [1] https://bugzilla.mozilla.org/302433 ***/
user_pref("browser.helperApps.deleteTempFileOnExit", true);
// 2604: отключить создание thumbnail в папке профиля ***/
user_pref("browser.pagethumbnails.capturing_disabled", true); // [HIDDEN PREF]
// 2606: disable UITour backend so there is no chance that a remote page can use it
user_pref("browser.uitour.enabled", false);
user_pref("browser.uitour.url", "");
// 2607: есть в конце документа
// 2608: есть в конце документа
/* 2611: disable middle mouse click opening links from clipboard
 * отключить СКМ для открытия ссылок из буфера обмена ***/
   // user_pref("middlemouse.contentLoadURL", false);
/* 2615: disable websites overriding Firefox's keyboard shortcuts [FF58+]
 * 0 (default) or 1=allow, 2=block
 * [SETTING] to add site exceptions: Ctrl+I>Permissions>Override Keyboard Shortcuts ***/
   // user_pref("permissions.default.shortcuts", 2);
/* 2616: удалить специальные разрешения для определенных доменов Mozilla [FF35+]
 * [1] resource://app/defaults/permissions ***/
user_pref("permissions.manager.defaultsUrl", "");
// 2617: удалить белый список веб-каналов
user_pref("webchannel.allowObject.urlWhitelist", "");
/* 2619: use Punycode in Internationalized Domain Names to eliminate possible spoofing
 * [SETUP-WEB] Нежелательно для не латинского алфавита, стандартные IDN также кодируются punycoded
 * [TEST] https://www.xn--80ak6aa92e.com/ (www.apple.com)
 * [1] https://wiki.mozilla.org/IDN_Display_Algorithm
 * [2] https://en.wikipedia.org/wiki/IDN_homograph_attack
 * [3] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=punycode+firefox
 * [4] https://www.xudongz.com/blog/2017/idn-phishing/ ***/
   // user_pref("network.IDN_show_punycode", true);
/* 2620: enforce PDFJS, disable PDFJS scripting [SETUP-CHROME]
 * Этот параметр определяет, доступность "Просмотреть в Firefox" и определяет,
 * обрабатываются ли PDF-файлы в браузере или внешне ("Спросить" или "Открыть")
 * CAVEAT: JS все еще сможет заставить PDF-файл открываться в браузере
 * [SETTING] General>Applications>Portable Document Format (PDF) ***/
   // user_pref("pdfjs.disabled", false); // [DEFAULT: false]
user_pref("pdfjs.enableScripting", false); // [FF86+]
/* 2621: disable links launching Windows Store on Windows 8/8.1/10 [WINDOWS]
 * отключить запуск ссылок Windows Store на Windows 8/8.1/10 ***/
   // user_pref("network.protocol-handler.external.ms-windows-store", false);
/* 2623: disable permissions delegation [FF73+]
 * В настоящее время применяется к геолокации, разрешениям на камеру, микрофон и общий доступ
 * к экрану,  * а также полноэкранным запросам. Означает, что любые запросы будут
 * показывать/использовать их правильное стороннее происхождение
 * [1] https://groups.google.com/forum/#!topic/mozilla.dev.platform/BdFOMAuCGW8/discussion ***/
user_pref("permissions.delegation.enabled", false);

/** DOWNLOADS ***/
/* 2651: всегда спрашивать, где сохранить
 * [SETUP-CHROME] На Android это блокирует долгое нажатие и сохранение изображений
 * [SETTING] General>Downloads>Always ask you where to save files
 * [ПРИМ] Надо бы раскомментировать для портативки. Но многие ее стационарно используют... ***/
   // user_pref("browser.download.useDownloadDir", false);
// 2652: есть в конце документа
/* 2653: disable adding downloads to the system's "recent documents" list
 * Отключить добавление загрузок в список "последние документы" системы ***/
user_pref("browser.download.manager.addToRecentDocs", false);
/* 2654: enable user interaction for security by always asking how to handle new mimetypes [FF101+]
 * [SETTING] General>Files and Applications>What should Firefox do with other files ***/
user_pref("browser.download.always_ask_before_handling_new_types", true);

/** EXTENSIONS ***/
/* 2660: lock down allowed extension directories
 * [SETUP-CHROME] Это отключит расширения, языковые пакеты, темы и любые другие XPI,
 * установленные вне каталогов профилей и приложения
 * [1] https://mike.kaply.com/2012/02/21/understanding-add-on-scopes/
 * [1] https://archive.is/DYjAM (archived) ***/
user_pref("extensions.enabledScopes", 5); // [HIDDEN PREF]
user_pref("extensions.autoDisableScopes", 15); // [DEFAULT: 15]
/* 2661: disable bypassing 3rd party extension install prompts [FF82+]
 * [1] https://bugzilla.mozilla.org/buglist.cgi?bug_id=1659530,1681331 ***/
user_pref("extensions.postDownloadThirdPartyPrompt", false);
/* 2662: disable webextension restrictions on certain mozilla domains (требуется 4503) [FF60+]
 * отключить ограничения webextension для определенных доменов Mozilla ***/
user_pref("extensions.webextensions.restrictedDomains", "");

/*** [SECTION 2700]: ETP (ENHANCED TRACKING PROTECTION) ***/
user_pref("_user.js.parrot", "2700 syntax error: ETP (ENHANCED TRACKING PROTECTION)!");
/* 2701: enable ETP Strict Mode [FF86+]
 * ETP Strict Mode enables Total Cookie Protection (TCP)
 * [NOTE] Добавление исключений для сайта отключает все средства защиты ETP
 * для этого сайта и увеличивает риск отслеживания состояния между сайтами,
 * т.е., исключения для SiteA и SiteB означает, что PartyC на обоих сайтах общий
 * [ПРИМ] arkenfox советует "strict", но это неудобно, так как придется и для понижения
 * блокировки/изоляции, и для повышения, переключать минимум два параметра.
 * Вполне достаточно "custom" и переключать блокировку/изоляцию одним параметром в кнопке
 * [SETTING] to add site exceptions: Urlbar>ETP Shield
 * [SETTING] to manage site exceptions: Options>Privacy & Security>Enhanced Tracking Protection>Manage Exceptions ***/
user_pref("browser.contentblocking.category", "custom");
/* 2702: disable ETP web compat features [FF93+]
 * [SETUP-HARDEN] Includes skip lists, heuristics (SmartBlock) and automatic grants
 * Opener and redirect heuristics are granted for 30 days, see [3]
 * [1] https://blog.mozilla.org/security/2021/07/13/smartblock-v2/
 * [2] https://hg.mozilla.org/mozilla-central/rev/e5483fd469ab#l4.12
 * [3] https://developer.mozilla.org/en-US/docs/Web/Privacy/State_Partitioning#storage_access_heuristics ***/
   // user_pref("privacy.antitracking.enableWebcompat", false);
/* 2710: enable state partitioning of service workers [FF96+] ***/
user_pref("privacy.partition.serviceWorkers", true);

/*** [SECTION 2800]: SHUTDOWN & SANITIZING ***/
user_pref("_user.js.parrot", "2800 syntax error: SHUTDOWN & SANITIZING!");
/** SANITIZE ON SHUTDOWN: ALLOWS COOKIES + SITE DATA EXCEPTIONS FF102+ ***/
/* 2801: delete cookies and site data on exit
 * Время жизни кук (удалять куки при закрытии)
 * 0=keep until they expire (default), 2=keep until you close Firefox
 * [NOTE] Блокировка "cookie" также контролирует localStorage/sessionStorage, IndexedDB,
 * SharedWorkers и ServiceWorkers. ServiceWorkers require an "Allow" permission.
 * [SETTING] Privacy & Security>Cookies and Site Data>Delete cookies and site data when Firefox is closed
 * [SETTING] to add site exceptions: Ctrl+I>Permissions>Cookies>Allow
 * [SETTING] to manage site exceptions: Options>Privacy & Security>Permissions>Settings
 * [CHECK] ***/
   // user_pref("network.cookie.lifetimePolicy", 2); // кнопка
/* 2802: delete cache on exit [FF96+]
 * [NOTE] Отключение дискового кэша (1001) и очистка при выходе (2811) более надежно
 * [1] https://bugzilla.mozilla.org/1671182 ***/
   // user_pref("privacy.clearsitedata.cache.enabled", true);

/** SANITIZE ON SHUTDOWN : ALL OR NOTHING ***/
/* 2810: enable Firefox to clear items on shutdown (2811)
 * Включить очистку при завершении работы Firefox (2811)
 * [SETTING] Privacy & Security>History>Custom Settings>Clear history when Firefox closes
 * [CHECK] ***/
   // user_pref("privacy.sanitize.sanitizeOnShutdown", true); // кнопка
/* 2811: set/enforce what items to clear on shutdown (if 2810 is true) [SETUP-CHROME]
 * Элементы для очистки при завершении работы (если 2810 = true) [SETUP-CHROME]
 * These items do not use exceptions, it is all or nothing (1681701)
 * [NOTE] Если "history" - true, загрузки также будут очищены
 * [NOTE] "sessions": Active Logins: относится к HTTP Basic Authentication [1], а не логинам с помощью cookie
 * [NOTE] "offlineApps": Offline Website Data: localStorage, service worker cache, QuotaManager (IndexedDB, asm-cache)
 * [SETTING] Privacy & Security>History>Custom Settings>Clear history when Firefox closes>Settings
 * [1] https://en.wikipedia.org/wiki/Basic_access_authentication
 * [CHECK]-all (отключается в кнопке, еще см. 2810) ***/
user_pref("privacy.clearOnShutdown.cache", true);               // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.downloads", true);           // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.formdata", true);            // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.history", true);             // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.sessions", true);            // [DEFAULT: true]
user_pref("privacy.clearOnShutdown.offlineApps", true);         // [DEFAULT: false]
user_pref("privacy.clearOnShutdown.cookies", true);             // [DEFAULT: true]
   // user_pref("privacy.clearOnShutdown.siteSettings", false); // [DEFAULT: false] масшиаб, разрешения...
/** SANITIZE MANUAL: ALL OR NOTHING ***/
/* 2812: reset default items to clear with Ctrl-Shift-Del (to match 2811) [SETUP-CHROME]
 * Сброс элементов при очистке по Ctrl-Shift-Del
 * Firefox помнит последний выбор, это будет возвращать указанные значения при каждом запуске.
 * [NOTE] Если 'history' - true, загрузки также будут очищены
 * [CHECK]-all, кроме паролей, загрузок и настроек сайтов ***/
user_pref("privacy.cpd.cache", true);                  // [DEFAULT: true]
user_pref("privacy.cpd.formdata", true);               // [DEFAULT: true]
user_pref("privacy.cpd.history", true);                // [DEFAULT: true]
user_pref("privacy.cpd.sessions", true);               // [DEFAULT: true]  Active Logins
user_pref("privacy.cpd.offlineApps", true);            // [DEFAULT: false]
user_pref("privacy.cpd.cookies", true);                // [DEFAULT: true]  Maybe Logins
user_pref("privacy.cpd.downloads", true);              // [DEFAULT: true]
   // user_pref("privacy.cpd.passwords", false);       // [DEFAULT: false] Not listed
   // user_pref("privacy.cpd.siteSettings", false);    // [DEFAULT: false]
/* 2813: clear Session Restore data when sanitizing on shutdown or manually [FF34+]
 * [SETUP-CHROME] Очистка данных восстановления сеанса при закрытии и при очистке через диалог
 * [NOTE] Не требуется, если восстановление сеанса не используется (0102) или уже очищено с историей (2811)
 * [NOTE] privacy.clearOnShutdown.openWindows предотвращает возобновление после сбоя (см. также 5008)
 * [NOTE] privacy.cpd.openWindows имеет ошибку, из-за которой открывается дополнительное окно
 * [CHECK] ***/
user_pref("privacy.clearOnShutdown.openWindows", true);
   // user_pref("privacy.cpd.openWindows", true);
/* 2814: сброс "диапазона времени очистки" в "очистить недавнюю историю" (2804)
 * Это будет возвращать указанное значение при каждом запуске.
 * 0=everything, 1=last hour, 2=last two hours, 3=last four hours, 4=today
 * [NOTE] Значения 5 (последние 5 минут) и 6 (последние 24 часа) не указаны в
 * выпадающем списке, и не гарантируется, что они будут работать ***/
user_pref("privacy.sanitize.timeSpan", 0);

/*** [SECTION 4500]: RFP (RESIST FINGERPRINTING)
   RFP охватывает широкий спектр текущих решений по снятию fingerprint.
   Это покупка по принципу "все или ничего": вы не можете выбирать, какие части вам нужны

   [WARNING] НЕ используйте расширения для изменения уже защищенных здесь метрик RFP

   [ПРИМ] Активация этого "нечто" сделает браузер непригодным для использования.
   Все это в той или иной степени, и без ущерба юзабельности, решается с помощью
   специальных расширений типа CanvasBlocker или Canvas Defender.

   Так что основной преф RPF отключен в этой версии документа, часть удалена,
   а другие оставлены совсем не с целью защиты от снятия fingerprint.
***/
user_pref("_user.js.parrot", "4500 syntax error: the parrot's popped 'is clogs");
/* 4501: enable privacy.resistFingerprinting [FF41+]
 * Основной переключатель.
 * [SETUP-WEB] RFP can cause some website breakage: mainly canvas, use a site exception via the urlbar
 * RFP also has a few side effects: mainly timezone is UTC0, and websites will prefer light theme
 * [1] https://bugzilla.mozilla.org/418986 ***/
user_pref("privacy.resistFingerprinting", false);
/* 4502: set new window sizes to round to hundreds [FF55+] [SETUP-CHROME]
 * Открывать \ восстанавливать окна с округлением размера окна.
 * Ширина и высота будет округляться до кратных 200x100.
 * Макс. значения являются отправной точкой для округления значений. ***/
   // user_pref("privacy.window.maxInnerWidth", 1200);
   // user_pref("privacy.window.maxInnerHeight", 900);
/* 4503: disable mozAddonManager Web API [FF57+]
 * [NOTE] На FF60+ cовместно с (2662) заставит работать расширения на AMO и т.п.
 * привилегированных страницах (например, переводчики). В итоге кнопка установки
 * на AMO всегда бедет в состоянии "Установить...". ***/
user_pref("privacy.resistFingerprinting.block_mozAddonManager", true); // [HIDDEN PREF]
/* 4504: enable RFP letterboxing [FF67+]
 * [ПРИМ] Не трогайте это, не занимайтесь мазохизмом. ***/
user_pref("privacy.resistFingerprinting.letterboxing", false); // [HIDDEN PREF]
/* 4510: disable showing about:blank as soon as possible during startup [FF60+]
 * Значение true больше не маскирует изменение размеров chrome. ***/
user_pref("browser.startup.blankWindow", false);
/* 4510: disable using system colors
 * [SETTING] General>Language and Appearance>Fonts and Colors>Colors>Use system colors ***/
user_pref("browser.display.use_system_colors", false); // [DEFAULT false NON-WINDOWS]
/* 4511: enforce non-native widget theme
 * Security: removes/reduces system API calls, e.g. win32k API [1]
 * Fingerprinting: provides a uniform look and feel across platforms [2]
 * [1] https://bugzilla.mozilla.org/1381938
 * [2] https://bugzilla.mozilla.org/1411425 ***/
user_pref("widget.non-native-theme.enabled", true); // [DEFAULT: true]
/* 4512: enforce links targeting new windows to open in a new tab instead
 * 1=most recent window or tab, 2=new window, 3=new tab
 * Открывать ссылки во вкладках, даже если они нацелены на новое окно.
 * Предотвращает некоторые утечки разрешения экрана и размера окна.
 * Вы все еще сможете щелкнуть ПКМ по ссылке и открыть ее в новом окне.
 * [SETTING] General>Tabs>Open links in tabs instead of new windows
 * [TEST] https://arkenfox.github.io/TZP/tzp.html#screen ***/
user_pref("browser.link.open_newwindow", 3); // [DEFAULT: 3]
/* 4513: set all open window methods to abide by "browser.link.open_newwindow" (4512)
 * Установить для всех методов открытия окна соответствие с (4512)
 * [1] https://searchfox.org/mozilla-central/source/dom/tests/browser/browser_test_new_window_from_content.js ***/
user_pref("browser.link.open_newwindow.restriction", 0);
/* 4520: disable WebGL (Web Graphics Library)
 * [SETUP-WEB] Если он вам не нужен, то лучше отключить. Используется, например,
 * на яндекс погоде - на карте ветров. Защитить от снятия отпечатков через WebGL
 * могут расширения CanvasBlocker или Canvas Defender, они подделывают холст. ***/
   // user_pref("webgl.disabled", true); // кнопка

/*** [SECTION 5000]: OPTIONAL OPSEC
   Disk avoidance, application data isolation, eyeballs...
***/
user_pref("_user.js.parrot", "5000 syntax error: OPTIONAL OPSEC!");
/* 5001: start Firefox in PB (Private Browsing) mode
 * [NOTE] В этом режиме все окна приватные, а значок режима PB не отображается
 * [NOTE] Режим PB вводит в заблуждение, он просто отбирает у вас возможность очищать кеш,
 * историю, куки, localStorage и IndexedDB, до перезапуска браузера.
 * Используйте приватное окно когда это необходимо.
 * Чтобы очистить данные приватной сессии просто закройте приватное окно.
 * Все остальное достигается и без PB.
 * [SETTING] Privacy & Security>History>Custom Settings>Always use private browsing mode
 * [1] https://wiki.mozilla.org/Private_Browsing
 * [2] https://support.mozilla.org/kb/common-myths-about-private-browsing ***/
user_pref("browser.privatebrowsing.autostart", false);
/* 5002: disable memory cache
 * [ПРИМ] Есть смысл отключать при малом объеме памяти и быстром интернете: false и 0 соответственно.
 * capacity: -1=determine dynamically (default), 0=none, n=memory capacity in kibibytes ***/
user_pref("browser.cache.memory.enable", true);
user_pref("browser.cache.memory.capacity", -1);
/* 5003: disable saving passwords
 * [NOTE] Это не очищает уже сохраненные пароли
 * [SETTING] Privacy & Security>Logins and Passwords>Ask to save logins and passwords for websites ***/
   // user_pref("signon.rememberSignons", false);
/* 5004: disable permissions manager from writing to disk [FF41+] [RESTART]
 * [NOTE] любые изменения разрешений будут только для текущего сеанса
 * [1] https://bugzilla.mozilla.org/967812 ***/
   // user_pref("permissions.memory_only", true); // [HIDDEN PREF]
/* 5005: disable intermediate certificate caching [FF41+] [RESTART]
 * [NOTE] This affects login/cert/key dbs. The effect is all credentials are session-only.
 * Сохраненные логины и пароли будут недоступны. Сбросьте и перезапустите, чтобы вернуть их. ***/
   // user_pref("security.nocertdb", true); // [HIDDEN PREF]
/* 5006: disable favicons in history and bookmarks
 * [NOTE] Stored as data blobs in favicons.sqlite, these don't reveal anything that your
 * actual history (and bookmarks) already do. Your history is more detailed, so
 * control that instead; e.g. disable history, clear history on close, use PB mode
 * [NOTE] favicons.sqlite очищается от мусора при закрытии Firefox ***/
   // user_pref("browser.chrome.site_icons", false);
// 5007: есть в конце документа
/* 5008: disable resuming session from crash
 * Отключить возобновление сеанса после сбоя ***/
   // user_pref("browser.sessionstore.resume_from_crash", false);
/* 5009: disable "open with" in download dialog [FF50+]
 * [1] https://bugzilla.mozilla.org/1281959 ***/
   // user_pref("browser.download.forbid_open_with", true);
/* 5010: disable location bar suggestion types
 * Типы подсказок в адресной строке
 * [SETTING] Privacy & Security>Address Bar>When using the address bar, suggest ***/
   // user_pref("browser.urlbar.suggest.history", false);
   // user_pref("browser.urlbar.suggest.bookmark", false);
   // user_pref("browser.urlbar.suggest.openpage", false);
user_pref("browser.urlbar.suggest.topsites", false); // [FF78+]
/* 5011: disable location bar dropdown
 * Определяет общее количество записей, отображаемых в раскрывающемся списке ***/
   // user_pref("browser.urlbar.maxRichResults", 0);
/* 5012: disable location bar autofill
 * Отключить автозаполнение строки адреса
 * [CHECK] ***/
user_pref("browser.urlbar.autoFill", false);
/* 5013: disable browsing and download history
 * [NOTE] Можно просто очищать историю при выходе (см. 2811)
 * [SETTING] Privacy & Security>History>Custom Settings>Remember browsing and download history ***/
   // user_pref("places.history.enabled", false);
// 5014: список переходов в панели задач и меню пуск [WINDOWS]
user_pref("browser.taskbar.lists.enabled", false);
user_pref("browser.taskbar.lists.frequent.enabled", false);
user_pref("browser.taskbar.lists.recent.enabled", false);
user_pref("browser.taskbar.lists.tasks.enabled", false);
// 5015: предпросмотр в панели задач [WINDOWS]
   // user_pref("browser.taskbar.previews.enable", false); // [DEFAULT: false]
/* 5016: препятствовать загрузке на рабочий стол
 * 0=desktop, 1=downloads (default), 2=last used
 * [SETTING] To set your default "downloads": General>Downloads>Save files to ***/
   // user_pref("browser.download.folderList", 2);

/*** [SECTION 5500]: OPTIONAL HARDENING
   Эти настройки потенциально могут вызвать поломки и проблемы с производительностью,
   в основном их отключение можно обнаружить с fingerpint, а модель угроз незначительна.
***/
user_pref("_user.js.parrot", "5500 syntax error: OPTIONAL HARDENING!");
/* 5501: disable MathML (Mathematical Markup Language) [FF51+]
 * [1] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=mathml ***/
   // user_pref("mathml.disabled", true); // 1173199
/* 5502: disable in-content SVG (Scalable Vector Graphics) [FF53+]
 * [1] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=firefox+svg ***/
   // user_pref("svg.disabled", true); // 1216893
/* 5503: disable graphite
 * [1] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=firefox+graphite
 * [2] https://en.wikipedia.org/wiki/Graphite_(SIL) ***/
   // user_pref("gfx.font_rendering.graphite.enabled", false);
/* 5504: disable asm.js [FF22+]
 * [1] http://asmjs.org/
 * [2] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=asm.js
 * [3] https://rh0dev.github.io/blog/2017/the-return-of-the-jit/
 * [CHECK] ***/
   // user_pref("javascript.options.asmjs", false); // кнопка
/* 5505: disable Ion and baseline JIT to harden against JS exploits
 * [NOTE] When both Ion and JIT are disabled, and trustedprincipals
 * is enabled, then Ion can still be used by extensions (1599226)
 * [1] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=firefox+jit
 * [2] https://microsoftedge.github.io/edgevr/posts/Super-Duper-Secure-Mode/ ***/
   // user_pref("javascript.options.ion", false);
   // user_pref("javascript.options.baselinejit", false);
   // user_pref("javascript.options.jit_trustedprincipals", true); // [FF75+] [HIDDEN PREF]
/* 5506: disable WebAssembly [FF52+]
 * Все чаще обнаруживаются уязвимости [1], в том числе известные и исправленные [2].
 * WASM обладает мощным низкоуровневым доступом, что делает некоторые атаки (brute-force)
 * и уязвимости более возможными
 * [STATS] Исп. ~0,2% сайтов, половина из которых для крипто-майнинга и вредоносной рекламы [2][3]
 * [ПРИМ] Ломает некоторые сайты, например https://bin.snopyta.org/ , но пока только он и попался.
 * [1] https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword=wasm
 * [2] https://spectrum.ieee.org/tech-talk/telecom/security/more-worries-over-the-security-of-web-assembly
 * [3] https://www.zdnet.com/article/half-of-the-websites-using-webassembly-use-it-for-malicious-purposes
 * [CHECK] ***/
   // user_pref("javascript.options.wasm", false); // кнопка

/*** [SECTION 6000]: DON'T TOUCH ***/
user_pref("_user.js.parrot", "6000 syntax error: DON'T TOUCH!");
/* 6001: enforce Firefox blocklist
 * [WHY] Включает обновления для «отозванных сертификатов»
 * [1] https://blog.mozilla.org/security/2015/03/03/revoking-intermediate-certificates-introducing-onecrl/ ***/
user_pref("extensions.blocklist.enabled", true); // [DEFAULT: true]
/* 6002: enforce no referer spoofing
 * [WHY] Подмена может повлиять на защиту CSRF, сломает некоторую авторизацию и всю межсайтовую авторизацию ***/
user_pref("network.http.referer.spoofSource", false); // [DEFAULT: false]
/* 6004: задержка безопасности на некоторые подтверждения, например, установить, открыть/сохранить
 * [1] https://www.squarefree.com/2004/07/01/race-conditions-in-security-dialogs/ ***/
user_pref("security.dialog_enable_delay", 1000); // [DEFAULT: 1000]
/* 6008: enforce no First Party Isolation [FF51+]
 * [WARNING] Заменено разделением сети (FF85+) и TCP (2701), включение FPI отключает их.
 * FPI больше не поддерживается ***/
user_pref("privacy.firstparty.isolate", false); // [DEFAULT: false]
/* 6009: enforce SmartBlock shims [FF81+]
 * In FF96+ these are listed in about:compat
 * [1] https://blog.mozilla.org/security/2021/03/23/introducing-smartblock/ ***/
user_pref("extensions.webcompat.enable_shims", true); // [DEFAULT: true]
/* 6010: enforce/reset TLS 1.0/1.1 downgrades to session only
 * [NOTE] In FF97+ the TLS 1.0/1.1 downgrade UX was removed
 * [TEST] https://tls-v1-1.badssl.com:1010/ ***/
user_pref("security.tls.version.enable-deprecated", false); // [DEFAULT: false]
/* 6011: enforce disabling of Web Compatibility Reporter [FF56+]
 * Web Compatibility Reporter adds a "Report Site Issue" button to send data to Mozilla
 * [WHY] To prevent wasting Mozilla's time with a custom setup ***/
user_pref("extensions.webcompat-reporter.enabled", false); // [DEFAULT: false]
/* 6012: disable SHA-1 certificates
 * 0 = allow all, 1 = block all
 * 3 = only allow locally-added roots (e.g. anti-virus) (default)
 * 4 = only allow locally-added roots or for certs in 2015 and earlier ***/
   // user_pref("security.pki.sha1_enforcement_level", 1); // [DEFAULT: 1 FF102+]
/* 6050: prefsCleaner: reset items removed from arkenfox FF92+ ***/
// отображать все части URL в адресной строке
   // user_pref("browser.urlbar.trimURLs", "");
   // user_pref("dom.caches.enabled", ""); // кнопка
   // user_pref("dom.storageManager.enabled", "");
   // user_pref("dom.storage_access.enabled", "");
// Защита window.opener
user_pref("dom.targetBlankNoOpener.enabled", "true");
// Устанавливать сторонние cookie (если разрешены в 2701 и 7016) только для сеанса,
user_pref("network.cookie.thirdparty.sessionOnly", true);
user_pref("network.cookie.thirdparty.nonsecureSessionOnly", true);
// FPI больше не поддерживается
user_pref("privacy.firstparty.isolate.block_post_message", "false"); // сброс
// false может уменьшить вероятность поломки для FPI
user_pref("privacy.firstparty.isolate.restrict_opener_access", "true"); // сброс
user_pref("privacy.firstparty.isolate.use_site", "false"); // сброс
// Enforce "window.name" protection
user_pref("privacy.window.name.update.enabled", "true"); // сброс
// Убрать надпись "Не защищено" из адресной строки ***/
user_pref("security.insecure_connection_text.enabled", false); // сброс

/*** [SECTION 7000]: DON'T BOTHER ***/
user_pref("_user.js.parrot", "7000 syntax error: DON'T BOTHER!");
/* 7001: disable APIs
 * Просмотр с учетом Geo, полноэкранный режим, appCache, виртуальная реальность
 * [WHY] Состояние API легко отслеживаются. Разрешения для Geo и VR в (7002).
 * Отдельное хранилище appCache удалено в FF90. Full-screen-api только деактивирует кнопку на видео. ***/
   // user_pref("geo.enabled", false);
   // user_pref("full-screen-api.enabled", false);
   // user_pref("browser.cache.offline.enable", false);
   // user_pref("dom.vr.enabled", false);
/* 7002: разрешения по умолчанию
 * Location, Camera, Microphone, Notifications [FF58+] Virtual Reality [FF73+]
 * 0=always ask (default), 1=allow, 2=block
 * [Прим] Это просто разрешения по умолчанию, не больше.
 * Добавляйте исключения для нужных сайтов, а не разрешайте глобально.
 * [SETTING] добавить исключение: Ctrl+I>Permissions>
 * [SETTING] управление исключениями: Options>Privacy & Security>Permissions>Settings ***/
user_pref("permissions.default.geo", 0);
user_pref("permissions.default.camera", 0);
user_pref("permissions.default.microphone", 0);
   // user_pref("permissions.default.desktop-notification", 0);
user_pref("permissions.default.xr", 0); // Virtual Reality
/* 7003: disable non-modern cipher suites [1]
 * [WHY] Passive fingerprinting. Minimal/non-existent threat of downgrade attacks
 * [1] https://browserleaks.com/ssl ***/
   // user_pref("security.ssl3.ecdhe_ecdsa_aes_256_sha", false);
   // user_pref("security.ssl3.ecdhe_ecdsa_aes_128_sha", false);
   // user_pref("security.ssl3.ecdhe_rsa_aes_128_sha", false);
   // user_pref("security.ssl3.ecdhe_rsa_aes_256_sha", false);
   // user_pref("security.ssl3.rsa_aes_128_gcm_sha256", false); // no PFS
   // user_pref("security.ssl3.rsa_aes_256_gcm_sha384", false); // no PFS
   // user_pref("security.ssl3.rsa_aes_128_sha", false); // no PFS
   // user_pref("security.ssl3.rsa_aes_256_sha", false); // no PFS
/* 7004: control TLS versions
 * 1=TLS 1.0, 2=TLS 1.1, 3=TLS 1.2, 4=TLS 1.3
 * [WHY] Passive fingerprinting and security ***/
   // user_pref("security.tls.version.min", 3); // [DEFAULT: 3]
   // user_pref("security.tls.version.max", 4);
/* 7005: disable SSL session IDs [FF36+]
 * [WHY] Затратно для пассивного fingerprint. Не исп. в PB режиме, только для сеанса,
 * изолированы с (privacy.partition.network_state) (FF85+) и в контейнерах. ***/
   // user_pref("security.ssl.disable_session_identifiers", true); // [HIDDEN PREF in FF101 or lower]
/* 7006: onions
 * [WHY] Firefox doesn't support hidden services. Use Tor Browser ***/
   // user_pref("dom.securecontext.allowlist_onions", true); // [FF97+] 1382359/1744006
   // user_pref("network.http.referer.hideOnionSource", true); // 1305144
/* 7007: referers
 * [WHY] Only cross-origin referers (1600s) need control
 * Про настройку рефереров см. 1600
 * Отправлять реферер изображениям и (или только) ссылкам
 * 0=never, 1=send only when links are clicked, 2=for links and images (default) ***/
   // user_pref("network.http.sendRefererHeader", 2);
/* объем отправляемой информации
 * 0=send full URI (default), 1=scheme+host+port+path, 2=scheme+host+port ***/
   // user_pref("network.http.referer.trimmingPolicy", 0);
/* 7008: set the default Referrer Policy [FF59+]
 * 0=no-referer, 1=same-origin, 2=strict-origin-when-cross-origin, 3=no-referrer-when-downgrade
 * [WHY] Это только значение по умолчанию, оно может быть отменено политикой сайта. ***/
   // user_pref("network.http.referer.defaultPolicy", 2); // [DEFAULT: 2]
   // user_pref("network.http.referer.defaultPolicy.pbmode", 2); // [DEFAULT: 2]
/* 7010: disable HTTP Alternative Services [FF37+]
 * [WHY] Already isolated with network partitioning (FF85+)
 * Предотвращает возможность внешнего сканирования портов доступных вам ресурсов.
 * Изолирован с (privacy.partition.network_state) (FF85 +) или если FPI enabled (4000) ***/
   // user_pref("network.http.altsvc.enabled", false);
   // user_pref("network.http.altsvc.oe", false);
/* 7011: disable website control over browser right-click context menu
 * [WHY] Просто используйте Shift-Right-Click
 * [ПРИМ] Контекстное меню будет вызываться где попало, например в сайдбарах расширений. ***/
   // user_pref("dom.event.contextmenu.enabled", false);
/* 7012: disable icon fonts (glyphs) and local fallback rendering
 * [WHY] Breakage, font fallback is equivalency, also RFP ***/
   // user_pref("gfx.downloadable_fonts.enabled", false); // [FF41+]
   // user_pref("gfx.downloadable_fonts.fallback_delay", -1);
/* 7013: disable Clipboard API
 * Требует взаимодействие с пользователем. События вырезания/копирования/вставки
 * ограничены целевыми текстовыми полями. Отключенное состояние видно при fingerprint ***/
   // user_pref("dom.event.clipboardevents.enabled", false);
/* 7014: disable System Add-on updates
 * [WHY] It can compromise security. System addons ship with prefs, use those 
 * [ПРИМ] Лишнее для данной сборки ***/
user_pref("extensions.systemAddon.update.enabled", false); // [FF62+]
user_pref("extensions.systemAddon.update.url", ""); // [FF44+]
/* 7015: enable the DNT (Do Not Track) HTTP header
 * [WHY] DNT и так используется в ETP Strict (2701), но у нас ETP может быть и Custom ***/
user_pref("privacy.donottrackheader.enabled", true);
/* 7016: customize ETP settings
 * [WHY] Arkenfox only supports strict (2701)
 * [ПРИМ] Ну а мы поддерживаем custom (2701), с 1 или 5 здесь + очистка в (2811 и 2812),
 * для большинства случаев 1 проблем не доставляет, а в кнопке есть переключение блокировки/изоляции.
 * 0 = Принимать куки и данные сайта,
 * 1 = Блокировать все сторонние куки,
 * 2 = Блокировать все куки,
 * 3 = Блокировать куки с не посещенных сайтов,
 * 4 = Блокировать межсайтовые отслеживающие куки (default FF69+)
 * 5 = Блокировать межсайтовые отслеживающие куки, а другие изолировать (TCP)
 * [NOTE] В разрешениях для сайта можно установить исключения или использовать расширение
 * [NOTE] Категория "custom" гарантирует соблюдение префов Enhanced Tracking Protection
 * [SETTING] Privacy & Security>Enhanced Tracking Protection>Custom>Cookies
 * [1] https://blog.mozilla.org/security/2021/02/23/total-cookie-protection/
 * [CHECK] ***/
   // user_pref("network.cookie.cookieBehavior", 5); // кнопка
user_pref("network.http.referer.disallowCrossSiteRelaxingDefault", true);
user_pref("network.http.referer.disallowCrossSiteRelaxingDefault.top_navigation", true); // [FF100+]
user_pref("privacy.partition.network_state.ocsp_cache", true);
user_pref("privacy.query_stripping.enabled", true); // [FF101+] [ETP FF102+]
user_pref("privacy.trackingprotection.enabled", true);
user_pref("privacy.trackingprotection.socialtracking.enabled", true);
user_pref("privacy.trackingprotection.cryptomining.enabled", true); // [DEFAULT: true]
user_pref("privacy.trackingprotection.fingerprinting.enabled", true); // [DEFAULT: true]
/* 7017: disable service workers
 * [WHY] Уже изолирован (FF96+) с TCP (2701) за префом (2710)
 * или заблокирован с FPI в 3rd parties (FF95-)
 * Service workers по сути действуют как прокси между веб-приложениями,
 * браузером и сетью, управляются и сами управляют веб-страницами с которыми
 * связаны, перехватывая и изменяя запросы, и кэшируя ресурсы.
 * [NOTE] Работают только по HTTPS, не имеют доступа к DOM, не работают в PB.
 * [SETUP-WEB] Отключение service workers приведет к поломке редких сайтов.
 * При включении требуется true в (7018), (7019) и (dom.caches.enabled=true, см. 6050 или в кнопке)
 * [CHECK] ***/
   // user_pref("dom.serviceWorkers.enabled", false); // кнопка
/* 7018: disable Web Notifications
 * [WHY] Web Notifications находятся в (7002)
 * Могут использоваться service workers ***/
   // user_pref("dom.webnotifications.enabled", false); // [FF22+]
   // user_pref("dom.webnotifications.serviceworker.enabled", false); // [FF44+]
/* 7019: disable Push Notifications [FF44+]
 * Push - это API, который позволяет веб-сайтам отправлять вам (подписанные) сообщения, даже
 * когда сайт не загружен, путем отправки сообщений на ваш userAgentID через Push-сервер Mozilla.
 * [NOTE] Push требует, чтобы service workers (7017) подписывались и отображались, и включенных
 * desktop-notification (7002).
 * Само по себе отключение service workers не мешает Firefox опрашивать Mozilla Push Server.
 * Чтобы подписки запоминались, закомментируйте userAgentID и перезапустите Fx.
 * [1] https://support.mozilla.org/kb/push-notifications-firefox
 * [CHECK] ***/
   // user_pref("dom.push.enabled", false); // кнопка
   // user_pref("dom.push.userAgentID", ""); // если раскомментирован, подписки будут работать только до выхода

/*** [SECTION 8000]: DON'T BOTHER: FINGERPRINTING
   [WHY] Этого недостаточно для защиты от fingerprint и приносит больше вреда, чем пользы
   [WARNING] DO NOT USE with RFP. RFP already covers these, and they can interfere
***/
user_pref("_user.js.parrot", "8000 syntax error: the parrot's crossed the Jordan");
/* 8001: disable APIs ***/
// disable device Sensor APIs
   // user_pref("device.sensors.enabled", false);
/* disable Navigation Timing API
 * риск утечки данных при использовании proxi\VPN (вроде как неактуально) ***/
   // user_pref("dom.enable_performance", false);
//disable Resource Timing API
   // user_pref("dom.enable_resource_timing", false);
// disable gamepad API to prevent USB device ID enumeration
   // user_pref("dom.gamepad.enabled", false);
// disable Network Information API [FF31+]
   // user_pref("dom.netinfo.enabled", false); // [DEFAULT: false NON-ANDROID: false ANDROID FF99+]
// disable Web Audio API [FF51+]
   // user_pref("dom.webaudio.enabled", false);
/* 8002: disable other ***/
// disable websites choosing fonts (0=block, 1=allow)
   // user_pref("browser.display.use_document_fonts", 0);
// Масштабирование не будет запоминаться для сайтов
   // user_pref("browser.zoom.siteSpecific", false);
// disable touch events: 0=disabled, 1=enabled, 2=autodetect
   // user_pref("dom.w3c_touch_events.enabled", 0);
// disable media device enumeration [FF29+]
   // user_pref("media.navigator.enabled", false);
// disable MediaDevices change detection [FF51+]
   // user_pref("media.ondevicechange.enabled", false);
// disable video statistics to mitigate JS performance fingerprinting [FF25+]
   // user_pref("media.video_stats.enabled", false);
// disable the SpeechSynthesis (Text-to-Speech) part of the Web Speech API
   // user_pref("media.webspeech.synth.enabled", false);
// disable WebGL debug info being available to websites
   // user_pref("webgl.enable-debug-renderer-info", false);
/* 8003: spoof ***/
// spoof number of CPU cores [FF48+]
   // user_pref("dom.maxHardwareConcurrency", 2);
/* limit system font exposure to a whitelist [FF52+] [RESTART]
 * [ПРИМ] Изуродует сайты с шрифтами не из списка. Если список пуст, то разрешены все шрифты ***/
   // user_pref("font.system.whitelist", ""); // [HIDDEN PREF]
// navigator DOM object overrides
   // user_pref("general.appname.override", ""); // [HIDDEN PREF]
   // user_pref("general.appversion.override", ""); // [HIDDEN PREF]
   // user_pref("general.buildID.override", ""); // [HIDDEN PREF]
   // user_pref("general.oscpu.override", ""); // [HIDDEN PREF]
   // user_pref("general.platform.override", ""); // [HIDDEN PREF]
   // user_pref("general.useragent.override", ""); // [HIDDEN PREF]
// disable exposure of system colors to CSS or canvas [FF44+]
   // user_pref("ui.use_standins_for_native_colors", true);

/*** [SECTION 9000]: PERSONAL
   Не связанные с проектом настройки, которые могут оказаться полезными.
***/
user_pref("_user.js.parrot", "9000 syntax error: the parrot's cashed in 'is chips!");
/* WELCOME & WHAT'S NEW NOTICES ***/
user_pref("browser.startup.homepage_override.mstone", "ignore"); // master switch
user_pref("startup.homepage_welcome_url", "");
user_pref("startup.homepage_welcome_url.additional", "");
user_pref("startup.homepage_override_url", ""); // What's New page after updates
/* WARNINGS ***/
user_pref("browser.tabs.warnOnClose", false); // [DEFAULT false FF94+]
user_pref("browser.tabs.warnOnCloseOtherTabs", false);
user_pref("browser.tabs.warnOnOpen", false);
user_pref("browser.warnOnQuitShortcut", false); // [FF94+]
user_pref("full-screen-api.warning.delay", 0);
user_pref("full-screen-api.warning.timeout", 0);
/* UPDATES ***/
   // user_pref("app.update.auto", false); // [NON-WINDOWS] disable auto app updates
      // [NOTE] Вы по-прежнему будете получать запросы на обновление, и вам следует делать это своевременно
      // [SETTING] General>Firefox Updates>Check for updates but let you choose to install them
user_pref("browser.search.update", false); // disable search engine updates (e.g. OpenSearch)
      // [NOTE] Это не влияет на встроенные поисковые системы Mozilla или поисковые системы веб-расширений
user_pref("extensions.update.enabled", false); // disable extension and theme update checks
user_pref("extensions.update.autoUpdateDefault", false); // disable installing extension and theme updates
      // [SETTING] about:addons>Extensions>[cog-wheel-icon]>Update Add-ons Automatically (toggle)
/* При значении false, в about:addons, на вкладке "Подробности" аддона, не будет описания
 * и ссылки на AMO (ссылка на домашнюю страницу останется, если она прописана в аддоне) ***/
   // user_pref("extensions.getAddons.cache.enabled", false); // disable extension metadata (extension detail tab)
/* APPEARANCE ***/
   // user_pref("browser.download.autohideButton", false); // [FF57+]
// Отключить анимацию chrome - 0=нет, 1=да
   // user_pref("ui.prefersReducedMotion", 1); // кнопка [HIDDEN PREF]
   // 1 пункт есть ниже
/* CONTENT BEHAVIOR ***/
   // user_pref("accessibility.typeaheadfind", true); // включить поиск при наборе (поиск на странице)
   // user_pref("clipboard.autocopy", false); // disable autocopy default [LINUX]
   // user_pref("layout.spellcheckDefault", 2); // 0=none, 1-multi-line, 2=multi-line & single-line
/* UX BEHAVIOR ***/
   // user_pref("browser.backspace_action", 2); // 0=previous page, 1=scroll up, 2=do nothing
   // user_pref("browser.quitShortcut.disabled", true); // disable Ctrl-Q quit shortcut [LINUX] [MAC] [FF87+]
   // 3 пункта есть ниже
   // user_pref("general.autoScroll", false); // middle-click enabling auto-scrolling [DEFAULT: false on Linux]
   // user_pref("ui.key.menuAccessKey", 0); // disable alt key toggling the menu bar [RESTART]
user_pref("view_source.tab", true); // открывать "Исходный код страницы" в новой вкладке [FF68+]
/* UX FEATURES ***/
// Отключить и скрыть значки и меню
user_pref("browser.messaging-system.whatsNewPanel.enabled", false); // What's New toolbar icon [FF69+]
user_pref("extensions.pocket.enabled", false); // Pocket Account [FF46+]
   // user_pref("extensions.screenshots.disabled", true); // [FF55+] [CHECK]
user_pref("identity.fxaccounts.enabled", false); // Firefox Accounts & Sync [FF60+] [RESTART]
   // user_pref("reader.parse-on-load.enabled", false); // Reader View
/* OTHER ***/
user_pref("browser.bookmarks.max_backups", 2);
user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.addons", false); // disable CFR [FF67+]
      // [SETTING] General>Browsing>Recommend extensions as you browse
user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.features", false); // disable CFR [FF67+]
      // [SETTING] General>Browsing>Recommend features as you browse
   // user_pref("network.manage-offline-status", false); // see bugzilla 620472
   // user_pref("xpinstall.signatures.required", false); // enforced extension signing (Nightly/ESR)

/*** [SECTION 9999]: DEPRECATED / REMOVED / LEGACY / RENAMED
   Documentation denoted as [-]. Items deprecated prior to FF91 have been archived at [1]
   [1] https://github.com/arkenfox/user.js/issues/123
***/
user_pref("_user.js.parrot", "9999 syntax error: DEPRECATED / REMOVED / LEGACY / RENAMED!");
/* ESR91.x still uses all the following prefs
// [NOTE] replace the * with a slash in the line above to re-enable them
// FF93
// 7003: disable non-modern cipher suites
   // [-] https://bugzilla.mozilla.org/1724072
   // user_pref("security.ssl3.rsa_des_ede3_sha", false); // 3DES
// FF94
// 1402: limit font visibility (Windows, Mac, some Linux) [FF79+] - replaced by new 1402
   // [-] https://bugzilla.mozilla.org/1715507
   // user_pref("layout.css.font-visibility.level", 1);
// FF95
// 0807: disable location bar contextual suggestions [FF92+] - replaced by new 0807
   // [-] https://bugzilla.mozilla.org/1735976
user_pref("browser.urlbar.suggest.quicksuggest", false);
// FF96
// 0302: disable auto-INSTALLING Firefox updates via a background service + hide the setting [FF90+] [WINDOWS]
   // [SETTING] General>Firefox Updates>Automatically install updates>When Firefox is not running
   // [1] https://support.mozilla.org/kb/enable-background-updates-firefox-windows
   // [-] https://bugzilla.mozilla.org/1738983
user_pref("app.update.background.scheduling.enabled", false);
// FF97
// 7006: onions - replaced by new 7006 "allowlist"
   // [-] https://bugzilla.mozilla.org/1744006
   // user_pref("dom.securecontext.whitelist_onions", true); // 1382359
// FF99
// 6003: enforce CSP (Content Security Policy)
   // [1] https://developer.mozilla.org/docs/Web/HTTP/CSP
   // [-] https://bugzilla.mozilla.org/1754301
user_pref("security.csp.enable", true); // [DEFAULT: true]
// FF100
// 7009: disable HTTP2 - replaced by network.http.http2* prefs
   // [WHY] Passive fingerprinting. ~50% of sites use HTTP2 [1]
   // [1] https://w3techs.com/technologies/details/ce-http2/all/all
   // [-] https://bugzilla.mozilla.org/1752621
   // user_pref("network.http.spdy.enabled", false);
   // user_pref("network.http.spdy.enabled.deps", false);
   // user_pref("network.http.spdy.enabled.http2", false);
   // user_pref("network.http.spdy.websockets", false); // [FF65+]
// FF102
   // 0901: как часто Firefox должен запрашивать основной пароль
   // 0=once per session (default), 1=every time it's needed, 2=after n minutes (0902)
   // [-] https://bugzilla.mozilla.org/1767099
   // user_pref("security.ask_for_password", 2);
   // 0902: значение в минутах для (0901)=2
   // [-] https://bugzilla.mozilla.org/1767099
   // user_pref("security.password_lifetime", 5); // [DEFAULT: 30]
/* 6007: enable Local Storage Next Generation (LSNG) [FF65+] 
 * Бесполезный параметр - отключить его можно, только если в config.js
 * добавить - dom.storage.next_gen_auto_enabled_by_cause1=false. Сломав при этом профиль. ***/
   // user_pref("dom.storage.next_gen", true); // [DEFAULT: true FF92+]
/*************************  ДРУГОЕ ********************************************/
user_pref("_user.js.parrot", "Секция ДРУГОЕ syntax error");

// Параметры до сих пор существуют, отключаем на всякий
user_pref("app.update.BITS.enabled", false);
user_pref("app.update.checkInstallTime", false);
user_pref("app.update.service.enabled", false);
user_pref("app.update.staging.enabled", false);

// Не проверять является ли Firefox браузером по умолчанию при первом запуске
user_pref("browser.shell.didSkipDefaultBrowserCheckOnFirstRun", true);

/* Сброс настроек сети (прокси) при перезагрузке браузера
 * Не проксировать = 0, Системные = 5 (по умолчанию), "Авто (proxi.pac) = 2,
 * Прописанные = 1, Автоопределение = 4 ***/
user_pref("network.proxy.type", 5);

/* Язык возвращаемый JS и язык http-заголовков, если =2 то en-US,
 * не работает без RFP, а при включении RFP, Fx предлагает включить и это ***/
   // user_pref("privacy.spoof_english", 2);

/* Разделение сети (кэша) (TCP: Total Cookie Protection) замена FPI (Fx100+) ***/
   // user_pref("privacy.partition.network_state", true); // кнопка [DEFAULT: true]
// Отключить небезопасный активный контент на https страницах
   // user_pref("security.mixed_content.block_active_content", true); // кнопка [DEFAULT: true FF60+]
// Блокировать небезопасные (HTTP) загрузки на HTTPS страницах
   // user_pref("dom.block_download_insecure", false); // кнопка [DEFAULT: true]

/*** Безопасность ***/

/* Подхватывать сертификаты установленные в систему, иначе используются только
 * из внутреннего хранилища Firefox. ***/
   // user_pref("security.enterprise_roots.enabled", true);

/*** Внешний вид и поведение ***/

// Разрешить стили userChrome/userContent [FF68+]
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true); // [FF68+] (APPEARANCE)

// Использовать или нет атрибуты SVG
user_pref("svg.context-properties.content.enabled", true);

/* CSS backdrop-filter. Инфо и демо -
 * https://dev.to/snkds/how-to-enable-backdrop-filter-in-firefox-2n8e ***/
   // user_pref("layout.css.backdrop-filter.enabled", true);

// Включить использование функции css color-mix()
user_pref("layout.css.color-mix.enabled", true);

// Вернуть пункт конт.меню "Информация об изображении"
user_pref("browser.menu.showViewImageInfo", true);

/* Влияет на перетягивание из браузера в проводник и окна других программ
 * запущенных не от администратора ***/
user_pref("browser.launcherProcess.enabled", true); // [HIDDEN PREF]

// Запретить отсоединять нативные вкладки от окна
   // user_pref("browser.tabs.allowTabDetach", false);

// Чинит цвет элементов веб-страниц, при нестандартных темах оформления Windows
   // user_pref("browser.display.document_color_use", 1);

/* Не закрывать меню в панели закладок при открытии закладки по Ctrl+ЛКМ,
 * дает возможность открыть несколько закладок подряд ***/
user_pref("browser.bookmarks.openInTabClosesMenu", false);
// закрывать ли браузер при закрытии последней вкладки
user_pref("browser.tabs.closeWindowWithLastTab", false); // (UX BEHAVIOR)
// открывать ли из строки адреса в новой вкладке
user_pref("browser.urlbar.openintab", true);
// открывать ли поиск в новой вкладке 
user_pref("browser.search.openintab", true);
// открывать ли закладки в новой вкладке
user_pref("browser.tabs.loadBookmarksInTabs", true); // (UX BEHAVIOR)
// открывать ли закладки в фоне
user_pref("browser.tabs.loadBookmarksInBackground", false);

// Выделение нажатой ссылки другим контуром
   // user_pref("browser.display.focus_ring_on_anything", true);

// Зеленый замок в адресной строке для HTTPS без смешанного контента на странице
user_pref("security.secure_connection_icon_color_gray", false);
// Отключить иконку небезопасного соединения в адресной строке, текст отключен в 6050
   // user_pref("security.insecure_connection_icon.enabled", false);
// Калькулятор в адресной строке, например "7+8" и в дроп меню получаем ответ
user_pref("browser.urlbar.suggest.calculator", true);
// Конвертер величин в адресной строке
   // user_pref("browser.urlbar.unitConversion.enabled", true);
// Декодирование URL при копированиии из строки адреса
user_pref("browser.urlbar.decodeURLsOnCopy", true); // (UX BEHAVIOR)

// Показывать панель загрузок при окончании каждой загрузки
   // user_pref("browser.download.panel.shown", false); // Заблокировано в config.js
   // user_pref("browser.download.alwaysOpenPanel", true);

// Сохранять открываемые файлы в TEMP, а не в папку загрузок (есть в политиках)
   // user_pref("browser.download.start_downloads_in_tmp_dir", true);


// В about:addons открывать "расширения", вместо последней открытой категории
// Используется в config.js - lockPref(...
   // user_pref("extensions.ui.lastCategory", "addons://list/extension");

// В about:config предупреждение при входе
user_pref("general.warnOnAboutConfig", false);

// Не показывать в полях ввода пароля блок "Просмотр сохранённых ...."
user_pref("signon.showAutoCompleteFooter", false);

// Не показывать баннер в protections меню
user_pref("browser.protections_panel.infoMessage.seen", true);

/* Масштабировать только текст страниц =false, иначе все вместе с картинками,
 * эту функция теперь доступна в настройках ***/
   // user_pref("browser.zoom.full", true);

// Минимальный размер шрифтов на сайтах
   // user_pref("font.minimum-size.x-cyrillic", 9);
   // user_pref("font.minimum-size.x-unicode", 9);

/* Масштабирование интерфейса браузера. Значение в десятичных долях, например 0.55,
 * в диапазоне 0.00 - 2.00 (~1.63 для 4K) ***/
   // user_pref("layout.css.devPixelsPerPx", -1.0);

/*** Домашняя страница (см. еще 0100) ***/

// Не показывать логотип поисковика
   // user_pref("browser.newtabpage.activity-stream.logowordmark.alwaysVisible", false);
/* При вводе в строке поиска не переключать фокус на адресную строку и
 * не дублировать поисковые предложения в ней ***/
user_pref("browser.newtabpage.activity-stream.improvesearch.handoffToAwesomebar", false);
// ID оттиска или впечатления (хз что это, домашней странице ID не нужен)
user_pref("browser.newtabpage.activity-stream.impressionId", "");

// Показывать ли папку "Другие закладки" на панели закладок
   // user_pref("browser.toolbars.bookmarks.showOtherBookmarks", false);

// Показывать или нет значок в веб-уведомлениях
   // user_pref("alerts.showFavicons", false); // [DEFAULT: false]

// Цветовая тема ридера - "light","dark","sepia","auto"
   // user_pref("reader.color_scheme", "dark");

// Адаптивный цвет значков панели pdf-viewer
   // user_pref("pdfjs.viewerCssTheme", 0);

// Темная тема на страницах about:xxxxxx
   // user_pref("ui.systemUsesDarkTheme", 1); // [HIDDEN PREF] (APPEARANCE)

/* Темная тема панелей ***/
   // user_pref("browser.theme.toolbar-theme", 0); // [DEFAULT: 1] должно изменяться автоматически
// Тема контента (темная = 0, светлая = 1, авто = 2)
   // user_pref("browser.theme.content-theme", 2); // [DEFAULT: 2] может изменяться автоматически
// Тема контента, та что в настройках - 0=темная, 1=Светлая, 2=системная, 3=Firefox
   // user_pref("layout.css.prefers-color-scheme.content-override", 0);

/*** Скролбар ***/

/* Нажатие в определенной точке скроллбара сразу перемещает в эту точку,
 * иначе плавная прокрутка в эту точку, что неудобно на длинных страницах ***/
user_pref("ui.scrollToClick", 1); // [DEFAULT: 0]

/* Плавающие полосы прокрутки специфичные для разных платформ [Fx 100]
 * Скролбар по умолчанию    	0
 * Скролбар macOs           	1
 * Скролбар GTK             	2
 * Скролбар Android         	3
 * Скролбар Windows 10      	4
 * Скролбар Windows 11      	5 ***/
user_pref("widget.non-native-theme.scrollbar.style", 5);
user_pref("widget.gtk.overlay-scrollbars.enabled", true); // [DEFAULT: true]
user_pref("widget.windows.overlay-scrollbars.enabled", true); // [DEFAULT: true]
// Наложенный скролбар + скрытие (вместе с метками, см. ниже)
   // user_pref("ui.useOverlayScrollbars", 1);

/*** Поиск по странице (настроено под DarkReader) ***/

// Цвет подсветки НЕ текущей позиции и всех меток поиска на скроллбаре
   // user_pref("ui.textHighlightBackground", "#00ffff");
// Цвет текста НЕ текущей позиции
   // user_pref("ui.textHighlightForeground", "#1A1A1A");
// Цвет подсветки текущей позиции
   // user_pref("ui.textSelectBackgroundAttention", "#FFFF00");
// Цвет текста текущей позиции
   // user_pref("ui.textSelectForegroundAttention", "#1A1A1A");
// Цвет подсветки при потере фокуса (как правило переопределяется стилем общей подсветки)
   // user_pref("ui.textSelectBackgroundDisabled", "#b0b0b0");

/*** Инструменты разработчика ***/

// Включение инструментов браузера и удаленной отладки (если не понимаете, то скорее всего вам это не надо)
// [CHECK]-all
   // user_pref("devtools.chrome.enabled", true);
   // user_pref("devtools.debugger.remote-enabled", true);
user_pref("devtools.browsertoolbox.fission", true); // многопроцессная отладка
user_pref("devtools.cache.disabled", true); // отключить кэш
user_pref("devtools.debugger.prompt-connection", false); // дурацкое подтверждение
user_pref("devtools.inspector.activeSidebar", "ruleview");
user_pref("devtools.inspector.selectedSidebar", "ruleview");
user_pref("devtools.inspector.three-pane-enabled", false); // глюки
user_pref("devtools.toolbox.selectedTool", "inspector"); // вкладка по умолчанию
user_pref("devtools.toolbox.splitconsoleEnabled", false); // глюки (консоль)
user_pref("devtools.cache.disabled", true); // отключить кэш
// раскладка инспектора
user_pref("devtools.inspector.activeSidebar", "ruleview");
user_pref("devtools.inspector.showUserAgentStyles", true);
// темная тема
   // user_pref("devtools.theme", "dark");

/*** Вкладки ***/

/* При восстановлении сеанса - загружать контент восстановленных вкладок,
 * по умолчанию - не загружать и обновлять вкладки только при их выборе ***/
   // user_pref("browser.sessionstore.restore_on_demand", false); // [DEFAULT: true]
// Обновлять закрепленные вкладки только при их выборе
user_pref("browser.sessionstore.restore_pinned_tabs_on_demand", true);

/* Фокус при закрытии вкладки
 * true  - Если открытая вкладка закрывается, переместить фокус
 * обратно на вкладку, которая ее открыла. (по умолчанию)
 * false - Если открытая вкладка закрывается, переместить фокус
 * на соседнюю правую вкладку, если она существует;
 * в противном случае на соседнюю левую вкладку. ***/
   // user_pref("browser.tabs.selectOwnerOnClose", false);

// Открывать вкладки после текущей
   // user_pref("browser.tabs.insertAfterCurrent", true);
// Открывать связанные вкладки после текущей
user_pref("browser.tabs.insertRelatedAfterCurrent", true);

/*** Miltimedia ***/

// Автозапуск мультимедиа, см. 2030, 2031

// Вся эта секция требует перезапуска браузера
/* Значение TRUE в этом параметре приводит к блеклому отображению цветов в видео
 * Значение FALSE делает недоступными видео выше 1080p на YouTube
 * Может предотвратить подвисание видео при воспроизведении, на некоторых ПК ***/
   // user_pref("media.webm.enabled", false);
/* Для обратного эффекта, если вдруг стало не доступно видео выше 1080p на YouTube
 * можно попробовать проверить/переключить эти параметры ***/
   // user_pref("media.mediasource.webm.enabled", true); // По умолчанию в 91b =true
   // user_pref("media.wmf.dxva.d3d11.enabled", true); // По умолчанию в 91b =true
/* media.wmf.dxva.d3d11.enabled - это функция аппаратного декодирования видео
 * для видеокарт с DirectX10 и выше.
 * Отключите false эту функцию, если у вас видеокарта до DirectX9 включительно,
 * либо видеокарта вообще не поддерживает аппаратное декодирование H.264.
 * В некоторых случаях, отключение этой функции, также может помочь избавиться от
 * возникших проблем при воспроизведении видео на видеокартах от DirectX10. ***/
// Cкрытый (удалить, если не равен 2) или создать и выставить в 2
   // user_pref("gfx.crash-guard.status.wmfvpxvideo", 2);
// Так же можно попробовать удалить все строки с gfx.crash-guard.*
// При подвисаниях видео можно попробовать false для
   // user_pref("media.wmf.dxva.enabled", true); // При просмотре нагрузка на процессор возрастет
/* Решение проблемы появления артефактов при воспроизведении видео Fx 100+ */
   // user_pref("gfx.webrender.dcomp-video-overlay-win", false);

// Скрыть переключатель на видео "картинка в картинке"
   // user_pref("media.videocontrols.picture-in-picture.video-toggle.enabled", false);
// или свернуть его в значок
user_pref("media.videocontrols.picture-in-picture.video-toggle.has-used", true);

// Media cache - для предотврашения смены кривыми расширениями
user_pref("media.cache_size", 512000); // [DEFAULT: 512000]

/* При вставке скопированных изображений Fx может портить цветность,
 * в этом случае можно попробовать ***/
   // user_pref("gfx.color_management.enablev4", true);

/*** Память ***/

/* Как часто проверять страницу на изменения. Значения:
 * 0 - один раз за сессию
 * 1 - каждый раз при просмотре страницы
 * 2 - не проверять, использовать кэш браузера
 * 3 - проверять, когда страница устарела (автоматически). ***/
   // user_pref("browser.cache.check_doc_frequency", 3); // [DEFAULT: 3]

/* История вкладок, сохраняется при сохранении сессий.
 * Для приватности, при использовании функции сохранения сессий, можно
 * отключить второй параметр, а для очистки первого использовать автоочистку (2802)
 * или вручную очищать данные перед закрытием браузера. Иначе при восстановлении
 * сессии, тому кто ее восстановит, будет доступна вся ваша история вкладок.
 * Т.е. например, вкладка поваренок.ру, а в ее истории (стрелки вперед-назад)
 * порнохаб и страницы гугла со странными поисковыми запросами. )
 * Это ни как не отразится на истории посещений. ***/

// 5007: История закрытых вкладок для "восстановить закрытую вкладку"
user_pref("browser.sessionstore.max_tabs_undo", 25);
/* История вкладок "вперед<->назад". Минимум 1, практический минимум = 2,
 * так как некоторые страницы используют эту функцию для перенаправления. ***/
user_pref("browser.sessionhistory.max_entries", 10);
/* Максимум страниц с историей "вперед<->назад" для хранения в памяти,
 * -1 = авто (по умолчанию), 0 = отключить, максимум 8.
 * 1 может увеличить потребление памяти. Отключение просто не держит
 * страницы в памяти, а загружает их из сети при повторном вызове.
 * 0 не позволит восстанавливаться этим данным при восстановлении сессий. ***/
user_pref("browser.sessionhistory.max_total_viewers", 2);

/* Разрешить Windows сбрасывать память на диск, когда Firefox свернут.
 * Зависит от Windows. Разворачивание при этом будет тормозить. ***/
   // user_pref("config.trim_on_minimize", true); // [HIDDEN PREF]

/*** Оптимизация ***/

// Отключить изоляцию сайтов- Возвращает выбор числа процессов
   // user_pref("fission.autostart", false); // не рекомендуется
/* Если не использовать преф выше то:
 * 1 процесс на каждый сайт, тоже не рекомендуется,
 * это все костыли для совсем уж дохлых ПК и в ущерб безопасности. ***/
   // user_pref("dom.ipc.processCount.webIsolated", 1);
   // user_pref("fission.webContentIsolationStrategy", 0);

/* Для каждой вкладки свой процесс
 * При использовании Auto Tab Discard может уменьшить потребление памяти
 * https://addons.mozilla.org/ru/firefox/addon/auto-tab-discard ***/
   // user_pref("dom.ipc.processCount", -1);

/* Сеть в отдельном процессе - оптимизирует начальную загрузку
 * тяжелых сайтов и глюки соединения ***/
user_pref("network.process.enabled", true); // [DEFAULT: true]

/* Скорее всего устаревшее, второго префа нет в 102 или его скрыли.
 * Новый движок рендеринга, при проблемах с прорисовкой сайтов можно попробовать
 * раскомментировать 2-ой преф, первый преф и так отключен ***/
   // user_pref("gfx.webrender.enabled", false); // [DEFAULT: false]
   // user_pref("gfx.webrender.force-disabled", true); // [DEFAULT: false]

/* При включенном gfx.webrender.enabled на Windows 7 и затуманенных/пропавших
 * кнопках управления окном, убирает этот эффект ***/
   // user_pref("gfx.webrender.software", true); // кнопка

/* END: internal custom pref to test for syntax errors ***/
user_pref("_user.js.parrot", "УСПЕХ: user.js полностью загружен.");
