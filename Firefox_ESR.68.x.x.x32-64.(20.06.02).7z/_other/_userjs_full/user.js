/******
* Нумерация, если есть, соответствует ghacks user.js v. 31 August 2019
* url: https://github.com/ghacksuserjs/ghacks-user.js
* 
* Разделение по секциям условное.
* 
* При удалении параметра не забудьте сбросить его about:config
******/

/********************** Отключение всяких автообновлений ********************/

// 0301a: disable auto-update checks for Firefox
// [SETTING] General>Firefox Updates>Never check for updates
user_pref("app.update.enabled", false);
// 0000: ??? Обновление через службу Windows ??? ESR ???
user_pref("app.update.BITS.enabled", false);
// 0301b: disable auto-CHECKING for extension and theme updates
user_pref("extensions.update.enabled", false);
// 0302a: disable auto-INSTALLING Firefox updates
user_pref("app.update.auto", false);
// 0302b: disable auto-INSTALLING extension and theme updates (after the check in 0301b)
user_pref("extensions.update.autoUpdateDefault", false);
// 0308: disable search update
user_pref("browser.search.update", false);
// 0505: disable System Add-on updates
user_pref("extensions.systemAddon.update.enabled", false);
user_pref("extensions.systemAddon.update.url", "");

/****** Отключение всяких Crash Reports, Telemetry and Recommendations ******/

// 0105a: disable Activity Stream telemetry
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry.ping.endpoint", "");
user_pref("browser.newtabpage.activity-stream.telemetry", false);
// 0105b: disable Activity Stream Snippets
user_pref("browser.newtabpage.activity-stream.asrouter.providers.snippets", "");
user_pref("browser.newtabpage.activity-stream.feeds.snippets", false);
// 0105c: disable Activity Stream Top Stories, Pocket-based and/or sponsored content
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false); // [FF66+]
// 0309: disable sending Flash crash reports
user_pref("dom.ipc.plugins.flash.subprocess.crashreporter.enabled", false);
// 0310: disable sending the URL of the website where a plugin crashed
user_pref("dom.ipc.plugins.reportCrashURL", false);
// 0320: disable about:addons' Recommendations pane (uses Google Analytics)
user_pref("extensions.getAddons.showPane", false); // [HIDDEN PREF]
user_pref("extensions.webservice.discoverURL", "");
// 0321: disable recommendations in about:addons'
user_pref("extensions.getAddons.discovery.api_url", "");
user_pref("extensions.htmlaboutaddons.discover.enabled", false);
user_pref("extensions.htmlaboutaddons.recommendations.enabled", false);
/* 0330: disable telemetry
 * the pref (.unified) affects the behaviour of the pref (.enabled)
 * IF unified=false then .enabled controls the telemetry module
 * IF unified=true then .enabled ONLY controls whether to record extended data
 * so make sure to have both set as false ***/
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.enabled", false);
user_pref("toolkit.telemetry.server", "data:,");
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false);
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false);
user_pref("toolkit.telemetry.updatePing.enabled", false);
user_pref("toolkit.telemetry.bhrPing.enabled", false);
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false);
user_pref("toolkit.telemetry.hybridContent.enabled", false);
user_pref("toolkit.telemetry.cachedClientID", "");
// 0331: disable Telemetry Coverage (search)
user_pref("toolkit.telemetry.coverage.opt-out", true); // [HIDDEN PREF]
user_pref("toolkit.coverage.opt-out", true); // [FF64+] [HIDDEN PREF]
user_pref("toolkit.coverage.endpoint.base", "");
// 0340: disable Health Reports
user_pref("datareporting.healthreport.uploadEnabled", false);
// 0341: disable new data submission, master kill switch
user_pref("datareporting.policy.dataSubmissionEnabled", false);
// 0350: disable Crash Reports
user_pref("breakpad.reportURL", "");
user_pref("browser.tabs.crashReporting.sendReport", false);
user_pref("browser.crashReports.unsubmittedCheck.enabled", false);
// 0351: disable backlogged Crash Reports
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit", false);
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false);
/* 0370: disable Pocket [FF46+]
 * Pocket is a third party "save for later" cloud service ***/
   // user_pref("extensions.pocket.enabled", false);
// 0390: disable Captive Portal detection
user_pref("captivedetect.canonicalURL", "");
user_pref("network.captive-portal-service.enabled", false); // [FF52+]
// 0503: disable Normandy/Shield [FF60+] telemetry system (incl. Heartbeat)
user_pref("app.normandy.api_url", "");
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.first_run", false);
// 0506: disable PingCentre telemetry Currently blocked (see 0340)
user_pref("browser.ping-centre.telemetry", false);
user_pref("browser.ping-centre.production.endpoint", "");
user_pref("browser.ping-centre.staging.endpoint", "");
// 1204: disable SSL Error Reporting
user_pref("security.ssl.errorReporting.automatic", false);
user_pref("security.ssl.errorReporting.enabled", false);
user_pref("security.ssl.errorReporting.url", "");

/************************ Приватность и безопасность **************************/

/* Отключение сломает возможность авторизации на некоторых важных сайтах.
 * Сломает работу многих расширений. ***/
user_pref("dom.storage.enabled", true); // [DEFAULT: true]

/* Предотвращает возможность сканирования портов локальной сети. ***/
user_pref("network.http.altsvc.enabled", false);

/*** [SECTION 4000]: FPI (FIRST PARTY ISOLATION) ***/
/* 4001: Изоляция данных.
 * Может нарушить некоторую функциональность небольшого числа сайтов. ***/
user_pref("privacy.firstparty.isolate", true);
/* 4002: принудительное ограничение FPI для window.opener [FF54 +]
 * [NOTE] Установка этого значения в false может уменьшить поломку в 4001
 * FF65 + блокирует postMessage с targetOrigin "*", если originAttributes
 * не совпадают. Чтобы уменьшить вероятность поломки, игнорирует
 * originAttribute стороннего домена (FPD).
 * Второй преф, снимает это ограничение и разрешает связь, только если
 * FPD также совпадают. (толку от второго префа у себя не заметил) ***/
user_pref("privacy.firstparty.isolate.restrict_opener_access", false); // [DEFAULT: true]
   // user_pref("privacy.firstparty.isolate.block_post_message", true); // [HIDDEN PREF]

/** OCSP (Online Certificate Status Protocol) ***/
// 1210: enable OCSP Stapling
user_pref("security.ssl.enable_ocsp_stapling", true);
/* 1211: получение OCSP  подтверждения текущей действительности сертификатов
 * Настройки >> Приватность и защита >> Запрашивать OCSP...
 * 0=disabled, 1=enabled (default), 2=enabled for EV certificates only
 * OCSP (non-stapled) leaks information about the sites you visit to the CA (cert authority)
 * It's a trade-off between security (checking) and privacy (leaking info to the CA)
 * [NOTE] This pref only controls OCSP fetching and does not affect OCSP stapling ***/
user_pref("security.OCSP.enabled", 0);
/* 1212: set OCSP fetch failures
 * (non-stapled, see 1211) to hard-fail [SETUP-WEB]
 * Разрывать или нет соединение при недоступности центра сертификации ***/
user_pref("security.OCSP.require", false);

/*** [SECTION 2600]: MISCELLANEOUS ***/
/* 2601: prevent accessibility services from accessing your browser [RESTART]
 * [SETTING] Privacy & Security>Permissions>Prevent accessibility services
 * from accessing your browser ***/
user_pref("accessibility.force_disabled", 1);
// 2602: disable sending additional analytics to web servers
user_pref("beacon.enabled", false);

/*** [SECTION 2700]: PERSISTENT STORAGE ***/
/* 2701: disable 3rd-party cookies and site-data [SETUP-WEB]
 * 0=Accept cookies and site data (default), 1=(Block) All third-party cookies,
 * 2=(Block) All cookies, 3=(Block) Cookies from unvisited sites,
 * 4=(Block) Third-party trackers (FF63+)
 * [NOTE] Value 4 is tied to the Tracking Protection lists
 * [NOTE] You can set exceptions under site permissions or use an extension
 * [SETTING] Privacy & Security>Content Blocking>Custom>Choose what to block>Cookies ***/
   // user_pref("network.cookie.cookieBehavior", 4);
/* 2702: set third-party cookies (i.e ALL) (if enabled, see 2701) to session-only and (FF58+) set third-party non-secure (i.e HTTP) cookies to session-only
 * [NOTE] .sessionOnly overrides .nonsecureSessionOnly except when .sessionOnly=false and .nonsecureSessionOnly=true.
 * This allows you to keep HTTPS cookies, but session-only HTTP ones ***/
   // user_pref("network.cookie.thirdparty.sessionOnly", true);
   // user_pref("network.cookie.thirdparty.nonsecureSessionOnly", true); // [FF58+]

/*** [SECTION 0400]: BLOCKLISTS / SAFE BROWSING (SB) ***/
/* 0401: enforce Firefox blocklist, but sanitize blocklist url
 * [NOTE] It includes updates for "revoked certificates" ***/
   // user_pref("extensions.blocklist.enabled", true); // [DEFAULT: true]
   // user_pref("extensions.blocklist.url", "https://blocklists.settings.services.mozilla.com/v1/blocklist/3/%APP_ID%/%APP_VERSION%/"); // [DEFAULT]
/* 0402: disable binaries NOT in Safe Browsing local lists being checked
 * This is a real-time check with Google services
 * [SETUP-SECURITY] If you do not understand this, or if you want this
 * protection, then override it ***/
   // user_pref("browser.safebrowsing.downloads.remote.enabled", false);
/* 0403: disable 'ignore this warning' on Safe Browsing warnings
 * If clicked, it bypasses the block for that session.
 * This is a means for admins to enforce SB ***/
   // user_pref("browser.safebrowsing.allowOverride", true);

/************************************ Сеть ************************************/

/*  0 – Отключить реферер.
 *  1 – Отправить Referer при нажатии на ссылку и установить document.referrer для следующей страницы.
 *  2 – Отправить Referer при нажатии на ссылку или загрузке изображения (по умолчанию). ***/
   //user_pref("network.http.sendRefererHeader", 1);

/*** [SECTION 0600]: BLOCK IMPLICIT OUTBOUND ***/
/*** Паразитические сетевые запросы. Вроде ничего не ломает. ***/
// 0601: disable link prefetching
   // user_pref("network.prefetch-next", false);
// 0602: disable DNS prefetching
   // user_pref("network.dns.disablePrefetch", true);
   // user_pref("network.dns.disablePrefetchFromHTTPS", true); // [HIDDEN PREF]
// 0603: disable predictor / prefetching
   // user_pref("network.predictor.enabled", false);
   // user_pref("network.predictor.enable-prefetch", false); // [FF48+]
// 0605: disable link-mouseover opening connection to linked server
   // user_pref("network.http.speculative-parallel-limit", 0);
// 0606: disable pings (but enforce same host in case)
   // user_pref("browser.send_pings", false); // [DEFAULT: false]
   // user_pref("browser.send_pings.require_same_host", true);

/*** [SECTION 0700]: HTTP* / TCP/IP / DNS / PROXY / SOCKS etc ***/
/* 0701: disable IPv6
 * IPv6 can be abused, especially regarding MAC addresses. They also do not
 * play nice with VPNs. That's even assuming your ISP and/or router and/or
 * website can handle it. Firefox telemetry (April 2019) shows only 5% of all
 * connections are IPv6.
 * [NOTE] This is just an application level fallback. Disabling IPv6 is best
 * done at an OS/network level, and/or configured properly in VPN setups.
 * If you are not masking your IP, then this won't make much difference.
 * If you are maksing your IP, then it can only help. ***/
   // user_pref("network.dns.disableIPv6", true);
/* 0704: enforce the proxy server to do any DNS lookups when using SOCKS
 * e.g. in Tor, this stops your local DNS server from knowing your Tor
 * destination as a remote Tor node will handle the DNS request ***/
   // user_pref("network.proxy.socks_remote_dns", false);
/* 0707: disable (or setup) DNS-over-HTTPS (DoH) [FF60+]
 * Coogle - 8.8.8.8, Cloudflare - 1.1.1.1, Shivering-Isles - 185.207.105.117
 * TRR = Trusted Recursive Resolver. Mode: 0=off, 1=race, 2=TRR first,
 * 3=TRR only, 4=race for stats but always use native result.
 * Далее уже настроенные значения с альтернативным DoH сервером. ***/
   // user_pref("network.trr.mode", 3);
   // user_pref("network.trr.bootstrapAddress", "185.207.105.117");
   // user_pref("network.trr.resolvers", "[{ "name": "Cloudflare", "url": "https://mozilla.cloudflare-dns.com/dns-query" },{ "name": "Shivering-Isles", "url": "https://dns.shivering-isles.com/dns-query" },{ "name": "Google", "url": "https://dns.google.com/experimental" }]");
   // user_pref("network.trr.uri", "https://dns.shivering-isles.com/dns-query");
/* 0708: disable FTP [FF60+] ***/
   // user_pref("network.ftp.enabled", false);
/* 0709: disable using UNC (Uniform Naming Convention) paths [FF61+]
 * [SETUP-CHROME] Can break extensions for profiles on network shares ***/
   // user_pref("network.file.disable_unc_paths", true); // [HIDDEN PREF]
/* 0710: disable GIO as a potential proxy bypass vector
 * Gvfs/GIO has a set of supported protocols like obex, network, archive,
 * computer, dav, cdda, gphoto2, trash, etc. By default only smb and sftp
 * protocols are accepted so far (as of FF64) ***/
user_pref("network.gio.supported-protocols", ""); // [HIDDEN PREF]
/* 1205: disable TLS1.3 0-RTT (round-trip time) [FF51+]
 * [1] https://github.com/tlswg/tls13-spec/issues/1001
 * [2] https://blog.cloudflare.com/tls-1-3-overview-and-q-and-a/ ***/
   // user_pref("security.tls.enable_0rtt_data", false);

/***************************** Внешний вид и поведение ************************/

// Масштабировать только текст, иначе все, вместе с картинками
user_pref("browser.zoom.full", false);

// Темная тема на страницах about:xxxxxx
   // user_pref("browser.in-content.dark-mode", true);
   // user_pref("ui.systemUsesDarkTheme", 1); // [HIDDEN PREF]

/* Если нет, то перетягивание из браузера в проводник и окна
 * других программ не работает. ***/
user_pref("browser.launcherProcess.enabled", true); // [HIDDEN PREF]

/* about:addons - html версия списка (настраивается стилями) ***/
   // user_pref("extensions.htmlaboutaddons.enabled", true);
/* 2684: enforce a security delay on some confirmation dialogs
 * such as install, open/save ***/
   // user_pref("security.dialog_enable_delay", 0);

// закрывать ли браузер при закрытии последней вкладки
   // user_pref("browser.tabs.closeWindowWithLastTab", false);
// открывать ли закладки в новой вкладке
   // user_pref("browser.tabs.loadBookmarksInTabs", true);
// открывать ли из строки адреса в новой вкладке
   // user_pref("browser.urlbar.openintab", true);
// открывать ли поиск в новой вкладке 
   // user_pref("browser.search.openintab", true);

// Обновлять вкладки только при их выборе
   // user_pref("browser.sessionstore.restore_on_demand", true); // [DEFAULT]
// Обновлять ЗАКРЕПЛЁННЫЕ вкладки только при их выборе
   // user_pref("browser.sessionstore.restore_pinned_tabs_on_demand", true);

/* true  - Если открытая вкладка закрывается, переместить фокус
 * обратно на вкладку, которая ее открыла. (по умолчанию)
 * false - Если открытая вкладка закрывается, переместить фокус
 * на соседнюю правую вкладку, если она существует;
 * в противном случае на соседнюю левую вкладку. ***/
user_pref("browser.tabs.selectOwnerOnClose", false);

// see bugzilla 1320061 [FF53+]
   // ser_pref("browser.urlbar.decodeURLsOnCopy", true);

// [FF68+] allow userChrome/userContent
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

/* 2604: отключить создание thumbnail в папке профиля ***/
   // user_pref("browser.pagethumbnails.capturing_disabled", true); // [HIDDEN PREF]

/* Как часто Firefox должен спрашивать мастер пароль
 * 0 = при появлении первого поля логина
 * 1 = каждый раз при логине
 * 2 = каждые n минут (security.password_lifetime = n) ***/
   // user_pref("security.ask_for_password", 2);
// Период в минутах, как часто Firefox должен спрашивать мастер пароль
   // user_pref("security.password_lifetime", 5); 

/*** DOWNLOADS ***/
// Переопределение поведения при загрузке файлов
/* 2650: discourage downloading to desktop
 * 0=desktop 1=downloads 2=last used ***/
   // user_pref("browser.download.folderList", 2);
// 2651: always asking where to download
   // user_pref("browser.download.useDownloadDir", false);
// 2652: disable adding downloads to the system's "recent documents" list
   // user_pref("browser.download.hide_plugins_without_extensions", false);

// Показывать список загрузок при старте загрузки (надо поставить false)
   // user_pref("browser.download.panel.shown", false);


/** EXTENSIONS ***/
/* 2662: disable webextension restrictions on certain mozilla domains (см. 4503) [FF60+] ***/
   // user_pref("extensions.webextensions.restrictedDomains", "");

/*** [SECTION 2800]: SHUTDOWN ***/
/* 2802: enable Firefox to clear items on shutdown (see 2803)
 * [SETTING]
 * Очистка истории при закрытии ***/
   // user_pref("privacy.sanitize.sanitizeOnShutdown", true);
/* 2803: set what items to clear on shutdown (if 2802 is true)
 * Если history true, то downloads тоже true, независимо от значения,
 * если history false, то downloads можно true отдельно. ***/
   // user_pref("privacy.clearOnShutdown.cache", true);
   // user_pref("privacy.clearOnShutdown.cookies", true);
   // user_pref("privacy.clearOnShutdown.downloads", true); // see note above
   // user_pref("privacy.clearOnShutdown.formdata", true); // Form & Search History
   // user_pref("privacy.clearOnShutdown.history", true); // Browsing & Download History
   // user_pref("privacy.clearOnShutdown.offlineApps", true); // Offline Website Data
   // user_pref("privacy.clearOnShutdown.sessions", true); // Active Logins
   // user_pref("privacy.clearOnShutdown.siteSettings", false); // Site Preferences
/* 2804: очистка по кнопке или ключу Ctrl-Shift-Del (to match 2803) [SETUP-CHROME]
 * This dialog can also be accessed from the menu History>Clear Recent History ***/
   // user_pref("privacy.cpd.cache", true);
   // user_pref("privacy.cpd.cookies", true);
   // user_pref("privacy.cpd.downloads", true); // not used
   // user_pref("privacy.cpd.formdata", true); // Form & Search History
   // user_pref("privacy.cpd.history", true); // Browsing & Download History
   // user_pref("privacy.cpd.offlineApps", true); // Offline Website Data
   // user_pref("privacy.cpd.passwords", false); // this is not listed
   // user_pref("privacy.cpd.sessions", true); // Active Logins
   // user_pref("privacy.cpd.siteSettings", false); // Site Preferences
/* 2806: Всегда сбрасывать 'Диапазон времени для очистки'
 * в 'Очистить недавнюю историю' (see 2804) на это значение.
 * 0=everything, 1=last hour, 2=last two hours, 3=last four hours,
 * 4=today, 5=last five minutes, 6=last twenty-four hours
 * [NOTE] The values 5 + 6 are not listed in the dropdown, which will display a
 * blank value if they are used, but they do work as advertised ***/
   // user_pref("privacy.sanitize.timeSpan", 0);

/*** [SECTION 0800]: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS ***/
/* 0805: disable CSS querying page history - CSS history leak
 * Подсветка посещенных ссылок работать не будет. Но, если включено,
 * то сайты получают доступ к вашей истории посещений. ***/
   // user_pref("layout.css.visited_links_enabled", false);
/* 0807: disable live search suggestions
/* [NOTE] Both must be true for the location bar to work
 * Отключит предложения при поиске в строках адреса и поиска ***/
   // user_pref("browser.search.suggest.enabled", false);
   // user_pref("browser.urlbar.suggest.searches", false);
/* 0850a: disable location bar suggestion types
 * [SETTING] Приватность и защита>Панель адреса 
 * Отключит подстановку адресов с строке адреса ***/
   // user_pref("browser.urlbar.suggest.history", false);
   // user_pref("browser.urlbar.suggest.bookmark", false);
   // user_pref("browser.urlbar.suggest.openpage", false);

/*** [SECTION 2000]: MEDIA / CAMERA / MIC *************************************/

/* Значение TRUE в этом параметре приводит к блеклому отображению цветов
 * при воспроизведении видео (просто дерьмовому).
 * Значение FALSE делает недоступными видео выше 1080p ***/
user_pref("media.webm.enabled", false);

/* 2001: disable WebRTC (Web Real-Time Communication)
 * [SETUP-WEB] Предотвращает утечку IP адреса через WebRTC.
 * Актуально при использовании VPN и прокси ***/
user_pref("media.peerconnection.enabled", false);
/* 2002: limit WebRTC IP leaks if using WebRTC ***/
   // user_pref("media.peerconnection.ice.default_address_only", true);
   // user_pref("media.peerconnection.ice.no_host", true); // [FF51+]
/* 2010: disable WebGL (Web Graphics Library)
 * [SETUP-WEB] When disabled, may break some websites. When enabled, provides high entropy,
 * especially with readPixels(). Some of the other entropy is lessened with RFP (see 4501) ***/
   // user_pref("webgl.disabled", true);
   // user_pref("webgl.dxgl.enabled", false); // [WINDOWS]
   // user_pref("webgl.enable-webgl2", false);
/* 2012: limit WebGL ***/
   // user_pref("webgl.min_capability_mode", true);
   // user_pref("webgl.disable-extensions", true);
   // user_pref("webgl.disable-fail-if-major-performance-caveat", true);
/* 2022: disable screensharing ***/
   // user_pref("media.getusermedia.screensharing.enabled", false);
   // user_pref("media.getusermedia.browser.enabled", false);
   // ser_pref("media.getusermedia.audiocapture.enabled", false);
/* 2024: set a default permission for Camera-Microphone [FF58+]
 * 0=always ask (default), 1=allow, 2=block
 * [SETTING] add: Page Info>Permissions>Use the Camera/Microphone
 * [SETTING] manage: Options>Privacy & Security>Permissions>Camera/Microphone>Settings ***/
   // user_pref("permissions.default.camera", 2);
   // user_pref("permissions.default.microphone", 2);
/* 2030: отключит, на сколько это возможно, автозапуск мультимедиа HTML5 [FF63+]
 * 0=Allowed, 1=Blocked (2=Prompt - removed in FF66)
 * [NOTE] You can set exceptions under site permissions
 * [SETTING] Privacy & Security>Permissions>Block websites from automatically playing sound ***/
   // user_pref("media.autoplay.default", 1); // [DEFAULT: 1 in FF67+]
/* 2031: disable autoplay of HTML5 media if you interacted with the site [FF66+] ***/
   // user_pref("media.autoplay.enabled.user-gestures-needed", false);
/* 2032: disable audio autoplay in non-active tabs [FF51+] ***/
   // user_pref("media.block-autoplay-until-in-foreground", true); // [DEFAULT: true]
/* 2033: disable autoplay for muted videos [FF63+] ***/
   // user_pref("media.autoplay.allow-muted", false);

/************** Разрешения для сайтов по управлению окнами и др. ***************/

/*** [SECTION 2200]: WINDOW MEDDLING & LEAKS / POPUPS ***/
/* 2201: prevent websites from disabling new window features ***/
   // user_pref("dom.disable_window_open_feature.close", true);
   // user_pref("dom.disable_window_open_feature.location", true); // [DEFAULT: true]
   // user_pref("dom.disable_window_open_feature.menubar", true);
   // user_pref("dom.disable_window_open_feature.minimizable", true);
   // user_pref("dom.disable_window_open_feature.personalbar", true); // bookmarks toolbar
   // user_pref("dom.disable_window_open_feature.resizable", true); // [DEFAULT: true]
   // user_pref("dom.disable_window_open_feature.status", true); // [DEFAULT: true]
   // user_pref("dom.disable_window_open_feature.titlebar", true);
   // user_pref("dom.disable_window_open_feature.toolbar", true);
/* 2202: prevent scripts from moving and resizing open windows ***/
user_pref("dom.disable_window_move_resize", true);
/* 2203: open links targeting new windows in a new tab instead
 * This stops malicious window sizes and some screen resolution leaks.
 * You can still right-click a link and open in a new window. ***/
user_pref("browser.link.open_newwindow", 3);
user_pref("browser.link.open_newwindow.restriction", 0);
/* 2204: disable Fullscreen API (requires user interaction) to prevent screen-resolution leaks
 * [NOTE] You can still manually toggle the browser's fullscreen state (F11),
 * but this pref will disable embedded video/game fullscreen controls, e.g. youtube
 * [TEST] https://ghacksuserjs.github.io/TorZillaPrint/TorZillaPrint.html#screen ***/
   // user_pref("full-screen-api.enabled", false);
/* 2210: block popup windows
 * [SETTING] Privacy & Security>Permissions>Block pop-up windows ***/
   // user_pref("dom.disable_open_during_load", true);
/* 2212: limit events that can cause a popup [SETUP-WEB]
 * default is "change click dblclick auxclick mouseup pointerup notificationclick
 * reset submit touchend contextmenu" ***/
   // user_pref("dom.popup_allowed_events", "click dblclick");

/*** [SECTION 2300]: WEB WORKERS ***/
/* 2302: disable service workers [FF32, FF44-compat]
 * Service workers essentially act as proxy servers that sit between web apps, and the browser
 * and network, are event driven, and can control the web page/site it is associated with,
 * intercepting and modifying navigation and resource requests, and caching resources.
 * [NOTE] Service worker APIs are hidden (in Firefox) and cannot be used when in PB mode.
 * [NOTE] Service workers only run over HTTPS. Service workers have no DOM access. ***/
user_pref("dom.serviceWorkers.enabled", false); // [DEFAULT: false]
/* 2304: disable Web Notifications
 * [NOTE] Web Notifications require service workers (2302) and are behind a prompt (2306) ***/
   // user_pref("dom.webnotifications.enabled", false); // [FF22+]
   // user_pref("dom.webnotifications.serviceworker.enabled", false); // [FF44+]
/* 2305: disable Push Notifications [FF44+] ***/
   // user_pref("dom.push.enabled", false);
   // user_pref("dom.push.connection.enabled", false);
   // user_pref("dom.push.serverURL", "");
   // user_pref("dom.push.userAgentID", "");
/* 2306: set a default permission for Notifications (both 2305 and 2306) [FF58+]
 * 0=always ask (default), 1=allow, 2=block
 * [NOTE] Best left at default "always ask", fingerprintable via Permissions API
 * [SETTING] to add site exceptions: Page Info>Permissions>Receive Notifications
 * [SETTING] to manage site exceptions: Options>Privacy & Security>Permissions>Notifications>Settings ***/
   // user_pref("permissions.default.desktop-notification", 2);

/*** DOM (DOCUMENT OBJECT MODEL) & JAVASCRIPT ***/
/* 2401: disable website control over browser right-click context menu
 * [NOTE] Shift-Right-Click will always bring up the browser right-click context menu 
 * Если false то контекстное меню вызывается где ни попадя, в аддонах, TST и т.п. ***/
   // user_pref("dom.event.contextmenu.enabled", false);
/* 2402: disable website access to clipboard events/content
 * [SETUP-WEB] Ломает взаимодействие сайтов с буфером обмена
 * Затрагивает только очень-очень редкие сайты которым это действительно нужно.
 * Если включено, то все сайты имеют доступ к вашему буферу обмена. ***/
   // user_pref("dom.event.clipboardevents.enabled", false);
/* 2403: disable clipboard commands (cut/copy) from "non-privileged" content [FF41+]
 * По опыту, ломает взаимодействие пользовательских скриптов с буфером ***/
   // user_pref("dom.allow_cut_copy", false);
/* 2404: disable "Confirm you want to leave" dialog on page close
 * Does not prevent JS leaks of the page close event. ***/
user_pref("dom.disable_beforeunload", true);
// 2414: disable shaking the screen
   // user_pref("dom.vibrator.enabled", false);
/* 2429: enable (limited but sufficient) window.opener protection [FF65+]
 * Makes rel=noopener implicit for target=_blank in anchor and area elements
 * when no rel attribute is set ***/
   // user_pref("dom.targetBlankNoOpener.enabled", true);

/********************************** Плагины ***********************************/

// EME-free - удалить если пользуетесь кодеком EME
user_pref("app.partner.mozilla-EMEfree", "mozilla-EMEfree");
// EME-free - переключить если пользуетесь кодеком EME
/* 1825: disable widevine CDM (Content Decryption Module)
 * Switch if you *need* CDM, e.g. Netflix, Amazon Prime, Hulu, whatever ***/
user_pref("media.gmp-widevinecdm.visible", false);
user_pref("media.gmp-widevinecdm.enabled", false);
// 1830: disable all DRM content (EME: Encryption Media Extension)
user_pref("browser.eme.ui.enabled", false);
user_pref("media.eme.enabled", false);

// OpenH264 - переключить если НЕ пользуетесь кодеком OpenH264
user_pref("media.gmp-gmpopenh264.enabled", true);
/* Если переключить, то кодек вообще удалится из профиля и about:addons
 * При обратном включении зайдите в about:addons в плагины и обновите его
 * Firefox загрузит его за десяток секунд, размер кодека чуть меньше 1Мб ***/
user_pref("media.gmp-gmpopenh264.visible", true);

/*********************************** Кэш и память *****************************/

/* Отправляем кэш в память.
 * Подойдет для систем с нормальным количеством памяти >4ГБ ***/
// 1003: disable memory cache
user_pref("browser.cache.memory.enable", true);
/* Эти два префа обычно нет смысла переопределять.
 * Capacity:
 * -1=determine dynamically (default),
 * 0=none,
 * n=memory capacity in kb ***/
      // user_pref("browser.cache.memory.capacity", 0); // [HIDDEN PREF]
// * Максимум для одной записи 
      // user_pref("browser.cache.memory.max_entry_size", 5120); // [DEFAULT: 5120]
   // user_pref("browser.cache.disk.enable", false);
   // user_pref("browser.cache.disk.capacity", 0);
   // user_pref("browser.cache.disk_cache_ssl", false);
   // user_pref("browser.cache.offline.capacity", 0);
   // user_pref("browser.cache.offline.enable", false);

// Media cache - для предотврашения смены кривыми расширениями
   // user_pref("media.cache_size", 512000); // [DEFAULT: 512000]

/* Как часто проверять страницу на изменения. Значения:
 * 0 - один раз за сессию
 * 1 - каждый раз при просмотре страницы
 * 2 - не проверять, использовать кэш браузера
 * 3 - проверять, когда страница устарела (автоматически). ***/
   // user_pref("browser.cache.check_doc_frequency", 3); // [DEFAULT: 3]

/* Освобождать память при сворачивании окна браузера,
 * разворачивание при этом может подтормаживать. ***/
   // user_pref("config.trim_on_minimize", true); // [Создать] Логическое

/************************* Сессии и история вкладок ***************************/

/* История вкладок, сохраняется при сохранении сессий.
 * Для приватности, при использовании функции сохранения сессий, можно
 * отключить первые два параметра. Иначе при восстановлении сессии
 * будет доступной вся история вкладок. Т.е. например, вкладка поваренок.ру,
 * а в ее истории порнохаб и страница гугла с поисковым запросом "что делать
 * что бы меня отпустило" ))).  Это ни как не отразится на истории посещений. ***/

// 1020: История закрытых вкладок для "восстановить закрытую вкладку".
   // user_pref("browser.sessionstore.max_tabs_undo", 15);
/* История вкладок "вперед<->назад". Минимум 1, практический минимум = 2,
 * так как некоторые страницы используют эту функцию для перенаправления. ***/
   // user_pref("browser.sessionhistory.max_entries", 10);
/* Максимум страниц с историей "вперед<->назад" для хранения в памяти,
 * по умолчанию -1 = автоматически, 0 = отключить, максимум 8.
 * Считается, что эта функция может тормозить браузер. Отключение просто
 * не держит страницы в памяти, а загружает из сети при повторном вызове. ***/
   // user_pref("browser.sessionhistory.max_total_viewers", -1);

/* browser.sessionstore.enabled - более не работает,
 * сессия пишется в любом случае. ***/
/* 1021: disable storing extra session data [SETUP-CHROME] extra session data
 * contains contents of forms, scrollbar positions, cookies and POST data define
 * on which sites to save extra session data:
 * 0=everywhere, 1=unencrypted sites, 2=nowhere ***/
   // user_pref("browser.sessionstore.privacy_level", 2);
/* 1022: disable resuming session from crash ***/
   // user_pref("browser.sessionstore.resume_from_crash", false);
/* 1023: минимальный интервал между сохранениями сеанса
 * Сокращаем писанину на диск, при штатном выходе все равно перепишется,
 * при не штатном - все равно сессия пропадает, как правило.
 * Можно попробовать восстановить так -
 * https://fstrange.ru/coder/programs-to-work/firefox-kak-vosstanovit-vkladki.html ***/
   // user_pref("browser.sessionstore.interval", 1200000);
   // user_pref("browser.sessionstore.interval.idle", 6000000);
/* 1024: disable automatic Firefox start and session restore after reboot
 * [FF62+] [WINDOWS] [1] https://bugzilla.mozilla.org/603903 ***/
   // user_pref("toolkit.winRegisterApplicationRestart", false);

/******************************* Геолокация ***********************************/

// Не используйте эту секцию без присмотра взрослых

/*** [SECTION 0200]: GEOLOCATION ***/
// 0201: disable Location-Aware Browsing
   // user_pref("geo.enabled", false);
// 0202: disable GeoIP-based search results ***/
   // user_pref("browser.search.region", "US"); // [HIDDEN PREF]
   // user_pref("browser.search.geoip.url", "");
/* 0205: set Firefox language [FF59+] [RESTART]
 * Go to the end of about:support to view Internationalization & Localization
 * settings If set to empty, the OS locales are used. If not set at all, default
 * locale is used. This is the language used in menus, about pages, messages,
 * and notifications from Firefox ***/
   // user_pref("intl.locale.requested", "en-US"); // [HIDDEN PREF]
/* 0206: disable geographically specific results/search engines
 * e.g. "browser.search.*.US"
 * i.e. ignore all of Mozilla's various search engines in multiple locales ***/
   // user_pref("browser.search.geoSpecificDefaults", false);
   // user_pref("browser.search.geoSpecificDefaults.url", "");
/* 0207: set preferred language for diplaying web pages [TEST] ***/
   // user_pref("intl.accept_languages", "en-US, en");
/* 0208: enforce US English locale regardless of the system locale ***/
   // user_pref("javascript.use_us_english_locale", true); // [HIDDEN PREF]
/* 0209: use APP locale over OS locale in regional preferences [FF56+] ***/
   // user_pref("intl.regional_prefs.use_os_locales", false);
/* 0210: use Mozilla geolocation service instead of Google when geolocation is
 * enabled. Optionally enable logging to the console (defaults to false) ***/
   // user_pref("geo.wifi.uri", "https://location.services.mozilla.com/v1/geolocate?key=%MOZILLA_API_KEY%");
   // user_pref("geo.wifi.logging.enabled", true); // [HIDDEN PREF]
/* 0211: disable using the OS's geolocation service ***/
   // user_pref("geo.provider.ms-windows-location", false); // [WINDOWS]

/***************************** FINGERPRINTING *********************************/

/* Позволять ли сайтам определять установленные шрифты
 * По шрифтам и их количеству можно идентифицировать пользователя
 /* 0 - нет, 1 - да. 0 - ломает отображение сайтов. ***/
   // user_pref("browser.display.use_document_fonts", 0);

/*** [SECTION 2500]: HARDWARE FINGERPRINTING ***/
/* Секция позволяет отключить передачу информации о некотором вашем железе,
 * но может поломать функционал некоторых специфических сайтов ***/
/* 2502: disable Battery Status API
 * Initially a Linux issue (high precision readout) that was fixed.
 * However, it is still another metric for fingerprinting, used to raise entropy.
 * e.g. do you have a battery or not, current charging status, charge level, times remaining etc
 * [NOTE] From FF52+ Battery Status API is only available in chrome/privileged code. ***/
   // user_pref("dom.battery.enabled", false);
/* 2504: disable virtual reality devices
 * Optional protection depending on your connected devices ***/
   // user_pref("dom.vr.enabled", false);
/* 2505: disable media device enumeration [FF29+]
 * [NOTE] media.peerconnection.enabled should also be set to false (see 2001) ***/
   // user_pref("media.navigator.enabled", false);
/* 2508: disable hardware acceleration to reduce graphics fingerprinting [SETUP-HARDEN]
 * [WARNING] Affects text rendering (fonts will look different), impacts video performance,
 * and parts of Quantum that utilize the GPU will also be affected as they are rolled out
 * [SETTING] General>Performance>Custom>Use hardware acceleration when available ***/
   // user_pref("gfx.direct2d.disabled", true); // [WINDOWS]
   // user_pref("layers.acceleration.disabled", true);
// 2510: disable Web Audio API [FF51+]
   // user_pref("dom.webaudio.enabled", false);
/* 2517: disable Media Capabilities API [FF63+]
 * [WARNING] This *may* affect media performance if disabled, no one is sure ***/
   // user_pref("media.media-capabilities.enabled", false);

/*** [SECTION 4500]: RFP (RESIST FINGERPRINTING) ***/
/* 4501: enable privacy.resistFingerprinting [FF41+]
 * This pref is the master switch for all other privacy.resist* prefs unless stated
 * [SETUP-WEB] RFP can cause the odd website to break in strange ways, and has a few side affects,
 * but is largely robust nowadays. Give it a try. Your choice. Also see 4504 (letterboxing). ***/
   // user_pref("privacy.resistFingerprinting", true);
/* 4502: set new window sizes to round to hundreds [FF55+] [SETUP-CHROME]
 * Width will round down to multiples of 200s and height to 100s, to fit your screen.
 * The override values are a starting point to round from if you want some control ***/
   // user_pref("privacy.window.maxInnerWidth", 1000);
   // user_pref("privacy.window.maxInnerHeight", 1000);
/* 4503: disable mozAddonManager Web API [FF57+]
 * [NOTE] На FF60+ cовместно с (2662) заставит работать расширения на AMO и т.п.
 * привилегированных страницах. Например переводчики. В итоге функционал удаления,
 * поломается и кнопка усановки на AMO всегда бедет в состоянии "Установить...". ***/
   // user_pref("privacy.resistFingerprinting.block_mozAddonManager", true); // [HIDDEN PREF]
/* 4504: enable RFP letterboxing [FF67+]
 * Dynamically resizes the inner window (FF67; 200w x100h: FF68+; stepped ranges) by applying letterboxing,
 * using dimensions which waste the least content area, If you use the dimension pref, then it will only apply
 * those resolutions. The format is "width1xheight1, width2xheight2, ..." (e.g. "800x600, 1000x1000, 1600x900")
 * [SETUP-WEB] This does NOT require RFP (see 4501) **for now**, so if you're not using 4501, or you are but you're
 * not taking anti-fingerprinting seriously and a little visual change upsets you, then feel free to flip this pref
 * [WARNING] The dimension pref is only meant for testing, and we recommend you DO NOT USE it ***/
   // user_pref("privacy.resistFingerprinting.letterboxing", true); // [HIDDEN PREF]
   // user_pref("privacy.resistFingerprinting.letterboxing.dimensions", ""); // [HIDDEN PREF]
/* 4510: ускорение загрузки about:blank [FF60+]
 * отключает стробоскоп (вспышку белого) при старте браузера или загрузке страницы ***/
user_pref("browser.startup.blankWindow", false);

/************************************ END *************************************/

/*** [SECTION 5000]: PERSONAL ***/
/* WELCOME & WHAT's NEW NOTICES ***/
   // user_pref("browser.startup.homepage_override.mstone", "ignore"); // master switch
   // user_pref("startup.homepage_welcome_url", "");
   // user_pref("startup.homepage_welcome_url.additional", "");
   // user_pref("startup.homepage_override_url", ""); // What's New page after updates
/* WARNINGS ***/
   // user_pref("browser.tabs.warnOnClose", false);
   // user_pref("browser.tabs.warnOnCloseOtherTabs", false);
   // user_pref("browser.tabs.warnOnOpen", false);
   // user_pref("full-screen-api.warning.delay", 0);
   // user_pref("full-screen-api.warning.timeout", 0);
   // user_pref("general.warnOnAboutConfig", false);
   // user_pref("browser.aboutConfig.showWarning", false); // [FF67+]
/* APPEARANCE ***/
   // user_pref("browser.download.autohideButton", false); // [FF57+]
   // user_pref("toolkit.cosmeticAnimations.enabled", false); // [FF55+]
/* CONTENT BEHAVIOR ***/
   // user_pref("accessibility.typeaheadfind", true); // enable "Find As You Type"
   // user_pref("clipboard.autocopy", false); // disable autocopy default [LINUX]
   // user_pref("layout.spellcheckDefault", 2); // 0=none, 1-multi-line, 2=multi-line & single-line
/* UX BEHAVIOR ***/
   // user_pref("browser.backspace_action", 2); // 0=previous page, 1=scroll up, 2=do nothing
   // user_pref("general.autoScroll", false); // middle-click enabling auto-scrolling [WINDOWS] [MAC]
   // user_pref("ui.key.menuAccessKey", 0); // disable alt key toggling the menu bar [RESTART]
   // user_pref("view_source.tab", false); // view "page/selection source" in a new window [FF68+, FF59 and under]
/* OTHER ***/
   // user_pref("browser.bookmarks.max_backups", 2);
   // user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.addons", false); // disable CFR [FF67+]
      // [SETTING] General>Browsing>Recommend extensions as you browse
   // user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.features", false); // disable CFR [FF67+]
      // [SETTING] General>Browsing>Recommend features as you browse
   // user_pref("identity.fxaccounts.enabled", false); // disable and hide Firefox Accounts and Sync [FF60+] [RESTART]
   // user_pref("network.manage-offline-status", false); // see bugzilla 620472
   // user_pref("reader.parse-on-load.enabled", false); // "Reader View"
   // user_pref("xpinstall.signatures.required", false); // enforced extension signing (Nightly/ESR)

/************************************* TEMP ***********************************/
// FF68
// 0105b: disable Activity Stream Snippets
   // [-] https://bugzilla.mozilla.org/1540939
user_pref("browser.aboutHomeSnippets.updateUrl", "");
user_pref("browser.newtabpage.activity-stream.disableSnippets", true);
// 0307: disable auto updating of lightweight themes (LWT)
   // Not to be confused with themes in 0301* + 0302*, which use the FF55+ Theme API
   // Mozilla plan to convert existing LWTs and remove LWT support in the future, see [1]
   // [1] https://blog.mozilla.org/addons/2018/09/20/future-themes-here/
   // [-] (part3b) https://bugzilla.mozilla.org/1525762
user_pref("lightweightThemes.update.enabled", false);
// 2682: enable CSP 1.1 experimental hash-source directive [FF29+]
   // [1] https://bugzilla.mozilla.org/buglist.cgi?bug_id=855326,883975
   // [-] https://bugzilla.mozilla.org/1386214
user_pref("security.csp.experimentalEnabled", true);
// * * * /
/************************************* END ************************************/
