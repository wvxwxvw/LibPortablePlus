/******
* Нумерация, если есть, соответствует ghacks user.js v. 26 June 2019
* url: https://github.com/ghacksuserjs/ghacks-user.js
* 
* Разделение по секциям условное.
* 
* При удалении параметра не забудьте сбросить его about:config
******/

/********************** Отключение всяких автообновлений ********************/

// 0301a: disable auto-update checks for Firefox
// [SETTING] General>Firefox Updates>Never check for updates
user_pref("app.update.enabled", false);
// 0000: ??? Обновление через службу Windows ??? ESR ???
user_pref("app.update.BITS.enabled", false);
// 0301b: disable auto-CHECKING for extension and theme updates
user_pref("extensions.update.enabled", false);
// 0302a: disable auto-INSTALLING Firefox updates
user_pref("app.update.auto", false);
// 0302b: disable auto-INSTALLING extension and theme updates (after the check in 0301b)
user_pref("extensions.update.autoUpdateDefault", false);
// 0308: disable search update
user_pref("browser.search.update", false);
// 0505: disable System Add-on updates
user_pref("extensions.systemAddon.update.enabled", false);
user_pref("extensions.systemAddon.update.url", "");

/****** Отключение всяких Crash Reports, Telemetry and Recommendations ******/

// 0105a: disable Activity Stream telemetry
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry.ping.endpoint", "");
user_pref("browser.newtabpage.activity-stream.telemetry", false);
// 0105b: disable Activity Stream Snippets
user_pref("browser.newtabpage.activity-stream.asrouter.providers.snippets", "");
user_pref("browser.newtabpage.activity-stream.feeds.snippets", false);
// 0105c: disable Activity Stream Top Stories, Pocket-based and/or sponsored content
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false); // [FF66+]
// 0309: disable sending Flash crash reports
user_pref("dom.ipc.plugins.flash.subprocess.crashreporter.enabled", false);
// 0310: disable sending the URL of the website where a plugin crashed
user_pref("dom.ipc.plugins.reportCrashURL", false);
// 0320: disable about:addons' Recommendations pane (uses Google Analytics)
user_pref("extensions.getAddons.showPane", false); // [HIDDEN PREF]
user_pref("extensions.webservice.discoverURL", "");
// 0321: disable recommendations in about:addons'
user_pref("extensions.getAddons.discovery.api_url", "");
user_pref("extensions.htmlaboutaddons.discover.enabled", false);
user_pref("extensions.htmlaboutaddons.recommendations.enabled", false);
/* 0330: disable telemetry
 * the pref (.unified) affects the behaviour of the pref (.enabled)
 * IF unified=false then .enabled controls the telemetry module
 * IF unified=true then .enabled ONLY controls whether to record extended data
 * so make sure to have both set as false ***/
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.enabled", false);
user_pref("toolkit.telemetry.server", "data:,");
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false);
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false);
user_pref("toolkit.telemetry.updatePing.enabled", false);
user_pref("toolkit.telemetry.bhrPing.enabled", false);
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false);
user_pref("toolkit.telemetry.hybridContent.enabled", false);
// 0331: disable Telemetry Coverage (search)
user_pref("toolkit.telemetry.coverage.opt-out", true); // [HIDDEN PREF]
user_pref("toolkit.coverage.opt-out", true); // [FF64+] [HIDDEN PREF]
user_pref("toolkit.coverage.endpoint.base", "");
// 0340: disable Health Reports
user_pref("datareporting.healthreport.uploadEnabled", false);
// 0341: disable new data submission, master kill switch
user_pref("datareporting.policy.dataSubmissionEnabled", false);
// 0350: disable Crash Reports
user_pref("breakpad.reportURL", "");
user_pref("browser.tabs.crashReporting.sendReport", false);
user_pref("browser.crashReports.unsubmittedCheck.enabled", false);
// 0351: disable backlogged Crash Reports
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit", false);
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false);
/* 0370: disable Pocket [FF46+]
 * Pocket is a third party "save for later" cloud service ***/
   // user_pref("extensions.pocket.enabled", false);
// 0390: disable Captive Portal detection
user_pref("captivedetect.canonicalURL", "");
user_pref("network.captive-portal-service.enabled", false); // [FF52+]
// 0503: disable Normandy/Shield [FF60+] telemetry system (incl. Heartbeat)
user_pref("app.normandy.api_url", "");
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.first_run", false);
// 0506: disable PingCentre telemetry Currently blocked (see 0340)
user_pref("browser.ping-centre.telemetry", false);
user_pref("browser.ping-centre.production.endpoint", "");
user_pref("browser.ping-centre.staging.endpoint", "");
// 1204: disable SSL Error Reporting
user_pref("security.ssl.errorReporting.automatic", false);
user_pref("security.ssl.errorReporting.enabled", false);
user_pref("security.ssl.errorReporting.url", "");

/***************************** Внешний вид и поведение ************************/

// [FF68+] allow userChrome/userContent
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

/* 2604: отключить создание thumbnail в папке профиля ***/
   // user_pref("browser.pagethumbnails.capturing_disabled", true); // [HIDDEN PREF]

/********************************** Плагины ***********************************/

// EME-free - удалить если пользуетесь кодеком EME
user_pref("app.partner.mozilla-EMEfree", "mozilla-EMEfree");
// EME-free - переключить если пользуетесь кодеком EME
/* 1825: disable widevine CDM (Content Decryption Module)
 * Switch if you *need* CDM, e.g. Netflix, Amazon Prime, Hulu, whatever ***/
user_pref("media.gmp-widevinecdm.visible", false);
user_pref("media.gmp-widevinecdm.enabled", false);
// 1830: disable all DRM content (EME: Encryption Media Extension)
user_pref("browser.eme.ui.enabled", false);
user_pref("media.eme.enabled", false);

// OpenH264 - переключить если НЕ пользуетесь кодеком OpenH264
user_pref("media.gmp-gmpopenh264.enabled", true);
/* Если переключить, то кодек вообще удалится из профиля и about:addons
 * При обратном включении зайдите в about:addons в плагины и обновите его
 * Firefox загрузит его за десяток секунд, размер кодека чуть меньше 1Мб ***/
user_pref("media.gmp-gmpopenh264.visible", true);

