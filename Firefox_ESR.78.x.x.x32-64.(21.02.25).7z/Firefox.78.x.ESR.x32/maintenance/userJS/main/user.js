/******
* Нумерация, если есть, соответствует ghacks user.js
* date: 21 Jul 2020
* version 78

* url: https://github.com/ghacksuserjs/ghacks-user.js

* При удалении параметра не забудьте сбросить его в about:config

       Подсказка: ищите и читайте теги "[SETUP]", при необходимости измените преф
       (или закомментируйте его и сбросьте в about:config). Вот основные теги:
       [SETUP-SECURITY] это один пункт, прочтите его
            [SETUP-WEB] может привести к поломке некоторых сайтов
         [SETUP-CHROME] изменяет поведение самого Firefox (не веб-сайта)
           [SETUP-PERF] может повлиять на производительность
         [SETUP-HARDEN] используйте Tor и не страдайте (удалил все)
     * [WARNING] теги важные и используются редко, так что следите за ними
        * [ПРИМ] мои примечания

* INDEX:

  0100: STARTUP
  0200: GEOLOCATION / LANGUAGE / LOCALE
  0300: QUIET FOX
  0400: BLOCKLISTS / SAFE BROWSING
  0500: SYSTEM ADD-ONS / EXPERIMENTS
  0600: BLOCK IMPLICIT OUTBOUND
  0700: HTTP* / TCP/IP / DNS / PROXY / SOCKS etc
  0800: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS
  0900: PASSWORDS
  1000: CACHE / SESSION (RE)STORE / FAVICONS
  1200: HTTPS (SSL/TLS / OCSP / CERTS / HPKP / CIPHERS)
  1400: FONTS
  1600: HEADERS / REFERERS
  1700: CONTAINERS
  1800: PLUGINS
  2000: MEDIA / CAMERA / MIC
  2200: WINDOW MEDDLING & LEAKS / POPUPS
  2300: WEB WORKERS
  2400: DOM (DOCUMENT OBJECT MODEL) & JAVASCRIPT
  2500: HARDWARE FINGERPRINTING
  2600: MISCELLANEOUS
  2700: PERSISTENT STORAGE
  2800: SHUTDOWN
  4000: FPI (FIRST PARTY ISOLATION)
  4500: RFP (RESIST FINGERPRINTING)
  4600: RFP ALTERNATIVES
  4700: RFP ALTERNATIVES (NAVIGATOR / USER AGENT (UA) SPOOFING)
  5000: PERSONAL
  9999: DEPRECATED / REMOVED / LEGACY / RENAMED
  ----: ДРУГОЕ

******/

// START: internal custom pref to test for syntax errors
user_pref("_user.js.parrot", "ФИАСКО! user.js загружен не полностью, из-за синтаксической ошибки в нем.");

// 0000: отключить предупреждение при входе в about:config
user_pref("general.warnOnAboutConfig", false); // XUL/XHTML version
user_pref("browser.aboutConfig.showWarning", false); // HTML version [FF71+]

/*** [SECTION 0100]: STARTUP ***/
user_pref("_user.js.parrot", "0100 syntax error: the parrot's dead!");
/* 0101: disable default browser check
 * [SETTING] General>Startup>Always check if Firefox is your default browser ***/
user_pref("browser.shell.checkDefaultBrowser", false);
// 0105a: disable Activity Stream telemetry
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry", false);
/* 0105b: disable Activity Stream Snippets
 * Запускает код с сервера (Remote Code Execution) и отправляет информацию обратно на сервер ***/
user_pref("browser.newtabpage.activity-stream.feeds.snippets", false);
user_pref("browser.newtabpage.activity-stream.asrouter.providers.snippets", "");
// 0105c: disable Activity Stream Top Stories, Pocket-based and/or sponsored content
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false); // [FF66+]
// 0105d: disable Activity Stream recent Highlights in the Library [FF57+]
   // user_pref("browser.library.activity-stream.enabled", false);
/* 0105e: clear default topsites
 * [NOTE] Это не мешает вам добавлять свои собственные ***/
user_pref("browser.newtabpage.activity-stream.default.sites", "");

/*** [SECTION 0200]: GEOLOCATION / LANGUAGE / LOCALE ***/
user_pref("_user.js.parrot", "0200 syntax error: the parrot's definitely deceased!");
/*** GEOLOCATION ***/

/* 0203: использовать сервис геолокации Mozilla вместо Google, когда геолокация включена [FF74+]
 * При желании включите запись в консоль, второй преф (defaults to false) ***/
user_pref("geo.provider.network.url", "https://location.services.mozilla.com/v1/geolocate?key=%MOZILLA_API_KEY%");
   // user_pref("geo.provider.network.logging.enabled", true); // [HIDDEN PREF]
// 0204: отключить использование сервиса геолокации ОС
user_pref("geo.provider.ms-windows-location", false); // [WINDOWS]
user_pref("geo.provider.use_corelocation", false); // [MAC]
user_pref("geo.provider.use_gpsd", false); // [LINUX]
/* 0206: отключить определение географиии поисковыми системами, например "browser.search.*.US"
 * [ПРИМ] это не мешает яндексу угадывать город нахождения ***/
user_pref("browser.search.geoSpecificDefaults", false);
user_pref("browser.search.geoSpecificDefaults.url", "");

/** LANGUAGE / LOCALE ***/
/* 0210: язык для отображения веб-страниц
 * [TEST] https://addons.mozilla.org/about ***/
   // user_pref("intl.accept_languages", "en-US, en");
/* 0211: применять US English независимо от языка системы
 * [SETUP-WEB] Может нарушить некоторые методы ввода  ***/
   // user_pref("javascript.use_us_english_locale", true); // [HIDDEN PREF]
/* 0212: применять резервную кодировку текста en-US
 * Если содержимое или сервер не объявляют кодировку, браузер использует язык
 * вашего приложения, здесь можно это переопределить
 * [TEST] https://hsivonen.com/test/moz/check-charset.htm ***/
   // user_pref("intl.charset.fallback.override", "windows-1252");

/*** [SECTION 0300]: QUIET FOX ***/
user_pref("_user.js.parrot", "0300 syntax error: the parrot's not pinin' for the fjords!");
// 0301b: disable auto-CHECKING for extension and theme updates
user_pref("extensions.update.enabled", false);
// 0302a: disable auto-INSTALLING Firefox updates [NON-WINDOWS FF65+]
user_pref("app.update.auto", false);
/* 0302b: disable auto-INSTALLING extension and theme updates (after the check in 0301b)
 * [SETTING] about:addons>Extensions>[cog-wheel-icon]>Update Add-ons Automatically (toggle) ***/
user_pref("extensions.update.autoUpdateDefault", false);
/* 0308: disable search engine updates (e.g. OpenSearch)
 * [NOTE] Это не влияет на встроенные поисковые системы Mozilla или веб-расширения ***/
user_pref("browser.search.update", false);
// 0309: disable sending Flash crash reports
user_pref("dom.ipc.plugins.flash.subprocess.crashreporter.enabled", false);
// 0310: disable sending the URL of the website where a plugin crashed
user_pref("dom.ipc.plugins.reportCrashURL", false);
// 0320: disable about:addons' Recommendations pane (uses Google Analytics)
user_pref("extensions.getAddons.showPane", false); // [HIDDEN PREF]
// 0321: disable recommendations in about:addons' Extensions and Themes panes [FF68+]
user_pref("extensions.htmlaboutaddons.recommendations.enabled", false);
/* 0330: disable telemetry
 * преф (.unified) влияет на поведение префа (.enabled)
 * IF unified=false then .enabled controls the telemetry module
 * IF unified=true then .enabled ONLY controls whether to record extended data
 * so make sure to have both set as false
 * [NOTE] FF58+ 'toolkit.telemetry.enabled' теперь ЗАБЛОКИРОВАН в prerelease
 * и release сборках (true и false соответственно) ***/
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.enabled", false); // see [NOTE] above FF58+
user_pref("toolkit.telemetry.server", "data:,");
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.updatePing.enabled", false); // [FF56+]
user_pref("toolkit.telemetry.bhrPing.enabled", false); // [FF57+] Background Hang Reporter
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false); // [FF57+]
// 0331: disable Telemetry Coverage
user_pref("toolkit.telemetry.coverage.opt-out", true); // [HIDDEN PREF]
user_pref("toolkit.coverage.opt-out", true); // [FF64+] [HIDDEN PREF]
user_pref("toolkit.coverage.endpoint.base", "");
/* 0340: disable Health Reports
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send technical... data ***/
user_pref("datareporting.healthreport.uploadEnabled", false);
// 0341: disable new data submission, master kill switch
user_pref("datareporting.policy.dataSubmissionEnabled", false);
/* 0342: disable Studies (see 0503)
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to install and run studies ***/
user_pref("app.shield.optoutstudies.enabled", false);
// 0350: disable Crash Reports
user_pref("breakpad.reportURL", "");
user_pref("browser.tabs.crashReporting.sendReport", false); // [FF44+]
user_pref("browser.crashReports.unsubmittedCheck.enabled", false); // [FF51+]
/* 0351: disable backlogged Crash Reports
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send backlogged crash reports  ***/
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false);
// 0390: disable Captive Portal detection
user_pref("captivedetect.canonicalURL", "");
user_pref("network.captive-portal-service.enabled", false); // [FF52+]
// 0391: disable Network Connectivity checks [FF65+]
user_pref("network.connectivity-service.enabled", false);

/*** [SECTION 0400]: BLOCKLISTS / SAFE BROWSING (SB) ***/
user_pref("_user.js.parrot", "0400 syntax error: the parrot's passed on!");
/** BLOCKLISTS ***/
/* 0401: enforce Firefox blocklist
 * [NOTE] Включает обновления для "отозванных сертификатов"
 * [1] https://blog.mozilla.org/security/2015/03/03/revoking-intermediate-certificates-introducing-onecrl/ ***/
user_pref("extensions.blocklist.enabled", true); // [DEFAULT: true]

/** SAFE BROWSING (SB)
    Safe Browsing предпринимает много шагов, чтобы сохранить конфиденциальность. Оставьте все без изменений.
    SBv4 (FF57+) даже куки не использует. (#В browser.safebrowsing.debug можно мониторить эту активность) ***/

/* 0412: disable SB checks for downloads (remote)
 * Чтобы проверить безопасность некоторых исполняемых файлов, Firefox отправляет
 * некоторую информацию о файле и его происхождении в службу Google Safe Browsing
 * [SETUP-SECURITY] Если вам нужна эта защита, то переключите ***/
user_pref("browser.safebrowsing.downloads.remote.enabled", false);
user_pref("browser.safebrowsing.downloads.remote.url", "");

/*** [SECTION 0500]: SYSTEM ADD-ONS / EXPERIMENTS

     Системные дополнения - это встроенные функции Firefox, которые не отображаются
     в about:addons. Чтобы просмотреть их, перейдите в about:support, они перечислены
     в разделе "Возможности Firefox"

     Некоторые из них не имеют префов включения-выключения. Но вы можете удалить их вручную.
     Обновления восстановят их. Они также могут восстановится автоматически (см. 0505)
     Находятся в * Portable: "...\core\browser\features\" 

     Префы отключения пунктов меню Pocket и аккаунта Firefox доступны в UX FEATURES (см. 5000) ***/
user_pref("_user.js.parrot", "0500 syntax error: the parrot's cashed in 'is chips!");
// 0503: disable Normandy/Shield [FF60+]
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.api_url", "");
// 0505: disable System Add-on updates
user_pref("extensions.systemAddon.update.enabled", false); // [FF62+]
user_pref("extensions.systemAddon.update.url", ""); // [FF44+]
/* 0506: disable PingCentre telemetry (used in several System Add-ons) [FF57+]
 * В настоящее время блокируется'datareporting.healthreport.uploadEnabled' (see 0340) ***/
user_pref("browser.ping-centre.telemetry", false);
// 0515: disable Screenshots
   // user_pref("extensions.screenshots.disabled", true); // [FF55+]
   // user_pref("extensions.screenshots.upload-disabled", true); // [FF60+]
/* 0517: disable Form Autofill
 * [NOTE] Сохраненные данные НЕ безопасны (используется файл JSON)
 * [NOTE] heuristics контролирует автозаполнение в формах без атрибутов @autocomplete
 * [SETTING] Privacy & Security>Forms and Autofill>Autofill addresses (FF74+) ***/
   // user_pref("extensions.formautofill.addresses.enabled", false); // [FF55+]
   // user_pref("extensions.formautofill.available", "off"); // [FF56+]
   // user_pref("extensions.formautofill.creditCards.enabled", false); // [FF56+]
   // user_pref("extensions.formautofill.heuristics.enabled", false); // [FF55+]
// 0518: disable Web Compatibility Reporter [FF56+]
user_pref("extensions.webcompat-reporter.enabled", false);

/*** [SECTION 0600]: BLOCK IMPLICIT OUTBOUND [not explicitly asked for - e.g. clicked on] ***/
user_pref("_user.js.parrot", "0600 syntax error: the parrot's no more!");
// 0601: disable link prefetching
user_pref("network.prefetch-next", false);
// 0602: disable DNS prefetching
user_pref("network.dns.disablePrefetch", true);
user_pref("network.dns.disablePrefetchFromHTTPS", true); // [HIDDEN PREF ESR] [DEFAULT: true FF70+]
// 0603: disable predictor, prefetching
user_pref("network.predictor.enabled", false);
user_pref("network.predictor.enable-prefetch", false); // [FF48+]
// 0605: disable link-mouseover opening connection to linked server
user_pref("network.http.speculative-parallel-limit", 0);
// 0606: disable "Hyperlink Auditing" (click tracking) and enforce same host in case
user_pref("browser.send_pings", false); // [DEFAULT: false]
user_pref("browser.send_pings.require_same_host", true);

/*** [SECTION 0700]: HTTP* / TCP/IP / DNS / PROXY / SOCKS etc ***/
user_pref("_user.js.parrot", "0700 syntax error: the parrot's given up the ghost!");
/* 0701: disable IPv6
 * IPv6 может злоупотреблять, особенно в отношении MAC-адресов
 * [STATS] телеметрия Firefox за июнь 2020 показывает, что только 5% всех подключений
 * используют IPv6 ***/
user_pref("network.dns.disableIPv6", true);
/* 0703: disable HTTP Alternative Services [FF37+]
 * [SETUP-PERF] Предотвращает возможность внешнего сканирования портов доступных вам ресурсов.
 * Так же защищено если FPI enabled (see 4000) ***/
user_pref("network.http.altsvc.enabled", false);
user_pref("network.http.altsvc.oe", false);
// 0704: при использовании SOCKS проксировать DNS-запросы,
user_pref("network.proxy.socks_remote_dns", true);
// 0708: disable FTP [FF60+]
   // user_pref("network.ftp.enabled", false);
/* 0709: disable using UNC (Uniform Naming Convention) paths [FF61+]
 * [SETUP-CHROME] Может сломать расширения с профилями на сетевых ресурсах ***/
   // user_pref("network.file.disable_unc_paths", true); // [HIDDEN PREF]
/* 0710: disable GIO as a potential proxy bypass vector
 * Gvfs/GIO has a set of supported protocols like obex, network, archive, computer, dav, cdda,
 * gphoto2, trash, etc. By default only smb and sftp protocols are accepted so far (as of FF64) ***/
user_pref("network.gio.supported-protocols", ""); // [HIDDEN PREF]

/*** [SECTION 0800]: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS ***/
user_pref("_user.js.parrot", "0800 syntax error: the parrot's ceased to be!");
/* 0801: отключить поиск по enter в адресной строке
 * При вводе или вставке URL он отправляется на сервер поисковика по умолчанию.
 * Examples: "secretplace,com", "secretplace/com", "secretplace com", "secret place.com"
 * [NOTE] Это не влияет на использование кнопок поиска в выпадающем списке
 * или использование ключей, настроенных в настройках (например, "d" для DuckDuckGo)
 * [SETUP-CHROME] Если вы не вводите или редко вводите URL-адреса и используете приватный
 * поисковик, то преф возможно вам не нужен ***/
   // user_pref("keyword.enabled", false);
/* 0802: disable location bar domain guessing
 * Отключить угадывание домена (www, .com и т.п.)
 * Приводит к ошибкам переходов, лишним подключениям и утечке данных ***/
user_pref("browser.fixup.alternate.enabled", false);
// 0803: отображать все части URL в адресной строке
user_pref("browser.urlbar.trimURLs", false);
/* 0805: отключить раскраску посещенных ссылок - CSS утечка истории
 * [NOTE] Это НИКОГДА не было полностью "решено". В Mozilla/docs указано,что это
 * только при "определенных обстоятельствах", также см. Последние комментарии в [2]
 * [TEST] https://earthlng.github.io/testpages/visited_links.html
 * [1] https://dbaron.org/mozilla/visited-privacy
 * [2] https://bugzilla.mozilla.org/147777
 * [3] https://developer.mozilla.org/docs/Web/CSS/Privacy_and_the_:visited_selector ***/
   // user_pref("layout.css.visited_links_enabled", false);
/* 0807: отключить предложения при поиске в строках адреса и поиска
 * [NOTE] Оба должны быть true для живого поиска
 * [SETUP-CHROME] при постоянном использовании приватной поисковой системы, не очень актуально
 * [SETTING] Search>Provide search suggestions | Show search suggestions in address bar results ***/
   // user_pref("browser.search.suggest.enabled", false);
   // user_pref("browser.urlbar.suggest.searches", false);
// 0809: отключить топ предзагруженных сайтой в адресной строке [FF54+]
user_pref("browser.urlbar.usepreloadedtopurls.enabled", false);
// 0810: отключить спекулятивные соединения строки адреса [FF56+]
user_pref("browser.urlbar.speculativeConnect.enabled", false);
/* 0811: отключить утечку отдельных слов из адресной строки на DNS **после поиска** [FF78+]
 * 0=never resolve single words, 1=heuristic (default), 2=always resolve
 * [NOTE] Для FF78 значения 1 и 2 одинаковы и всегда разрешаются, но это изменится в будущем ***/
user_pref("browser.urlbar.dnsResolveSingleWordsAfterSearch", 0);
/* 0850a: отключить типы подсказок в адресной строке
 * [SETTING] Privacy & Security>Address Bar>When using the address bar, suggest ***/
   // user_pref("browser.urlbar.suggest.history", false);
   // user_pref("browser.urlbar.suggest.bookmark", false);
   // user_pref("browser.urlbar.suggest.openpage", false);
   // user_pref("browser.urlbar.suggest.topsites", false); // [FF78+]
// 0850c: disable location bar dropdown
   // user_pref("browser.urlbar.maxRichResults", 0);
// 0850d: отключить автозаполнение строки адреса
   // user_pref("browser.urlbar.autoFill", false);
/* 0860: отключить историю поиска и форм
 * [SETUP-WEB] автозаполняемые формы могут быть прочитаны третьими лицами
 * [NOTE] как очистить formdata при выходе (см. 2803)
 * [SETTING] Privacy & Security>History>Custom Settings>Remember search and form history ***/
   // user_pref("browser.formfill.enable", false);
/* 0862: disable browsing and download history
 * [NOTE] как очистить историю при выходе (см. 2803)
 * [SETTING] Privacy & Security>History>Custom Settings>Remember browsing and download history ***/
   // user_pref("places.history.enabled", false);
// 0870: отключить список переходов в панели задач Windows [WINDOWS]
   // user_pref("browser.taskbar.lists.enabled", false);
   // user_pref("browser.taskbar.lists.frequent.enabled", false);
   // user_pref("browser.taskbar.lists.recent.enabled", false);
   // user_pref("browser.taskbar.lists.tasks.enabled", false);
// 0871: отключить предпросмотр в панели задач Windows [WINDOWS]
   // user_pref("browser.taskbar.previews.enable", false);

/*** [SECTION 0900]: PASSWORDS ***/
user_pref("_user.js.parrot", "0900 syntax error: the parrot's expired!");
/* 0901: disable saving passwords
 * [NOTE] Это не очищает уже сохраненные пароли
 * [SETTING] Privacy & Security>Logins and Passwords>Ask to save logins and passwords for websites ***/
   // user_pref("signon.rememberSignons", false);
/* 0902: использовать мастер-пароль
 * Устанавливается в настройках.
 * [SETTING] Privacy & Security>Logins and Passwords>Use a master password
 * [1] https://support.mozilla.org/kb/use-master-password-protect-stored-logins ***/
/* 0903: как часто Firefox должен запрашивать мастер-пароль
 * 0=the first time (default), 1=every time it's needed, 2=every N minutes (see 0904) ***/
   // user_pref("security.ask_for_password", 2);
// 0904: значение в минутах для (0903), по умолчанию 30
   // user_pref("security.password_lifetime", 5);
/* 0905: disable auto-filling username & password form fields
 * отключить автозаполнение полей имени и пароля
 * [NOTE] Имя и пароль остаются доступны при фокусе в поле ввода
 * [SETTING] Privacy & Security>Logins and Passwords>Autofill logins and passwords ***/
user_pref("signon.autofillForms", false);
// 0909: отключить захват формы для Менеджера паролей [FF51+]
   // user_pref("signon.formlessCapture.enabled", false);
/* 0912: ограничить (или отключить) диалоги учетных данных HTTP-аутентификации,
 * запускаемые субресурсами [FF41+], усиливает защиту от фишинга учетных данных
 * 0=не разрешать субресурсам
 * 1=не разрешать субдресурсам другого происхождения
 * 2=разрешать субресурсам (default) ***/
user_pref("network.auth.subresource-http-auth-allow", 1);

/*** [SECTION 1000]: CACHE / SESSION (RE)STORE / FAVICONS 
     Методы снятия отпечатков [1] [2] [3] требуют наличия кэша.
     Отключение дискового кэша (1001) *и возможно* кэша в памяти (1003) - это одно из решений.
     Но настройка временных контейнеров эффективнее [4].

     Мы рекомендуем избегать дискового кэша (1001), что бы кэш был только для сеанса и только в памяти.
     И настроить First Party Isolation (4001), это обеспечит баланс между риском и производительностью.
     ETAGs также можно нейтрализовать измением заголовков ответов [5] и настройкой очистки кэша по времени
     или вручную.

     [1] https://en.wikipedia.org/wiki/HTTP_ETag#Tracking_using_ETags
     [2] https://robertheaton.com/2014/01/20/cookieless-user-tracking-for-douchebags/
     [3] https://www.grepular.com/Preventing_Web_Tracking_via_the_Browser_Cache
     [4] https://medium.com/@stoically/enhance-your-privacy-in-firefox-with-temporary-containers-33925cd6cd21
     [5] https://github.com/ghacksuserjs/ghacks-user.js/wiki/4.2.4-Header-Editor ***/
user_pref("_user.js.parrot", "1000 syntax error: the parrot's gone to meet 'is maker!");
/** CACHE ***/
/* 1001: disable disk cache
 * [SETUP-PERF] Если вы думаете, что дисковый кэш реально может помочь (тяжелые сайты,
 * HD video), и используете временные контейнеры, то можете переключить это
 * [NOTE] очистка кэша при выходе (see 2803) ***/
user_pref("browser.cache.disk.enable", false);
/* 1003: memory cache
 * capacity: -1=determine dynamically (default), 0=none, n=memory capacity in kilobytes ***/
user_pref("browser.cache.memory.enable", true);
   // user_pref("browser.cache.memory.capacity", 0); // [HIDDEN PREF ESR]
/* 1006: disable permissions manager from writing to disk [RESTART]
 * [NOTE] любые изменения разрешений будут только для текущего сеанса ***/
   // user_pref("permissions.memory_only", true); // [HIDDEN PREF]
/* 1007: disable media cache from writing to disk in Private Browsing
 * [NOTE] MSE (Media Source Extensions) are already stored in-memory in PB ***/
user_pref("browser.privatebrowsing.forceMediaMemoryCache", true); // [FF75+]
user_pref("media.memory_cache_max_size", 16384);

/** SESSIONS & SESSION RESTORE ***/
/* 1021: disable storing extra session data [SETUP-CHROME]
 * укажите для каких сайтов сохранять дополнительные данные в сессии
 * содержимое форм, позиция прокрутки, cookie и данные POST:
 * 0=everywhere, 1=unencrypted sites, 2=nowhere ***/
   // user_pref("browser.sessionstore.privacy_level", 2);
// 1022: отключить возобновление сеанса после сбоя
   // user_pref("browser.sessionstore.resume_from_crash", false);
/* 1023: минимальный интервал между сохранениями сеанса
 * Увеличение может помочь на старых машинах и уменьшит запись на диск.
 * Default is 15000 (15 secs). Try 30000 (30 secs), 60000 (1 min) etc
 * [SETUP-CHROME] Это также может повлиять на запись "недавно закрытых вкладок":
 * быстро открытая и закрытая вкладка не успеет записаться ***/
   // user_pref("browser.sessionstore.interval", 1200000);
   // user_pref("browser.sessionstore.interval.idle", 6000000);
/* 1024: disable automatic Firefox start and session restore after reboot [FF62+] [WINDOWS]
 * отключить автозапуск Firefox и восстановление сеанса после перезагрузки системы ***/
   // user_pref("toolkit.winRegisterApplicationRestart", false);

/*** [SECTION 1200]: HTTPS (SSL/TLS / OCSP / CERTS / HPKP / CIPHERS) ***/
user_pref("_user.js.parrot", "1200 syntax error: the parrot's a stiff!");
/** SSL (Secure Sockets Layer) / TLS (Transport Layer Security) ***/
/* 1201: require safe negotiation
 * Блокирует соединения с серверами, которые не поддерживают RFC 5746 [2], поскольку они
 * потенциально уязвимы для атаки MiTM [3]. Сервер *без* RFC 5746 может быть защищен от атаки
 * если он отключает повторные переговоры, но проблема в том, что браузер не может этого знать.
 * Установка этого pref в true-единственный способ для браузера гарантировать, что не будет
 * никаких небезопасных повторных переговоров на канале между браузером и сервером.
 * [1] https://wiki.mozilla.org/Security:Renegotiation
 * [2] https://tools.ietf.org/html/rfc5746
 * [3] https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2009-3555
 * [ПРИМ] Проверьте на ваших постоянных сайтах и переключите при проблемах доступа. ***/
user_pref("security.ssl.require_safe_negotiation", true);
/* 1204: disable SSL session tracking [FF36+]
 * ID SSL сеанса уникальны, сохраняются до 24 часов и могут использоваться для отслеживания
 * [SETUP-PERF] FPI (см. 4000) вроде как изолирует их ***/
user_pref("security.ssl.disable_session_identifiers", true); // [HIDDEN PREF]
// 1205: disable SSL Error Reporting
user_pref("security.ssl.errorReporting.automatic", false);
user_pref("security.ssl.errorReporting.enabled", false);
user_pref("security.ssl.errorReporting.url", "");

/** OCSP (Online Certificate Status Protocol)
    #Required reading [#] https://scotthelme.co.uk/revocation-is-broken/ ***/
// 1210: enable OCSP Stapling
user_pref("security.ssl.enable_ocsp_stapling", true);
/* 1211: контроль использования OCSP выборки (для подтверждения текущего действия сертификатов)
 * 0=disabled, 1=enabled (default), 2=enabled for EV certificates only
 * OCSP (не сшитый) пропускает информацию о сайтах которые вы посещаете в CA (центр сертификации)
 * Это компромисс между безопасностью (проверка) и конфиденциальностью (утечка информации в CA)
 * [NOTE] Этот преф управляет только выборкой OCSP и не влияет на сшивание OCSP
 * [1] https://en.wikipedia.org/wiki/Ocsp ***/
user_pref("security.OCSP.enabled", 1);
/* 1212: set OCSP fetch failures (non-stapled, see 1211) to hard-fail [SETUP-WEB]
 * Когда нет доступа к центру сертификации, Firefox просто продолжает соединение (=soft-fail)
 * Установка этого префа в true заставит Firefox разорвать соединение (=hard-fail)
 * Soft-fail не имеет смысла при сбое связи OCSP: вы не знаете действителен ли сертификат или
 * отозван, или вы атакованы (злонамеренная блокировка серверов OCSP).
 * [ПРИМ] Если включен, то возможно мешает префу network.trr.mode=3 ***/
   // user_pref("security.OCSP.require", true);

/** CERTS / HPKP (HTTP Public Key Pinning) ***/
/* 1221: disable Windows 8.1's Microsoft Family Safety cert [FF50+] [WINDOWS]
 * 0=disable detecting Family Safety mode and importing the root
 * 1=only attempt to detect Family Safety mode (don't import the root)
 * 2=detect Family Safety mode and import the root ***/
user_pref("security.family_safety.mode", 0);
/* 1223: enforce strict pinning
 * PKP (Public Key Pinning) 0=disabled 1=allow user MiTM (such as your antivirus), 2=strict
 * [SETUP-WEB] Если вы полагаетесь на AV (антивирус) при проверке ВСЕГО веб-трафика,
 * то переключите значение на по умолчанию =1 ***/
user_pref("security.cert_pinning.enforcement_level", 2);

/** MIXED CONTENT ***/
// 1240: отключить небезопасный активный контент на страницах https
user_pref("security.mixed_content.block_active_content", true); // [DEFAULT: true]
// 1241: отключить небезопасный пассивный контент (например, изображения) на страницах https [SETUP-WEB]
   // user_pref("security.mixed_content.block_display_content", true);
// 1243: блокировать незашифрованные запросы от Flash на зашифрованных страницах
user_pref("security.mixed_content.block_object_subrequest", true);
/* 1244: включить режим только HTTPS [FF76+]
 * [NOTE] This is experimental
 * [1] https://bugzilla.mozilla.org/1613063 */
   // user_pref("dom.security.https_only_mode", true); // [FF76+]
   // user_pref("dom.security.https_only_mode.upgrade_local", true); // [FF77+]

/** UI (User Interface) ***/
// 1270: предупреждение на "замке" для "сломанной безопасности" (если 1201 = false)
user_pref("security.ssl.treat_unsafe_negotiation_as_broken", true);
/* 1271: диалог "добавить исключение безопасности" для предупреждений SSL
 * 0=do neither 1=pre-populate url 2=pre-populate url + pre-fetch cert (default) ***/
   // user_pref("browser.ssl_override_behavior", 1);
// 1272: display advanced information on Insecure Connection warning pages
user_pref("browser.xul.error_pages.expert_bad_cert", true);
// 1273: display "insecure" icon and "Not Secure" text on HTTP sites
user_pref("security.insecure_connection_icon.enabled", true); // [FF59+] [DEFAULT: true FF70+]
   // user_pref("security.insecure_connection_text.enabled", true); // [FF60+]

/*** [SECTION 1600]: HEADERS / REFERERS ***/
user_pref("_user.js.parrot", "1600 syntax error: the parrot rests in peace!");
/* 1601: ALL: control when images/links send a referer
 * когда и как изображениям и ссылкам отправлять реферер
 * 0=never, 1=send only when links are clicked, 2=for links and images (default) ***/
   // user_pref("network.http.sendRefererHeader", 1); // [DEFAULT: 2]
/* 1602: ALL: control the amount of information to send
 * объем отправляемой информации
 * 0=send full URI (default), 1=scheme+host+port+path, 2=scheme+host+port ***/
   // user_pref("network.http.referer.trimmingPolicy", 0); // [DEFAULT: 0]
/* 1603: CROSS ORIGIN: кому отправлять реферер
 * 0=always (default), 1=only if base domains match, 2=only if hosts match
 * [SETUP-WEB] Вызывает проблемы со старыми модемами/роутерами и некоторыми сайтами, например, vimeo, icloud. ***/
   // user_pref("network.http.referer.XOriginPolicy", 1);
/* 1604: CROSS ORIGIN: объем отправляемой информации [FF52+]
 * 0=send full URI (default), 1=scheme+host+port+path, 2=scheme+host+port ***/
   // user_pref("network.http.referer.XOriginTrimmingPolicy", 0); // [DEFAULT: 0]
// 1610: ALL: enable the DNT (Do Not Track) HTTP header
   // user_pref("privacy.donottrackheader.enabled", true);

/*** [SECTION 1800]: PLUGINS ***/
user_pref("_user.js.parrot", "1800 syntax error: the parrot's pushing up daisies!");
// 1803: disable Flash plugin
user_pref("plugin.state.flash", 0);
/* 1820: disable GMP (Gecko Media Plugins)
 * Больше см. в секции OpenH264 в конце файла ***/
user_pref("media.gmp-provider.enabled", false);
/* 1825: disable widevine CDM (Content Decryption Module)
 * [SETUP-WEB] if you *need* CDM, e.g. Netflix, Amazon Prime, Hulu, whatever ***/
user_pref("media.gmp-widevinecdm.visible", false);
user_pref("media.gmp-widevinecdm.enabled", false);
/* 1830: disable all DRM content (EME: Encryption Media Extension)
 * EME-free - переключить если пользуетесь кодеком
 * [SETUP-WEB] if you *need* EME, e.g. Netflix, Amazon Prime, Hulu, whatever
 * [SETTING] General>DRM Content>Play DRM-controlled content ***/
user_pref("media.eme.enabled", false);

/*** [SECTION 2000]: MEDIA / CAMERA / MIC ***/
user_pref("_user.js.parrot", "2000 syntax error: the parrot's snuffed it!");
/* 2001: disable WebRTC (Web Real-Time Communication)
 * [SETUP-WEB] WebRTC сливает налево ваш реальный IP-адрес под VPN и прокси.
 * false - cломает возможность общения в режиме реального времени ***/
user_pref("media.peerconnection.enabled", false);
/* 2002: limit WebRTC IP leaks if using WebRTC
 * In FF70+ these settings match Mode 4 (Mode 3 in older versions) (see [3])
 * [TEST] https://browserleaks.com/webrtc
 * [3] https://tools.ietf.org/html/draft-ietf-rtcweb-ip-handling-12#section-5.2 ***/
user_pref("media.peerconnection.ice.default_address_only", true);
user_pref("media.peerconnection.ice.no_host", true); // [FF51+]
user_pref("media.peerconnection.ice.proxy_only_if_behind_proxy", true); // [FF70+]
/* 2010: disable WebGL (Web Graphics Library)
 * [SETUP-WEB] Когда отключено, могут сломаться некоторые сайты. Включение дает
 * высокую энтропию, особенно с readPixels(). Также см. RFP (4501) ***/
user_pref("webgl.disabled", true);
user_pref("webgl.enable-webgl2", false);
// 2012: limit WebGL
user_pref("webgl.min_capability_mode", true);
user_pref("webgl.disable-fail-if-major-performance-caveat", true);
// 2022: disable screensharing
user_pref("media.getusermedia.screensharing.enabled", false);
user_pref("media.getusermedia.browser.enabled", false);
user_pref("media.getusermedia.audiocapture.enabled", false);
/* 2030: отключить, насколько это возможно, автозапуск мультимедиа HTML5 [FF63+]
 * 0=Allow all, 1=Block non-muted media (default in FF67+), 2=Prompt (removed in FF66), 5=Block all (FF69+)
 * [NOTE] Исключения можно установить в разрешениях для сайта
 * [SETTING] Privacy & Security>Permissions>Autoplay>Settings>Default for all websites ***/
user_pref("media.autoplay.default", 5);
/* 2031: disable autoplay of HTML5 media if you interacted with the site [FF78+]
 * 0=sticky (default), 1=transient, 2=user
 * [NOTE] Если у вас возникли проблемы с некоторыми видеосайтами, то добавьте исключение (see 2030)
 * [ПРИМ] Автор рекомендует 2, но тогда ломается воспроизведение на некоторых сайтах,
 * а исключения превращают такой сайт в нон-стоп шарманку ***/
user_pref("media.autoplay.blocking_policy", 1);

/*** [SECTION 2200]: WINDOW MEDDLING & LEAKS / POPUPS ***/
user_pref("_user.js.parrot", "2200 syntax error: the parrot's 'istory!");
// 2201: запретить веб-сайтам управление функциями НОВЫХ окон
   // user_pref("dom.disable_window_open_feature.close", true);
   // user_pref("dom.disable_window_open_feature.location", true); // [DEFAULT: true]
   // user_pref("dom.disable_window_open_feature.menubar", true);
   // user_pref("dom.disable_window_open_feature.minimizable", true);
   // user_pref("dom.disable_window_open_feature.personalbar", true); // bookmarks toolbar
   // user_pref("dom.disable_window_open_feature.resizable", true); // [DEFAULT: true]
   // user_pref("dom.disable_window_open_feature.status", true); // [DEFAULT: true]
   // user_pref("dom.disable_window_open_feature.titlebar", true);
   // user_pref("dom.disable_window_open_feature.toolbar", true);
// 2202: запретить скриптам перемещать и изменять размер ОТКРЫТЫХ окон
user_pref("dom.disable_window_move_resize", true);
/* 2203: открывать ссылки во вкладках, даже если они нацелены на новое окно
 * Это останавливает ресайз вредоносных окон и некоторые утечки разрешения экрана.
 * Вы все еще можете щелкнуть правой кнопкой мыши ссылку и открыть ее в новом окне.
 * [TEST] https://ghacksuserjs.github.io/TorZillaPrint/TorZillaPrint.html#screen ***/
user_pref("browser.link.open_newwindow", 3);
user_pref("browser.link.open_newwindow.restriction", 0);
/* 2204: disable Fullscreen API (requires user interaction) to prevent screen-resolution leaks
 * [NOTE] Вы все еще сможете вручную переключить полноэкранное состояние браузера (F11), но
 * этот преф отключит встроенные полноэкранные элементы управления видео/игрой, например youtube
 * [TEST] https://ghacksuserjs.github.io/TorZillaPrint/TorZillaPrint.html#screen ***/
   // user_pref("full-screen-api.enabled", false);
/* 2210: блокировать всплывающие окна
 * [SETTING] Privacy & Security>Permissions>Block pop-up windows ***/
user_pref("dom.disable_open_during_load", true);
/* 2212: ограничить события, вызывающие всплывающие окна [SETUP-WEB], по умолчанию используются
 * "change click dblclick auxclick mouseup pointerup notificationclick reset submit touchend contextmenu" ***/
user_pref("dom.popup_allowed_events", "click dblclick");

/*** [SECTION 2300]: WEB WORKERS ***/
/**  Worker - это "фоновая задача" JS, выполняемая в глобальном контексте.
     Workers могут порождать новых workers (должны иметь одинаковое происхождение и схему),
     включая сервисных и общих workers. Общие workers могут использоваться несколькими сценариями
     и взаимодействовать между контекстами (windows / tabs / iframes) и даже управлять кэшем. ***/
user_pref("_user.js.parrot", "2300 syntax error: the parrot's off the twig!");
/* 2302: disable service workers [FF32, FF44-compat]
 * Service workers по сути действуют как прокси между веб-приложениями, браузером и сетью,
 * управляются и сами управляют веб-страницами, с которыми связаны, перехватывая и изменяя
 * запросы и кэшируя ресурсы.
 * [NOTE] API Service worker скрыты (в Firefox) и не могут быть использованы в режиме PB.
 * [NOTE] Service workers работают только по HTTPS и не имеют доступа к DOM.
 * [SETUP-WEB] Отключение service workers приведет к поломке некоторых редких сайтов.
 * Этот преф требует true для service worker уведомлений (2304), push-уведомлений (2305)
 * и service worker кэша (2740). Если вы переключаете этот преф, то проверьте и эти настройки ***/
user_pref("dom.serviceWorkers.enabled", false);
// 2304: disable Web Notifications
   // user_pref("dom.webnotifications.enabled", false); // [FF22+]
   // user_pref("dom.webnotifications.serviceworker.enabled", false); // [FF44+]
// 2305: disable Push Notifications [FF44+]
user_pref("dom.push.enabled", false);
   // user_pref("dom.push.userAgentID", "");

/*** [SECTION 2400]: DOM (DOCUMENT OBJECT MODEL) & JAVASCRIPT ***/
user_pref("_user.js.parrot", "2400 syntax error: the parrot's kicked the bucket!");
/* 2401: disable website control over browser right-click context menu
 * [NOTE] Shift-Right-Click will always bring up the browser right-click context menu 
 * [ПРИМ] Контекстное меню будет вызываться где попало, например в сайдбарах расширений ***/
   // user_pref("dom.event.contextmenu.enabled", false);
/* 2404: disable clipboard commands (cut/copy) from "non-privileged" content [FF41+]
 * this disables document.execCommand("cut"/"copy") to protect your clipboard ***/
   // user_pref("dom.allow_cut_copy", false);
/* 2405: отключить диалог подтверждения об уходе со страницы
 * Не предотвращает JS утечку события закрытия страницы. ***/
user_pref("dom.disable_beforeunload", true);
// 2414: disable shaking the screen
user_pref("dom.vibrator.enabled", false);
// 2420: disable asm.js [FF22+] [SETUP-PERF]
   // user_pref("javascript.options.asmjs", false);
// 2426: disable Intersection Observer API [FF55+]
   // user_pref("dom.IntersectionObserver.enabled", false);
/* 2429: включить (ограниченную, но достаточную) защиту window.opener [FF65+]
 * Делает rel=noopener скрытым для target=_blank, когда атрибут rel не установлен ***/
user_pref("dom.targetBlankNoOpener.enabled", true); // [DEFAULT: true FF78+]

/*** [SECTION 2500]: HARDWARE FINGERPRINTING ***/
user_pref("_user.js.parrot", "2500 syntax error: the parrot's shuffled off 'is mortal coil!");
/* 2505: disable media device enumeration [FF29+]
 * [NOTE] media.peerconnection.enabled также должен быть установлен в false (see 2001)
 * [1] https://wiki.mozilla.org/Media/getUserMedia
 * [2] https://developer.mozilla.org/docs/Web/API/MediaDevices/enumerateDevices ***/
user_pref("media.navigator.enabled", false);
/* 2510: disable Web Audio API [FF51+]
 * [1] https://bugzilla.mozilla.org/1288359 ***/
user_pref("dom.webaudio.enabled", false);

/*** [SECTION 2600]: MISCELLANEOUS ***/
user_pref("_user.js.parrot", "2600 syntax error: the parrot's run down the curtain!");
/* 2601: prevent accessibility services from accessing your browser [RESTART]
 * [SETTING] Privacy & Security>Permissions>Prevent accessibility services from accessing your browser
 * Запретить службам поддержки доступности доступ к вашему браузеру ***/
user_pref("accessibility.force_disabled", 1);
// 2602: disable sending additional analytics to web servers
user_pref("beacon.enabled", false);
// 2603: remove temp files opened with an external application
user_pref("browser.helperApps.deleteTempFileOnExit", true);
/* 2604: disable page thumbnail collection
 * отключить создание thumbnail в папке профиля ***/
user_pref("browser.pagethumbnails.capturing_disabled", true); // [HIDDEN PREF]
// 2606: disable UITour backend so there is no chance that a remote page can use it
user_pref("browser.uitour.enabled", false);
user_pref("browser.uitour.url", "");
/* 2611: disable middle mouse click opening links from clipboard
 * отключить СКМ для открытия ссылок из буфера обмена ***/
   // user_pref("middlemouse.contentLoadURL", false);
// 2616: удалить специальные разрешения для определенных доменов Mozilla [FF35+]
   // user_pref("permissions.manager.defaultsUrl", "");
// 2617: удалить белый список веб-каналов
   // user_pref("webchannel.allowObject.urlWhitelist", "");
/* 2619: принудительно исп. Punycode для интернационализированных доменных имен.
 * Firefox имеет *некоторые* средства защиты, но лучше перестраховаться, чем сожалеть
 * [SETUP-WEB] Нежелательно для не латинского алфавита, законные IDN также кодируются punycoded
 * [TEST] https://www.xn--80ak6aa92e.com/ (www.apple.com) ***/
   // user_pref("network.IDN_show_punycode", true);
/* 2620: enforce Firefox's built-in PDF reader [SETUP-CHROME]
 * Этот параметр определяет, доступна ли опция "Отображать в Firefox" в приведенном ниже параметре,
 * а также определяет, обрабатываются ли PDF-файлы в браузере или внешне ("Ask "или" Open With")
 * [SETTING] General>Applications>Portable Document Format (PDF) ***/
user_pref("pdfjs.disabled", false); // [DEFAULT: false]
/* 2621: disable links launching Windows Store on Windows 8/8.1/10 [WINDOWS]
 * отключить запуск ссылок Windows Store на Windows  8/8.1/10 ***/
   // user_pref("network.protocol-handler.external.ms-windows-store", false);
/* 2623: disable permissions delegation [FF73+]
 * В настоящее время применяется к геолокации, разрешениям на камеру, микрофон и общий доступ к экрану,
 * а также полноэкранным запросам. Означает, что любые запросы будут показывать/использовать
 * их правильное стороннее происхождение ***/
user_pref("permissions.delegation.enabled", false);

/*** DOWNLOADS ***/
// Переопределение поведения при загрузке файлов
/* 2650: препятствовать загрузке на рабочий стол
 * 0=desktop, 1=downloads (default), 2=last used
 * [SETTING] To set your default "downloads": General>Downloads>Save files to ***/
   // user_pref("browser.download.folderList", 2);
/* 2651: всегда спрашивать, где сохранить
 * [SETUP-CHROME] На Android это блокирует долгое нажатие и сохранение изображений
 * [SETTING] General>Downloads>Always ask you where to save files ***/
   // user_pref("browser.download.useDownloadDir", false);
// 2652: отключить добавление загрузок в список "последние документы" системы
   // user_pref("browser.download.manager.addToRecentDocs", false);
// 2653: отключить скрытие mime типов (Options>General>Applications) не связанных с плагинами
   // user_pref("browser.download.hide_plugins_without_extensions", false);

/** EXTENSIONS ***/
/* 2660: lock down allowed extension directories
 * [SETUP-CHROME] Это отключит расширения, языковые пакеты, темы и любые другие XPI,
 * установленные вне каталогов профилей и приложения ***/
user_pref("extensions.enabledScopes", 5); // [HIDDEN PREF]
user_pref("extensions.autoDisableScopes", 15); // [DEFAULT: 15]
// 2662: отключить ограничения webextension для определенных доменов Mozilla (you also need 4503) [FF60+]
user_pref("extensions.webextensions.restrictedDomains", "");

/** SECURITY ***/
/* 2680: enforce CSP (Content Security Policy)
 * [WARNING] CSP является очень важной и широко распространенной функцией безопасности. Не отключайте это!
 * [1] https://developer.mozilla.org/docs/Web/HTTP/CSP ***/
user_pref("security.csp.enable", true); // [DEFAULT: true]
// 2684: задержка безопасности на некоторые подтверждения, например, установить, открыть/сохранить
user_pref("security.dialog_enable_delay", 700);

/*** [SECTION 2700]: PERSISTENT STORAGE

     [NOTE] indexedDB и serviceWorkers недоступны в режиме приватного просмотра
     [NOTE] Блокировка файлов cookie также блокирует доступ сайтов к localStorage (и sessionStorage),
     indexedDB, sharedWorker и serviceWorker (а следовательно и worker-у кэша и уведомлений).
     Если вы устанавливаете сайту исключение для cookies ("разрешить" или "разрешить на сессию"),
     то все перечисленное становится доступным для сайтов, за исключением shared/service workers,
     для него настройка cookies *должна* быть "Разрешить". ***/
user_pref("_user.js.parrot", "2700 syntax error: the parrot's joined the bleedin' choir invisible!");
/* 2701: disable 3rd-party cookies and site-data [SETUP-WEB]
 * 0=Принимать куки и данные сайта, 1=Блокировать все сторонние куки, 2=Блокировать все куки,
 * 3=Блокировать куки с не посещенных сайтов, 4=Блокировать кросс-сайты и соц-медиа трекеры (default FF69+)
 * [NOTE] В разрешениях для сайта можно установить исключения или использовать расширение
 * [NOTE] Категория "custom" гарантирует соблюдение префов Enhanced Tracking Protection
 * [SETTING] Privacy & Security>Enhanced Tracking Protection>Custom>Cookies ***/
user_pref("network.cookie.cookieBehavior", 1);
user_pref("browser.contentblocking.category", "custom");
/* 2702: устанавливать сторонние cookie (ВСЕ) (если включено в 2701) только для сеанса и
   устанавливать сторонние небезопасные (т.е. HTTP) куки только для сеанса
   [NOTE] .sessionOnly отменяет .nonsecureSessionOnly кроме случая,
   когда .sessionOnly=false, а .nonsecureSessionOnly=true. ***/
user_pref("network.cookie.thirdparty.sessionOnly", true);
user_pref("network.cookie.thirdparty.nonsecureSessionOnly", true); // [FF58+]
/* 2703: удалять куки и данные сайта при закрытии
 * 0=keep until they expire (default), 2=keep until you close Firefox
 * [NOTE] преф отключается (но не изменяется), если вы блокируете все cookie (2701 = 2)
 * [SETTING] Privacy & Security>Cookies and Site Data>Delete cookies and site data when Firefox is closed ***/
   // user_pref("network.cookie.lifetimePolicy", 2);
// 2730: disable offline cache
user_pref("browser.cache.offline.enable", false);
/* 2740: disable service worker cache and cache storage
 * [NOTE] Можно просто очищать кэш service worker при закрытии Firefox (see 2803) ***/
   // user_pref("dom.caches.enabled", false);

/*** [SECTION 2800]: SHUTDOWN ***/
user_pref("_user.js.parrot", "2800 syntax error: the parrot's bleedin' demised!");
/* 2802: включить очистку при завершении работы Firefox (see 2803)
 * [SETTING] Privacy & Security>History>Custom Settings>Clear history when Firefox closes ***/
   // user_pref("privacy.sanitize.sanitizeOnShutdown", true);
/* 2803: элементы для очистки при завершении работы (если 2802 = true) [SETUP-CHROME]
 * [NOTE] Если 'history' - true, загрузки также будут очищены
 * [SETTING] Privacy & Security>History>Custom Settings>Clear history when Firefox closes>Settings ***/
   // user_pref("privacy.clearOnShutdown.cache", true);
   // user_pref("privacy.clearOnShutdown.cookies", true);
   // user_pref("privacy.clearOnShutdown.downloads", true); // see note above
   // user_pref("privacy.clearOnShutdown.formdata", true); // Form & Search History
   // user_pref("privacy.clearOnShutdown.history", true); // Browsing & Download History
   // user_pref("privacy.clearOnShutdown.offlineApps", true); // Offline Website Data
   // user_pref("privacy.clearOnShutdown.sessions", true); // Active Logins
   // user_pref("privacy.clearOnShutdown.siteSettings", false); // Site Preferences
/* 2804: сброс элементов при очистке по Ctrl-Shift-Del (to match 2803) [SETUP-CHROME]
 * Firefox помнит последний выбор, это будет возвращать указанные значения при каждом запуске.
 * [NOTE] Если 'history' - true, загрузки также будут очищены ***/
   // user_pref("privacy.cpd.cache", true);
   // user_pref("privacy.cpd.cookies", true);
   // user_pref("privacy.cpd.formdata", true); // Form & Search History
   // user_pref("privacy.cpd.history", true); // Browsing & Download History
   // user_pref("privacy.cpd.offlineApps", true); // Offline Website Data
   // user_pref("privacy.cpd.passwords", false); // this is not listed
   // user_pref("privacy.cpd.sessions", true); // Active Logins
   // user_pref("privacy.cpd.siteSettings", false); // Site Preferences
/* 2805: очистить данные восстановления сеанса при любой очистке [FF34+]
 * [NOTE] Не требуется, если восстановление сеанса не используется (0102) или уже очищено с историей (2803)
 * [NOTE] privacy.clearOnShutdown.openWindows предотвращает возобновление после сбоя (см. 1022)
 * [NOTE] privacy.cpd.openWindows has a bug that causes an additional window to open ***/
   // user_pref("privacy.clearOnShutdown.openWindows", true);
   // user_pref("privacy.cpd.openWindows", true);
/* 2806: сброс по умолчанию "диапазона времени для очистки" в "очистить недавнюю историю" (see 2804)
 * Firefox помнит последний выбор, это будет возвращать указанное значение при каждом запуске.
 * 0=everything, 1=last hour, 2=last two hours, 3=last four hours,
 * 4=today, 5=last five minutes, 6=last twenty-four hours
 * [NOTE] Значения 5 + 6 не перечислены в выпадающем списке ***/
   // user_pref("privacy.sanitize.timeSpan", 0);

/*** [SECTION 4000]: FPI (FIRST PARTY ISOLATION)
 ** 1278037 - isolate indexedDB (FF51+)
 ** 1277803 - isolate favicons (FF52+)
 ** 1264562 - isolate OCSP cache (FF52+)
 ** 1268726 - isolate Shared Workers (FF52+)
 ** 1316283 - isolate SSL session cache (FF52+)
 ** 1317927 - isolate media cache (FF53+)
 ** 1323644 - isolate HSTS and HPKP (FF54+)
 ** 1334690 - isolate HTTP Alternative Services (FF54+)
 ** 1334693 - isolate SPDY/HTTP2 (FF55+)
 ** 1337893 - isolate DNS cache (FF55+)
 ** 1344170 - isolate blob: URI (FF55+)
 ** 1300671 - isolate data:, about: URLs (FF55+)
 ** 1473247 - isolate IP addresses (FF63+)
 ** 1492607 - isolate postMessage with targetOrigin "*" (requires 4002) (FF65+)
 ** 1542309 - isolate top-level domain URLs when host is in the public suffix list (FF68+)
 ** 1506693 - isolate pdfjs range-based requests (FF68+)
 ** 1330467 - isolate site permissions (FF69+)
 ** 1534339 - isolate IPv6 (FF73+) ***/
user_pref("_user.js.parrot", "4000 syntax error: the parrot's pegged out");
/* 4001: enable First Party Isolation [FF51+]
 * [SETUP-WEB] Может нарушить междоменные логины и функции небольшого числа сайтов.
 * Очень важный преф, лучше ходить на такие кривые сайты с IE, чем отключить это ***/
user_pref("privacy.firstparty.isolate", true);
/* 4002: принудительное ограничение FPI для window.opener [FF54 +]
 * [NOTE] Установка этого значения в false может уменьшить вероятность поломки в 4001
 * FF65 + блокирует postMessage с targetOrigin "*", если originAttributes не совпадают.
 * Чтобы уменьшить вероятность поломки, игнорирует originAttribute первичного домена (FPD).
 * Второй преф разрешает связь, только если FPD также совпадают (еще больше ломает). ***/
user_pref("privacy.firstparty.isolate.restrict_opener_access", false); // [DEFAULT: true]
   // user_pref("privacy.firstparty.isolate.block_post_message", true); // [HIDDEN PREF ESR]

/*** [SECTION 4500]: RFP (RESIST FINGERPRINTING) ***/
user_pref("_user.js.parrot", "4500 syntax error: the parrot's popped 'is clogs");
/* 4503: disable mozAddonManager Web API [FF57+]
 * [NOTE] На FF60+ cовместно с (2662) заставит работать расширения на AMO и т.п.
 * привилегированных страницах (например, переводчики). В итоге функционал удаления,
 * поломается и кнопка установки на AMO всегда бедет в состоянии "Установить...". ***/
user_pref("privacy.resistFingerprinting.block_mozAddonManager", true); // [HIDDEN PREF]
/* 4510: disable showing about:blank as soon as possible during startup [FF60+]
 * Когда значение true (FF62+), не маскирует изменение размера RFP chrome.
 * Если false, то отключает стробоскоп (вспышку белого) при старте браузера или загрузке страницы ***/
user_pref("browser.startup.blankWindow", false);
/* 4520: disable chrome animations [FF77+] [RESTART]
 * [NOTE] RFP подделывает это. Отключает плавную отрисовку страницы (старое поведение)
 * Также влияет на поведение мегабара ***/
   // user_pref("ui.prefersReducedMotion", 1); // [HIDDEN PREF]

/*** [SECTION 4600]: RFP ALTERNATIVES
   * Глючная как и сам RFP. При выполнении рекомендаций много ломается ***/

/*** [SECTION 4700]: RFP ALTERNATIVES (NAVIGATOR / USER AGENT (UA) SPOOFING)
     Это только к сведению. Эти префы недостаточны сами по себе, вам нужно использовать
     RFP (4500) или расширение, а в этом случае они становятся бессмысленными. ***/

/*** [SECTION 5000]: PERSONAL
     Не связанные с проектом настройки, которые могут оказаться полезными.  ***/
user_pref("_user.js.parrot", "5000 syntax error: this is an ex-parrot!");
/* WELCOME & WHAT's NEW NOTICES ***/
user_pref("browser.startup.homepage_override.mstone", "ignore"); // master switch
user_pref("startup.homepage_welcome_url", "");
user_pref("startup.homepage_welcome_url.additional", "");
user_pref("startup.homepage_override_url", ""); // What's New page after updates
/* WARNINGS ***/
user_pref("browser.tabs.warnOnClose", false);
user_pref("browser.tabs.warnOnCloseOtherTabs", false);
user_pref("browser.tabs.warnOnOpen", false);
user_pref("full-screen-api.warning.delay", 0);
user_pref("full-screen-api.warning.timeout", 0);
/* APPEARANCE ***/
   // user_pref("browser.download.autohideButton", false); // [FF57+]
/* CONTENT BEHAVIOR ***/
   // user_pref("accessibility.typeaheadfind", true); // enable "Find As You Type"
   // user_pref("clipboard.autocopy", false); // disable autocopy default [LINUX]
   // user_pref("layout.spellcheckDefault", 2); // 0=none, 1-multi-line, 2=multi-line & single-line
/* UX BEHAVIOR ***/
   // user_pref("browser.backspace_action", 2); // 0=previous page, 1=scroll up, 2=do nothing
   // user_pref("browser.tabs.closeWindowWithLastTab", false);
   // user_pref("general.autoScroll", false); // middle-click enabling auto-scrolling [DEFAULT: false on Linux]
   // user_pref("ui.key.menuAccessKey", 0); // disable alt key toggling the menu bar [RESTART]
   // user_pref("view_source.tab", false); // открыать "Исходный код страницы" в новом окне [FF68+]
/* UX FEATURES: отключить и скрыть значки и меню ***/
user_pref("browser.messaging-system.whatsNewPanel.enabled", false); // What's New [FF69+]
user_pref("extensions.pocket.enabled", false); // Pocket Account [FF46+]
user_pref("identity.fxaccounts.enabled", false); // Firefox Accounts & Sync [FF60+] [RESTART]
   // user_pref("reader.parse-on-load.enabled", false); // Reader View
/* OTHER ***/
   // user_pref("browser.bookmarks.max_backups", 2);
   // user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.addons", false); // disable CFR [FF67+]
      // [SETTING] General>Browsing>Recommend extensions as you browse
   // user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.features", false); // disable CFR [FF67+]
      // [SETTING] General>Browsing>Recommend features as you browse
   // user_pref("network.manage-offline-status", false); // see bugzilla 620472
   // user_pref("xpinstall.signatures.required", false); // enforced extension signing (Nightly/ESR)

/*** ДРУГОЕ ***/
user_pref("_user.js.parrot", "Секция ДРУГОЕ syntax error");

// Параметры до сих пор существуют, отключаем на всякий
user_pref("app.update.BITS.enabled", false);
user_pref("app.update.auto", false); // есть выше
user_pref("app.update.checkInstallTime", false);
user_pref("app.update.enabled", false);
user_pref("app.update.service.enabled", false);
user_pref("app.update.silent", false);
user_pref("app.update.staging.enabled", false);

// Не проверять является ли Firefox браузером по умолчанию при первом запуске
user_pref("browser.shell.didSkipDefaultBrowserCheckOnFirstRun", true);

// Статус загрузки страницы - риск утечки данных при использовании proxi\VPN
user_pref("dom.enable_performance", false);

/*** Внешний вид и поведение ***/

// [FF68+] разрешить userChrome/userContent (APPEARANCE)
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

// Запретить отсоединять нативные вкладки от окна
   // user_pref("browser.tabs.allowTabDetach", false);

// Показывать ли папку "Другие закладки" на панели закладок ( для 1. до 84 и 2. для 84.2, скорее всего временно)
   // user_pref("browser.toolbars.bookmarks.showOtherBookmarks", false);
   // user_pref("browser.toolbars.bookmarks.2h2020", false);

// Темная тема на страницах about:xxxxxx
   // user_pref("browser.in-content.dark-mode", true);
   // user_pref("ui.systemUsesDarkTheme", 1); // [HIDDEN PREF]

// Отключить анимацию полноэкранного режима, еще см. 5000 - WARNINGS
   // user_pref("full-screen-api.transition-duration.enter", "0 0");
   // user_pref("full-screen-api.transition-duration.leave", "0 0");
   // user_pref("full-screen-api.transition.timeout", 0);

// В about:addons открывать "расширения", вместо последней открытой категории
// Лучше использовать в config.js - lockPref(...
   // user_pref("extensions.ui.lastCategory", "addons://list/extension");

/* Использовать или нет атрибуты SVG (false ломает цвет заданный в самих svg)
 * Отключите, если красите SVG глобально, через CSS */
user_pref("svg.context-properties.content.enabled", true);

/* Если нет, то перетягивание из браузера в проводник и окна
 * других программ может не работать, ходят такие слухи ***/
   // user_pref("browser.launcherProcess.enabled", true); // [HIDDEN PREF]

// закрывать ли браузер при закрытии последней вкладки (UX BEHAVIOR)
user_pref("browser.tabs.closeWindowWithLastTab", false);
// открывать ли из строки адреса в новой вкладке
user_pref("browser.urlbar.openintab", true);
// открывать ли поиск в новой вкладке 
user_pref("browser.search.openintab", true);
// открывать ли закладки в новой вкладке (есть в UX BEHAVIOR)
user_pref("browser.tabs.loadBookmarksInTabs", true);
// открывать ли закладки в фоне
user_pref("browser.tabs.loadBookmarksInBackground", false);

// Не показывать в полях ввода пароля блок "Просмотр сохранённых ...."
user_pref("signon.showAutoCompleteFooter", false);

/* Не закрывать меню в панели закладок при открытии закладки по Ctrl+ЛКМ,
 * дает возможность открыть несколько закладок подряд ***/
user_pref("browser.bookmarks.openInTabClosesMenu", false);

/* Масштабировать только текст страниц =false, иначе все вместе с картинками,
 * эту функция теперь доступна в настройках ***/
   // user_pref("browser.zoom.full", true);

// Декодирование URL при копированиии из строки адреса (UX BEHAVIOR)
user_pref("browser.urlbar.decodeURLsOnCopy", true);

// Показывать список загрузок при старте загрузки (показывать = false)
   // user_pref("browser.download.panel.shown", false);

// Инструменты разработчика
 // Включение инструментов браузера и удаленной отладки (не трогайте, если не понимаете)
   // user_pref("devtools.chrome.enabled", true);
   // user_pref("devtools.debugger.remote-enabled", true);
user_pref("devtools.debugger.prompt-connection", false); // сообщение
   // user_pref("devtools.toolbox.selectedTool", "inspector"); // вкладка по умолчанию
 // Темная тема
   // user_pref("devtools.theme", "dark");

// EME-free - косметика
user_pref("app.partner.mozilla-EMEfree", "mozilla-EMEfree");

// OpenH264 - переключить если НЕ пользуетесь кодеком OpenH264
user_pref("media.gmp-gmpopenh264.enabled", false);
/* Если переключить, то кодек вообще удалится из профиля и about:addons
 * При обратном включении зайдите в about:addons в плагины и обновите его
 * Firefox загрузит его за десяток секунд, размер кодека чуть меньше 1Мб ***/
user_pref("media.gmp-gmpopenh264.visible", false);

/*** Вкладки ***/

// При восстановлении сеанса не загружать контент восстановленных вкладок
// Обновлять вкладки только при их выборе
   // user_pref("browser.sessionstore.restore_on_demand", true); // [DEFAULT]
// Обновлять закрепленные вкладки только при их выборе
   // user_pref("browser.sessionstore.restore_pinned_tabs_on_demand", true);

/* Фокус при закрытии вкладки
 * true  - Если открытая вкладка закрывается, переместить фокус
 * обратно на вкладку, которая ее открыла. (по умолчанию)
 * false - Если открытая вкладка закрывается, переместить фокус
 * на соседнюю правую вкладку, если она существует;
 * в противном случае на соседнюю левую вкладку. ***/
   // user_pref("browser.tabs.selectOwnerOnClose", false);

/*** Miltimedia ***/

/* Значение TRUE в этом параметре приводит к блеклому отображению цветов в видео
 * Значение FALSE делает недоступными видео выше 1080p на YouTube
 * Может предотвратить подвисание видео при воспроизведении, на некоторых ПК ***/
   // user_pref("media.webm.enabled", false);
/* Для обратного эффекта, если вдруг стало не доступно видео выше 1080p на YouTube
 * можно проверить или использовать эти параметры ***/
   // user_pref("media.mediasource.webm.enabled", true);
   // user_pref("gfx.crash-guard.status.wmfvpxvideo", 2);

// Автозапуск мультимедиа, см. 2030, 2031

// Функции автозапуска media помимо 2030 и 2031, можете побаловаться
   // user_pref("dom.media.autoplay.autoplay-policy-api", true);
   // user_pref("media.autoplay.allow-extension-background-pages", false);
   // user_pref("media.autoplay.block-event.enabled", true);
   // user_pref("media.autoplay.block-webaudio", true);

// Media cache - для предотврашения смены кривыми расширениями
user_pref("media.cache_size", 512000); // [DEFAULT: 512000]

/*** Память ***/

/* Как часто проверять страницу на изменения. Значения:
 * 0 - один раз за сессию
 * 1 - каждый раз при просмотре страницы
 * 2 - не проверять, использовать кэш браузера
 * 3 - проверять, когда страница устарела (автоматически). ***/
   // user_pref("browser.cache.check_doc_frequency", 3); // [DEFAULT: 3]

/* История вкладок, сохраняется при сохранении сессий.
 * Для приватности, при использовании функции сохранения сессий, можно
 * отключить первые два параметра. Иначе при восстановлении сессии
 * будет доступной вся история вкладок. Т.е. например, вкладка поваренок.ру,
 * а в ее истории порнохаб и страницы гугла со странными поисковыми запросами.
 * Это ни как не отразится на истории посещений. ***/

// 1020: История закрытых вкладок для "восстановить закрытую вкладку"
user_pref("browser.sessionstore.max_tabs_undo", 20);
/* История вкладок "вперед<->назад". Минимум 1, практический минимум = 2,
 * так как некоторые страницы используют эту функцию для перенаправления. ***/
user_pref("browser.sessionhistory.max_entries", 10);
/* Максимум страниц с историей "вперед<->назад" для хранения в памяти,
 * -1 = авто (по умолчанию), 0 = отключить, максимум 8.
 * Считается, что эта функция может тормозить браузер. Отключение просто
 * не держит страницы в памяти, а загружает из сети при повторном вызове. ***/
user_pref("browser.sessionhistory.max_total_viewers", 2);

/* Разрешить Windows сбрасывать память на диск, когда Firefox свернут.
 * Зависит от Windows. Разворачивание при этом будет тормозить. ***/
   // user_pref("config.trim_on_minimize", true); // [Создать] Логическое

/*** Оптимизация ***/

/* Для каждой вкладки свой процесс
 * При использовании Auto Tab Discard может уменьшить потребление памяти
 * https://addons.mozilla.org/ru/firefox/addon/auto-tab-discard ***/
   // user_pref("dom.ipc.processCount", -1);

/* Новый движок рендеринга, для ESR можно попробовать раскомментировать 2-ой преф,
 * первый преф и так отключен ***/
   // user_pref("gfx.webrender.enabled", false); // [DEFAULT: false]
   // user_pref("gfx.webrender.force-disabled", true); // [DEFAULT: false]

/* END: internal custom pref to test for syntax errors ***/
user_pref("_user.js.parrot", "УСПЕХ: user.js полностью загружен.");
