/******
* Нумерация, если есть, соответствует ghacks user.js
* date: 20 Jul 2020
* version 78-beta

* url: https://github.com/ghacksuserjs/ghacks-user.js

* При удалении параметра не забудьте сбросить его в about:config
******/

// START: internal custom pref to test for syntax errors
user_pref("_user.js.parrot", "ФИАСКО! user.js загружен не полностью, из-за синтаксической ошибки в нем.");

/*** [SECTION 0100]: STARTUP ***/

/* 0101: disable default browser check
 * [SETTING] General>Startup>Always check if Firefox is your default browser ***/
user_pref("browser.shell.checkDefaultBrowser", false);
// 0105a: disable Activity Stream telemetry
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry", false);
/* 0105b: disable Activity Stream Snippets
 * Запускает код с сервера (Remote Code Execution) и отправляет информацию обратно на сервер ***/
user_pref("browser.newtabpage.activity-stream.feeds.snippets", false);
user_pref("browser.newtabpage.activity-stream.asrouter.providers.snippets", "");
// 0105c: disable Activity Stream Top Stories, Pocket-based and/or sponsored content
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false); // [FF66+]
// 0105d: disable Activity Stream recent Highlights in the Library [FF57+]
   // user_pref("browser.library.activity-stream.enabled", false);
/* 0105e: clear default topsites
 * [NOTE] Это не мешает вам добавлять свои собственные ***/
user_pref("browser.newtabpage.activity-stream.default.sites", "");

/*** [SECTION 0300]: QUIET FOX ***/

// 0301b: disable auto-CHECKING for extension and theme updates
user_pref("extensions.update.enabled", false);
// 0302a: disable auto-INSTALLING Firefox updates [NON-WINDOWS FF65+]
user_pref("app.update.auto", false);
/* 0302b: disable auto-INSTALLING extension and theme updates (after the check in 0301b)
 * [SETTING] about:addons>Extensions>[cog-wheel-icon]>Update Add-ons Automatically (toggle) ***/
user_pref("extensions.update.autoUpdateDefault", false);
/* 0308: disable search engine updates (e.g. OpenSearch)
 * [NOTE] Это не влияет на встроенные поисковые системы Mozilla или веб-расширения ***/
user_pref("browser.search.update", false);
// 0309: disable sending Flash crash reports
user_pref("dom.ipc.plugins.flash.subprocess.crashreporter.enabled", false);
// 0310: disable sending the URL of the website where a plugin crashed
user_pref("dom.ipc.plugins.reportCrashURL", false);
// 0320: disable about:addons' Recommendations pane (uses Google Analytics)
user_pref("extensions.getAddons.showPane", false); // [HIDDEN PREF]
// 0321: disable recommendations in about:addons' Extensions and Themes panes [FF68+]
user_pref("extensions.htmlaboutaddons.recommendations.enabled", false);
/* 0330: disable telemetry
 * преф (.unified) влияет на поведение префа (.enabled)
 * IF unified=false then .enabled controls the telemetry module
 * IF unified=true then .enabled ONLY controls whether to record extended data
 * so make sure to have both set as false
 * [NOTE] FF58+ 'toolkit.telemetry.enabled' теперь ЗАБЛОКИРОВАН в prerelease
 * и release сборках (true и false соответственно) ***/
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.enabled", false); // see [NOTE] above FF58+
user_pref("toolkit.telemetry.server", "data:,");
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.updatePing.enabled", false); // [FF56+]
user_pref("toolkit.telemetry.bhrPing.enabled", false); // [FF57+] Background Hang Reporter
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false); // [FF57+]
// 0331: disable Telemetry Coverage
user_pref("toolkit.telemetry.coverage.opt-out", true); // [HIDDEN PREF]
user_pref("toolkit.coverage.opt-out", true); // [FF64+] [HIDDEN PREF]
user_pref("toolkit.coverage.endpoint.base", "");
/* 0340: disable Health Reports
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send technical... data ***/
user_pref("datareporting.healthreport.uploadEnabled", false);
// 0341: disable new data submission, master kill switch
user_pref("datareporting.policy.dataSubmissionEnabled", false);
/* 0342: disable Studies (see 0503)
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to install and run studies ***/
user_pref("app.shield.optoutstudies.enabled", false);
// 0350: disable Crash Reports
user_pref("breakpad.reportURL", "");
user_pref("browser.tabs.crashReporting.sendReport", false); // [FF44+]
user_pref("browser.crashReports.unsubmittedCheck.enabled", false); // [FF51+]
/* 0351: disable backlogged Crash Reports
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send backlogged crash reports  ***/
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false);
// 0390: disable Captive Portal detection
user_pref("captivedetect.canonicalURL", "");
user_pref("network.captive-portal-service.enabled", false); // [FF52+]
// 0391: disable Network Connectivity checks [FF65+]
user_pref("network.connectivity-service.enabled", false);

/*** [SECTION 0500]: SYSTEM ADD-ONS / EXPERIMENTS
     Префы отключения пунктов меню Pocket и аккаунта Firefox доступны в UX FEATURES (см. 5000) ***/
// 0503: disable Normandy/Shield [FF60+]
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.api_url", "");
// 0505: disable System Add-on updates
user_pref("extensions.systemAddon.update.enabled", false); // [FF62+]
user_pref("extensions.systemAddon.update.url", ""); // [FF44+]
/* 0506: disable PingCentre telemetry (used in several System Add-ons) [FF57+]
 * В настоящее время блокируется'datareporting.healthreport.uploadEnabled' (see 0340) ***/
user_pref("browser.ping-centre.telemetry", false);
// 0515: disable Screenshots
   // user_pref("extensions.screenshots.disabled", true); // [FF55+]
   // user_pref("extensions.screenshots.upload-disabled", true); // [FF60+]
// 0518: disable Web Compatibility Reporter [FF56+]
user_pref("extensions.webcompat-reporter.enabled", false);

/*** [SECTION 1200]: HTTPS (SSL/TLS / OCSP / CERTS / HPKP / CIPHERS) ***/

// 1205: disable SSL Error Reporting
user_pref("security.ssl.errorReporting.automatic", false);
user_pref("security.ssl.errorReporting.enabled", false);
user_pref("security.ssl.errorReporting.url", "");

/*** [SECTION 1800]: PLUGINS ***/

// 1803: disable Flash plugin
user_pref("plugin.state.flash", 0);
/* 1820: disable GMP (Gecko Media Plugins)
 * Больше см. в секции OpenH264 в конце файла ***/
user_pref("media.gmp-provider.enabled", false);
/* 1825: disable widevine CDM (Content Decryption Module)
 * [SETUP-WEB] if you *need* CDM, e.g. Netflix, Amazon Prime, Hulu, whatever ***/
user_pref("media.gmp-widevinecdm.visible", false);
user_pref("media.gmp-widevinecdm.enabled", false);
/* 1830: disable all DRM content (EME: Encryption Media Extension)
 * EME-free - переключить если пользуетесь кодеком
 * [SETUP-WEB] if you *need* EME, e.g. Netflix, Amazon Prime, Hulu, whatever
 * [SETTING] General>DRM Content>Play DRM-controlled content ***/
user_pref("media.eme.enabled", false);

/*** [SECTION 2000]: MEDIA / CAMERA / MIC ***/

/* 2001: disable WebRTC (Web Real-Time Communication)
 * [SETUP-WEB] WebRTC сливает налево ваш реальный IP-адрес под VPN и прокси.
 * false - cломает возможность общения в режиме реального времени ***/
user_pref("media.peerconnection.enabled", false);
/* 2002: limit WebRTC IP leaks if using WebRTC
 * In FF70+ these settings match Mode 4 (Mode 3 in older versions) (see [3])
 * [TEST] https://browserleaks.com/webrtc
 * [3] https://tools.ietf.org/html/draft-ietf-rtcweb-ip-handling-12#section-5.2 ***/
user_pref("media.peerconnection.ice.default_address_only", true);
user_pref("media.peerconnection.ice.no_host", true); // [FF51+]
user_pref("media.peerconnection.ice.proxy_only_if_behind_proxy", true); // [FF70+]

/*** [SECTION 2300]: WEB WORKERS ***/

/* 2302: disable service workers [FF32, FF44-compat]
 * Service workers по сути действуют как прокси между веб-приложениями, браузером и сетью,
 * управляются и сами управляют веб-страницами, с которыми связаны, перехватывая и изменяя
 * запросы и кэшируя ресурсы.
 * [NOTE] API Service worker скрыты (в Firefox) и не могут быть использованы в режиме PB.
 * [NOTE] Service workers работают только по HTTPS и не имеют доступа к DOM.
 * [SETUP-WEB] Отключение service workers приведет к поломке некоторых редких сайтов.
 * Этот преф требует true для service worker уведомлений (2304), push-уведомлений (2305)
 * и service worker кэша (2740). Если вы переключаете этот преф, то проверьте и эти настройки ***/
user_pref("dom.serviceWorkers.enabled", false);
// 2304: disable Web Notifications
   // user_pref("dom.webnotifications.enabled", false); // [FF22+]
   // user_pref("dom.webnotifications.serviceworker.enabled", false); // [FF44+]
// 2305: disable Push Notifications [FF44+]
user_pref("dom.push.enabled", false);
   // user_pref("dom.push.userAgentID", "");

/*** [SECTION 2600]: MISCELLANEOUS ***/

// 2602: disable sending additional analytics to web servers
user_pref("beacon.enabled", false);
/* 2604: disable page thumbnail collection
 * отключить создание thumbnail в папке профиля ***/
user_pref("browser.pagethumbnails.capturing_disabled", true); // [HIDDEN PREF]
// 2606: disable UITour backend so there is no chance that a remote page can use it
user_pref("browser.uitour.enabled", false);
user_pref("browser.uitour.url", "");

/*** [SECTION 5000]: PERSONAL
     Не связанные с проектом настройки, которые могут оказаться полезными.  ***/

/* WELCOME & WHAT's NEW NOTICES ***/
user_pref("browser.startup.homepage_override.mstone", "ignore"); // master switch
user_pref("startup.homepage_welcome_url", "");
user_pref("startup.homepage_welcome_url.additional", "");
user_pref("startup.homepage_override_url", ""); // What's New page after updates
/* UX FEATURES: отключить и скрыть значки и меню ***/
user_pref("browser.messaging-system.whatsNewPanel.enabled", false); // What's New [FF69+]
user_pref("extensions.pocket.enabled", false); // Pocket Account [FF46+]
user_pref("identity.fxaccounts.enabled", false); // Firefox Accounts & Sync [FF60+] [RESTART]
   // user_pref("reader.parse-on-load.enabled", false); // Reader View

/*** ДРУГОЕ ***/

// Параметры до сих пор существуют, отключаем на всякий
user_pref("app.update.BITS.enabled", false);
user_pref("app.update.enabled", false);
user_pref("app.update.service.enabled", false);

// Не проверять является ли Firefox браузером по умолчанию при первом запуске
user_pref("browser.shell.didSkipDefaultBrowserCheckOnFirstRun", true);

/*** Внешний вид и поведение ***/

// [FF68+] разрешить userChrome/userContent (APPEARANCE)
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

// Темная тема на страницах about:xxxxxx
   // user_pref("browser.in-content.dark-mode", true);
   // user_pref("ui.systemUsesDarkTheme", 1); // [HIDDEN PREF]

// Инструменты разработчика
 // Темная тема
   // user_pref("devtools.theme", "dark");

// EME-free - косметика
user_pref("app.partner.mozilla-EMEfree", "mozilla-EMEfree");

// OpenH264 - переключить если НЕ пользуетесь кодеком OpenH264
user_pref("media.gmp-gmpopenh264.enabled", false);
/* Если переключить, то кодек вообще удалится из профиля и about:addons
 * При обратном включении зайдите в about:addons в плагины и обновите его
 * Firefox загрузит его за десяток секунд, размер кодека чуть меньше 1Мб ***/
user_pref("media.gmp-gmpopenh264.visible", false);

/* END: internal custom pref to test for syntax errors ***/
user_pref("_user.js.parrot", "УСПЕХ: user.js полностью загружен.");
