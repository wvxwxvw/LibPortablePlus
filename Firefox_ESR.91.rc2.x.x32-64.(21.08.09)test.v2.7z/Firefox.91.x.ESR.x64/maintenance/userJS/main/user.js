/******
* Нумерация, если есть, соответствует arkenfox user.js
* date: 30 July 2021
* version 91-alpha
* url: https://github.com/arkenfox/user.js

       Подсказка:
       Ищите и читайте теги "[SETUP]", при необходимости измените параметр
       (или закомментируйте его и обязательно сбросьте в about:config).

       Вот основные теги:
       [SETUP-SECURITY] это один пункт, прочтите его
            [SETUP-WEB] может привести к поломке некоторых сайтов
         [SETUP-CHROME] изменяет поведение самого Firefox (не веб-сайта)
           [SETUP-PERF] может повлиять на производительность
              [WARNING] обратите внимание
                 [ПРИМ] мои примечания
                [CHECK] параметры которые у меня раскомментированы

* INDEX:

  0100: STARTUP
  0200: GEOLOCATION / LANGUAGE / LOCALE
  0300: QUIET FOX
  0400: BLOCKLISTS / SAFE BROWSING
  0500: SYSTEM ADD-ONS / EXPERIMENTS
  0600: BLOCK IMPLICIT OUTBOUND
  0700: HTTP* / TCP/IP / DNS / PROXY / SOCKS etc
  0800: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS
  0900: PASSWORDS
  1000: CACHE / SESSION (RE)STORE / FAVICONS
  1200: HTTPS (SSL/TLS / OCSP / CERTS / HPKP / CIPHERS)
  1400: FONTS
  1600: HEADERS / REFERERS
  1700: CONTAINERS
  1800: PLUGINS
  2000: MEDIA / CAMERA / MIC
  2200: WINDOW MEDDLING & LEAKS / POPUPS
  2300: WEB WORKERS
  2400: DOM (DOCUMENT OBJECT MODEL) & JAVASCRIPT
  2500: HARDWARE FINGERPRINTING
  2600: MISCELLANEOUS
  2700: PERSISTENT STORAGE
  2800: SHUTDOWN
  4000: FPI (FIRST PARTY ISOLATION)
  4500: RFP (RESIST FINGERPRINTING)
  4600: RFP ALTERNATIVES
  4700: RFP ALTERNATIVES (USER AGENT SPOOFING)
  5000: PERSONAL
  9999: DEPRECATED / REMOVED / LEGACY / RENAMED
  ----: ДРУГОЕ

******/

// START: internal custom pref to test for syntax errors
user_pref("_user.js.parrot", "ФИАСКО! user.js загружен не полностью, из-за синтаксической ошибки в нем.");

// 0000: отключить предупреждение при входе в about:config
user_pref("general.warnOnAboutConfig", false); // XHTML version
user_pref("browser.aboutConfig.showWarning", false); // HTML version [FF71+]

/*** [SECTION 0100]: STARTUP ***/
user_pref("_user.js.parrot", "0100 syntax error: the parrot's dead!");
/* 0101: disable default browser check
 * [SETTING] General>Startup>Always check if Firefox is your default browser ***/
user_pref("browser.shell.checkDefaultBrowser", false);
/* 0102: что открывать при запуске [SETUP-CHROME]
 * 0=blank, 1=home, 2=last visited page, 3=resume previous session
 * [NOTE] Session Restore is not used in PB mode (0110) and is cleared with history (2803, 2804)
 * [SETTING] General>Startup>Restore previous session ***/
   // user_pref("browser.startup.page", 1);
/* 0103: set HOME+NEWWINDOW page
 * about:home=Activity Stream (default, see 0105), custom URL, about:blank
 * [SETTING] Home>New Windows and Tabs>Homepage and new windows ***/
   // user_pref("browser.startup.homepage", "about:blank");
/* 0104: set NEWTAB page
 * true=Activity Stream (default, see 0105), false=blank page
 * [SETTING] Home>New Windows and Tabs>New tabs ***/
   // user_pref("browser.newtabpage.enabled", false);
user_pref("browser.newtab.preload", false);
// 0105a: disable Activity Stream telemetry
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry", false);
/* 0105b: disable Activity Stream Snippets
 * Запускает код с сервера и отправляет информацию обратно на телеметрический сервер
 * [1] https://abouthome-snippets-service.readthedocs.io/ ***/
user_pref("browser.newtabpage.activity-stream.feeds.snippets", false); // [DEFAULT: false FF89+]
// 0105c: disable Activity Stream Top Stories, Pocket-based and/or sponsored content
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false); // [FF66+]
user_pref("browser.newtabpage.activity-stream.showSponsoredTopSites", false); // [FF83+]
/* 0105e: clear default topsites
 * [NOTE] Это не мешает вам добавлять свои собственные ***/
user_pref("browser.newtabpage.activity-stream.default.sites", "");
/* 0110: start Firefox in PB (Private Browsing) mode
 * [NOTE] В этом режиме все окна приватные, а значок режима PB не отображается
 * [WARNING] Режим PB вводит в заблуждение, типа, раз нет кеша, истории, куков, localStorage и IndexedDB
 * - значит нет проблем, но на самом деле у вас отбирают возможность управления некоторыми параметрами в этом режиме.
 * Используйте приватное окно для временной сессии, в остальном смысла нет, всего этого можно добиться и без PB
 * [SETTING] Privacy & Security>History>Custom Settings>Always use private browsing mode
 * [1] https://wiki.mozilla.org/Private_Browsing
 * [2] https://spreadprivacy.com/is-private-browsing-really-private/ ***/
   // user_pref("browser.privatebrowsing.autostart", true);

/*** [SECTION 0200]: GEOLOCATION / LANGUAGE / LOCALE ***/
user_pref("_user.js.parrot", "0200 syntax error: the parrot's definitely deceased!");
/** GEOLOCATION ***/
/* 0201: disable Location-Aware Browsing
 * [NOTE] Best left at default "true", fingerprintable, already behind a prompt (see 0202)
 * [1] https://www.mozilla.org/firefox/geolocation/ ***/
   // user_pref("geo.enabled", false);
/* 0202: set a default permission for Location (see 0201) [FF58+]
 * 0=always ask (default), 1=allow, 2=block
 * [NOTE] Best left at default "always ask", fingerprintable via Permissions API
 * [SETTING] to add site exceptions: Ctrl+I>Permissions>Access Your Location
 * [SETTING] to manage site exceptions: Options>Privacy & Security>Permissions>Location>Settings ***/
   // user_pref("permissions.default.geo", 2);
/* 0203: использовать сервис геолокации Mozilla вместо Google, когда геолокация включена [FF74+]
 * При желании включите запись в консоль, второй преф (defaults to false) ***/
user_pref("geo.provider.network.url", "https://location.services.mozilla.com/v1/geolocate?key=%MOZILLA_API_KEY%");
   // user_pref("geo.provider.network.logging.enabled", true); // [HIDDEN PREF]
// 0204: отключить использование сервиса геолокации ОС
user_pref("geo.provider.ms-windows-location", false); // [WINDOWS]
user_pref("geo.provider.use_corelocation", false); // [MAC]
user_pref("geo.provider.use_gpsd", false); // [LINUX]
/* 0207: disable region updates
 * [ПРИМ] это не мешает яндексу угадывать город нахождения ***/
user_pref("browser.region.network.url", ""); // [FF78+]
user_pref("browser.region.update.enabled", false); // [[FF79+]
/* 0208: set search region
 * [NOTE] Не сработает, если Firefox изменил настройки вашего региона (see 0207) ***/
   // user_pref("browser.search.region", "US"); // [HIDDEN PREF]

/** LANGUAGE / LOCALE ***/
/* 0210: язык для отображения веб-страниц
 * [TEST] https://addons.mozilla.org/about ***/
   // user_pref("intl.accept_languages", "en-US, en");
/* 0211: применять US English независимо от языка системы
 * [SETUP-WEB] Может нарушить некоторые методы ввода  ***/
   // user_pref("javascript.use_us_english_locale", true); // [HIDDEN PREF]

/*** [SECTION 0300]: QUIET FOX
***/
user_pref("_user.js.parrot", "0300 syntax error: the parrot's not pinin' for the fjords!");
/* 0301: disable auto-INSTALLING Firefox updates [NON-WINDOWS FF65+]
 * [NOTE] In FF65+ on Windows this SETTING (below) is now stored in a file and the pref was removed
 * [SETTING] General>Firefox Updates>Check for updates but let you choose to install them ***/
user_pref("app.update.auto", false);
/* 0302: disable auto-INSTALLING Firefox updates via a background service [FF90+] [WINDOWS]
 * [SETTING] General>Firefox Updates>Automatically install updates>When Firefox is not running
 * [1] https://support.mozilla.org/kb/enable-background-updates-firefox-windows ***/
user_pref("app.update.background.scheduling.enabled", false);
/* 0303: disable auto-CHECKING for extension and theme updates ***/
   // user_pref("extensions.update.enabled", false);
/* 0304: disable auto-INSTALLING extension and theme updates (after the check in 0303)
 * [SETTING] about:addons>Extensions>[cog-wheel-icon]>Update Add-ons Automatically (toggle) ***/
user_pref("extensions.update.autoUpdateDefault", false);
/* 0306: отключить метаданные расширения
 * Используется при установке/обновлении расширения и при фоновых проверках.
 * При значении false вкладки сведений о расширении не будут иметь описания ***/
   // user_pref("extensions.getAddons.cache.enabled", false);
/* 0308: disable search engine updates (e.g. OpenSearch)
 * [NOTE] Это не влияет на встроенные поисковые системы Mozilla или веб-расширения ***/
user_pref("browser.search.update", false);
// 0320: disable about:addons' Recommendations pane (uses Google Analytics)
user_pref("extensions.getAddons.showPane", false); // [HIDDEN PREF]
// 0321: disable recommendations in about:addons' Extensions and Themes panes [FF68+]
user_pref("extensions.htmlaboutaddons.recommendations.enabled", false);
/* 0330: disable telemetry
 * преф (.unified) влияет на поведение префа (.enabled)
 * IF unified=false then .enabled controls the telemetry module
 * IF unified=true then .enabled ONLY controls whether to record extended data
 * so make sure to have both set as false
 * [NOTE] FF58+ 'toolkit.telemetry.enabled' теперь ЗАБЛОКИРОВАН в prerelease
 * и release сборках (true и false соответственно) ***/
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.enabled", false); // see [NOTE]
user_pref("toolkit.telemetry.server", "data:,");
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.updatePing.enabled", false); // [FF56+]
user_pref("toolkit.telemetry.bhrPing.enabled", false); // [FF57+] Background Hang Reporter
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false); // [FF57+]
// 0331: disable Telemetry Coverage
user_pref("toolkit.telemetry.coverage.opt-out", true); // [HIDDEN PREF]
user_pref("toolkit.coverage.opt-out", true); // [FF64+] [HIDDEN PREF]
user_pref("toolkit.coverage.endpoint.base", "");
/* 0340: disable Health Reports
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send technical... data ***/
user_pref("datareporting.healthreport.uploadEnabled", false);
// 0341: disable new data submission, master kill switch [FF41+]
user_pref("datareporting.policy.dataSubmissionEnabled", false);
/* 0342: disable Studies (see 0503)
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to install and run studies ***/
user_pref("app.shield.optoutstudies.enabled", false);
/* 0343: disable personalized Extension Recommendations in about:addons and AMO [FF65+]
 * [NOTE] Этот преф не действует, если 0340 отключен
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to make personalized extension recommendations ***/
user_pref("browser.discovery.enabled", false);
// 0350: disable Crash Reports
user_pref("breakpad.reportURL", "");
user_pref("browser.tabs.crashReporting.sendReport", false); // [FF44+]
user_pref("browser.crashReports.unsubmittedCheck.enabled", false); // [FF51+] [DEFAULT: false]
/* 0351: enforce no submission of backlogged Crash Reports [FF58+]
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send backlogged crash reports  ***/
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false); // [DEFAULT: false]
// 0390: disable Captive Portal detection
user_pref("captivedetect.canonicalURL", "");
user_pref("network.captive-portal-service.enabled", false); // [FF52+]
// 0391: disable Network Connectivity checks [FF65+]
user_pref("network.connectivity-service.enabled", false);

/*** [SECTION 0400]: BLOCKLISTS / SAFE BROWSING (SB) ***/
user_pref("_user.js.parrot", "0400 syntax error: the parrot's passed on!");
/** BLOCKLISTS ***/
/* 0401: enforce Firefox blocklist
 * [NOTE] Включает обновления для "отозванных сертификатов"
 * [1] https://blog.mozilla.org/security/2015/03/03/revoking-intermediate-certificates-introducing-onecrl/ ***/
user_pref("extensions.blocklist.enabled", true); // [DEFAULT: true]

/** SAFE BROWSING (SB)
    Safe Browsing делает много шагов для сохранения конфиденциальности. Полный URL никогда не передается
    Google, только ЧАСТЬ-хэш префикса, и тот скрыт шумом других ЧАСТИЧНЫХ хэшей. Google уверяет, что это
    анонимно и используется только для маркировки вредоносных сайтов.
    И т.п и т.д, заплатили что ли? Fx 89 - Зашел на GitHub скачать Sabdboxie, а он меня не пустил.
    На GitHub!!! Потом правда пустил, но мне такая опека не нужна.

    [1] https://feeding.cloud.geek.nz/posts/how-safe-browsing-works-in-firefox/
    [2] https://wiki.mozilla.org/Security/Safe_Browsing
    [3] https://support.mozilla.org/kb/how-does-phishing-and-malware-protection-work
***/
/* 0410: disable SB (Safe Browsing)
 * Это главные переключатели.
 * [SETTING] Privacy & Security>Security>... "Block dangerous and deceptive content" ***/
user_pref("browser.safebrowsing.malware.enabled", false);
user_pref("browser.safebrowsing.phishing.enabled", false);
/* 0411: disable SB checks for downloads (both local lookups + remote)
 * Это главный переключатель для параметров safebrowsing.downloads* (0412, 0413)
 * [SETTING] Privacy & Security>Security>... "Block dangerous downloads" ***/
user_pref("browser.safebrowsing.downloads.enabled", false);
/* 0412: disable SB checks for downloads (remote)
 * Чтобы проверить безопасность некоторых исполняемых файлов, Firefox отправляет
 * некоторую информацию о файле и его происхождении в службу Google Safe Browsing.
 * Служба Safe Browsing, которая помогает Firefox определить, следует ли блокировать файл.
 * [SETUP-SECURITY] Если вам нужна эта защита, то переопределите эти параметры ***/
user_pref("browser.safebrowsing.downloads.remote.enabled", false);
user_pref("browser.safebrowsing.downloads.remote.url", "");
/* 0413: disable SB checks for unwanted software
 * [SETTING] Privacy & Security>Security>... "Warn you about unwanted and uncommon software" ***/
user_pref("browser.safebrowsing.downloads.remote.block_potentially_unwanted", false);
user_pref("browser.safebrowsing.downloads.remote.block_uncommon", false);
/* 0419: запретить переопределение в уведомлениях SB [FF45+]
 * [TEST] see github wiki APPENDIX A: Test Sites: Section 5 ***/
   // user_pref("browser.safebrowsing.allowOverride", false);

/*** [SECTION 0500]: SYSTEM ADD-ONS / EXPERIMENTS

     Системные дополнения - это встроенные функции Firefox, которые не отображаются
     в about:addons. Чтобы просмотреть их, перейдите в about:support, они перечислены
     в разделе "Возможности Firefox"

     Некоторые из них не имеют префов включения/выключения. Но вы можете удалить их вручную.
     Обновления восстановят их. Они также могут восстановится автоматически (см. 0505)
     Находятся в * Portable: "...\core\browser\features\" 

     Префы отключения пунктов меню Pocket и аккаунта Firefox доступны в UX FEATURES (см. 5000) ***/
user_pref("_user.js.parrot", "0500 syntax error: the parrot's cashed in 'is chips!");
/* 0503: disable Normandy/Shield [FF60+]
 * телеметрия и стороннее тестирование ***/
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.api_url", "");
// 0505: disable System Add-on updates
user_pref("extensions.systemAddon.update.enabled", false); // [FF62+]
user_pref("extensions.systemAddon.update.url", ""); // [FF44+]
/* 0506: disable PingCentre telemetry (used in several System Add-ons) [FF57+]
 * В настоящее время блокируется'datareporting.healthreport.uploadEnabled' (see 0340) ***/
user_pref("browser.ping-centre.telemetry", false);
/* 0515: disable Screenshots
 * [CHECK] ***/
   // user_pref("extensions.screenshots.disabled", true); // [FF55+]
/* 0517: disable Form Autofill
 * [NOTE] Сохранение данных НЕ безопасно (так как используется текстовый файл JSON)
 * [NOTE] Эвристика контролирует автозаполнение форм без атрибутов @autocomplete
 * [SETTING] Privacy & Security>Forms and Autofill>Autofill addresses
 * [CHECK]-all ***/
   // user_pref("extensions.formautofill.addresses.enabled", false); // [FF55+]
   // user_pref("extensions.formautofill.available", "off"); // [FF56+]
   // user_pref("extensions.formautofill.creditCards.available", false); // [FF57+]
   // user_pref("extensions.formautofill.creditCards.enabled", false); // [FF56+]
   // user_pref("extensions.formautofill.heuristics.enabled", false); // [FF55+]
// 0518: enforce disabling of Web Compatibility Reporter [FF56+]
user_pref("extensions.webcompat-reporter.enabled", false); // [DEFAULT: false]

/*** [SECTION 0600]: BLOCK IMPLICIT OUTBOUND [not explicitly asked for - e.g. clicked on] ***/
user_pref("_user.js.parrot", "0600 syntax error: the parrot's no more!");
// 0601: disable link prefetching
user_pref("network.prefetch-next", false);
// 0602: disable DNS prefetching
user_pref("network.dns.disablePrefetch", true);
user_pref("network.dns.disablePrefetchFromHTTPS", true); // [DEFAULT: true]
// 0603: disable predictor / prefetching
user_pref("network.predictor.enabled", false);
user_pref("network.predictor.enable-prefetch", false); // [FF48+] [DEFAULT: false]
// 0605: disable link-mouseover opening connection to linked server
user_pref("network.http.speculative-parallel-limit", 0);
// 0606: enforce no "Hyperlink Auditing" (click tracking)
user_pref("browser.send_pings", false); // [DEFAULT: false]
user_pref("browser.send_pings.require_same_host", true);

/*** [SECTION 0700]: HTTP* / TCP/IP / DNS / PROXY / SOCKS etc ***/
user_pref("_user.js.parrot", "0700 syntax error: the parrot's given up the ghost!");
/* 0701: disable IPv6
 * IPv6 может злоупотреблять, особенно в отношении MAC-адресов
 * [STATS] телеметрия Firefox за июль 2021 показывает, что только ~10% всех подключений
 * используют IPv6
 * [NOTE] Это просто запасной вариант на уровне приложения. Отключение IPv6 лучше всего выполнять
 * на уровне ОС/сети и/или правильно настроить VPN. Если вы не маскируете свой IP - это не будет
 * иметь большого значения, если маскируете - то это может только помочь.
 * [NOTE] PHP defaults to IPv6 with "localhost". Use "php -S 127.0.0.1:PORT"
 * [TEST] https://ipleak.org/ ***/
user_pref("network.dns.disableIPv6", true);
/* 0702: disable HTTP2
 * [STATS] ~46% of sites (July 2021) [5]
 * [1] https://http2.github.io/faq/
 * [5] https://w3techs.com/technologies/details/ce-http2/all/all ***/
   // user_pref("network.http.spdy.enabled", false);
   // user_pref("network.http.spdy.enabled.deps", false);
   // user_pref("network.http.spdy.enabled.http2", false);
   // user_pref("network.http.spdy.websockets", false); // [FF65+]
/* 0703: disable HTTP Alternative Services [FF37+]
 * [SETUP-PERF] Предотвращает возможность внешнего сканирования портов доступных вам ресурсов.
 * Защищено если FPI enabled (see 4000) ***/
user_pref("network.http.altsvc.enabled", false);
user_pref("network.http.altsvc.oe", false);
// 0704: при использовании SOCKS проксировать DNS-запросы,
user_pref("network.proxy.socks_remote_dns", true);
/* 0709: disable using UNC (Uniform Naming Convention) paths [FF61+]
 * [SETUP-CHROME] Может сломать расширения с профилями на сетевых ресурсах
 * [1] https://gitlab.torproject.org/tpo/applications/tor-browser/-/issues/26424
 * [CHECK] ***/
   // user_pref("network.file.disable_unc_paths", true); // [HIDDEN PREF]
/* 0710: disable GIO as a potential proxy bypass vector
 * Gvfs/GIO has a set of supported protocols like obex, network, archive, computer, dav, cdda,
 * gphoto2, trash, etc. By default only smb and sftp protocols are accepted so far (as of FF64) ***/
user_pref("network.gio.supported-protocols", ""); // [HIDDEN PREF]

/*** [SECTION 0800]: LOCATION BAR / SEARCH BAR / SUGGESTIONS / HISTORY / FORMS
***/
user_pref("_user.js.parrot", "0800 syntax error: the parrot's ceased to be!");
/* 0801: отключить поиск по enter в адресной строке
 * При вводе или вставке URL он отправляется на сервер поисковика по умолчанию.
 * Examples: "secretplace,com", "secretplace/com", "secretplace com", "secret place.com"
 * [NOTE] Это не влияет на кнопки поиска в выпадающем списке и ключи, настроенные в настройках
 * (например, "d" для DuckDuckGo)
 * [SETUP-CHROME] Если вы не вводите или редко вводите URL-адреса и используете приватный
 * поисковик, то преф возможно вам не нужен
 * [ПРИМ] Ломает поиск одним кликом ***/
   // user_pref("keyword.enabled", false);
/* 0802: disable location bar domain guessing
 * Отключить угадывание домена (www, .com и т.п.)
 * Приводит к ошибкам переходов, лишним подключениям и утечке данных ***/
user_pref("browser.fixup.alternate.enabled", false);
// 0803: отображать все части URL в адресной строке
user_pref("browser.urlbar.trimURLs", false);
/* 0805: отключить раскраску посещенных ссылок - CSS утечка истории
 * [SETUP-HARDEN] Массовое быстрое обнюхивание истории было смягчено в 2010 году [1][2].
 * Более медленные и дорогие атаки были смягчены в FF77+ [3].
 * RFP (4501) еще больше затрудняет временные атаки, если очищать историю при закрытии (2803).
 * Тем не менее, соц. инженерия [2#limits][4][5] и целевые временные атаки все еще работают
 * [1] https://developer.mozilla.org/docs/Web/CSS/Privacy_and_the_:visited_selector
 * [2] https://dbaron.org/mozilla/visited-privacy
 * [3] https://bugzilla.mozilla.org/1632765
 * [4] https://earthlng.github.io/testpages/visited_links.html (see github wiki APPENDIX A on how to use)
 * [5] https://lcamtuf.blogspot.com/2016/08/css-mix-blend-mode-is-bad-for-keeping.html ***/
user_pref("layout.css.visited_links_enabled", false);
/* 0807: отключить предложения при поиске в строках адреса и поиска
 * [NOTE] Оба должны быть true для живого поиска
 * [SETUP-CHROME] при постоянном использовании приватной поисковой системы, возможно, не актуально
 * [SETTING] Search>Provide search suggestions | Show search suggestions in address bar results
 * [CHECK] ***/
   // user_pref("browser.search.suggest.enabled", false);
   // user_pref("browser.urlbar.suggest.searches", false);
// 0810: отключить спекулятивные соединения строки адреса [FF56+]
user_pref("browser.urlbar.speculativeConnect.enabled", false);
/* 0811: отключить утечку отдельных слов из адресной строки на DNS **после поиска** [FF78+]
 * 0=never resolve single words, 1=heuristic (default), 2=always resolve ***/
user_pref("browser.urlbar.dnsResolveSingleWordsAfterSearch", 0);
/* 0850a: отключить типы подсказок в адресной строке
 * [SETTING] Privacy & Security>Address Bar>When using the address bar, suggest ***/
   // user_pref("browser.urlbar.suggest.history", false);
   // user_pref("browser.urlbar.suggest.bookmark", false);
   // user_pref("browser.urlbar.suggest.openpage", false);
// [CHECK]
   // user_pref("browser.urlbar.suggest.topsites", false); // [FF78+]
/* 0850b: disable tab-to-search [FF85+]
 * Кроме того, вы можете исключить их на основе каждого движка, сняв флажок Options>Search
 * [SETTING] Privacy & Security>Address Bar>When using the address bar, suggest>Search engines ***/
   // user_pref("browser.urlbar.suggest.engines", false);
/* 0850c: disable location bar dropdown
 * Определяет общее количество записей, отображаемых в раскрывающемся списке ***/
   // user_pref("browser.urlbar.maxRichResults", 0);
/* 0850d: отключить автозаполнение строки адреса
 * [CHECK] ***/
   // user_pref("browser.urlbar.autoFill", false);
/* 0860: отключить историю поиска и форм
 * [SETUP-WEB] автозаполняемые формы могут быть прочитаны третьими лицами
 * [NOTE] как очистить formdata при выходе (см. 2803)
 * [SETTING] Privacy & Security>History>Custom Settings>Remember search and form history ***/
   // user_pref("browser.formfill.enable", false);
/* 0862: disable browsing and download history
 * [NOTE] как очистить историю при выходе (см. 2803)
 * [SETTING] Privacy & Security>History>Custom Settings>Remember browsing and download history ***/
   // user_pref("places.history.enabled", false);
// 0870: отключить список переходов в панели задач [WINDOWS]
user_pref("browser.taskbar.lists.enabled", false);
user_pref("browser.taskbar.lists.frequent.enabled", false);
user_pref("browser.taskbar.lists.recent.enabled", false);
user_pref("browser.taskbar.lists.tasks.enabled", false);
// 0871: отключить предпросмотр в панели задач Windows [WINDOWS]
   // user_pref("browser.taskbar.previews.enable", false); // [DEFAULT: false]

/*** [SECTION 0900]: PASSWORDS ***/
user_pref("_user.js.parrot", "0900 syntax error: the parrot's expired!");
/* 0901: disable saving passwords
 * [NOTE] Это не очищает уже сохраненные пароли
 * [SETTING] Privacy & Security>Logins and Passwords>Ask to save logins and passwords for websites ***/
   // user_pref("signon.rememberSignons", false);
/* 0902: Использовать мастер-пароль. Устанавливается в настройках.
 * [SETTING] Privacy & Security>Logins and Passwords>Use a master password
 * [1] https://support.mozilla.org/kb/use-master-password-protect-stored-logins ***/
/* 0903: как часто Firefox должен запрашивать мастер-пароль
 * 0=the first time (default), 1=every time it's needed, 2=every N minutes (see 0904) ***/
   // user_pref("security.ask_for_password", 2);
// 0904: значение в минутах для (0903)=2, по умолчанию 30
   // user_pref("security.password_lifetime", 5);
/* 0905: disable auto-filling username & password form fields
 * отключить автозаполнение полей имени и пароля
 * [NOTE] Имя и пароль остаются доступны при фокусе в поле ввода
 * [SETTING] Privacy & Security>Logins and Passwords>Autofill logins and passwords ***/
user_pref("signon.autofillForms", false);
// 0909: отключить захват формы для Менеджера паролей [FF51+]
   // user_pref("signon.formlessCapture.enabled", false);
/* 0912: ограничить (или отключить) диалоги учетных данных HTTP-аутентификации,
 * запускаемые субресурсами [FF41+], усиливает защиту от фишинга учетных данных
 * 0=не разрешать субресурсам
 * 1=не разрешать субдресурсам другого происхождения
 * 2=разрешать субресурсам (default) ***/
user_pref("network.auth.subresource-http-auth-allow", 1);
/* 0913: disable automatic authentication on Microsoft sites [FF91+] [WINDOWS 10+]
 * [SETTING] Privacy & Security>Logins and Passwords>Allow Windows single sign-on for...
 * [1] https://support.mozilla.org/kb/windows-sso ***/
user_pref("network.http.windows-sso.enabled", false);

/*** [SECTION 1000]: CACHE / SESSION (RE)STORE / FAVICONS
     Методы снятия отпечатков [1] [2] [3] требуют наличия кэша.
     Отключение дискового кэша (1001) *и возможно* кэша в памяти (1003) - это одно из решений.
     Но настройка временных контейнеров эффективнее [4].

     Мы рекомендуем избегать дискового кэша (1001), что бы кэш был только для сеанса и только в памяти.
     И настроить First Party Isolation (4001), это обеспечит баланс между риском и производительностью.
     ETAGs также можно нейтрализовать измением заголовков ответов [5] и настройкой очистки кэша по времени
     или вручную.

     [1] https://en.wikipedia.org/wiki/HTTP_ETag#Tracking_using_ETags
     [2] https://robertheaton.com/2014/01/20/cookieless-user-tracking-for-douchebags/
     [3] https://www.grepular.com/Preventing_Web_Tracking_via_the_Browser_Cache
     [4] https://medium.com/@stoically/enhance-your-privacy-in-firefox-with-temporary-containers-33925cd6cd21
     [5] https://github.com/arkenfox/user.js/wiki/4.2.4-Header-Editor
***/
user_pref("_user.js.parrot", "1000 syntax error: the parrot's gone to meet 'is maker!");
/** CACHE ***/
/* 1001: disable disk cache
 * [SETUP-PERF] Если вы думаете, что дисковый кэш реально может помочь (тяжелые сайты,
 * HD video), и используете временные контейнеры, то можете переключить этот параметр
 * [NOTE] для очистки кэша при выходе (see 2803) ***/
user_pref("browser.cache.disk.enable", false);
/* 1003: memory cache
 * capacity: -1=determine dynamically (default), 0=none, n=memory capacity in kilobytes ***/
user_pref("browser.cache.memory.enable", true);
   // user_pref("browser.cache.memory.capacity", 0);
/* 1006: disable permissions manager from writing to disk [RESTART]
 * [NOTE] любые изменения разрешений будут только для текущего сеанса ***/
   // user_pref("permissions.memory_only", true); // [HIDDEN PREF]
/* 1007: disable media cache from writing to disk in Private Browsing
 * [NOTE] MSE (Media Source Extensions) are already stored in-memory in PB ***/
user_pref("browser.privatebrowsing.forceMediaMemoryCache", true); // [FF75+]
user_pref("media.memory_cache_max_size", 65536);

/** SESSIONS & SESSION RESTORE ***/
/* 1021: disable storing extra session data [SETUP-CHROME]
 * укажите для каких сайтов сохранять дополнительные данные в сессии
 * содержимое форм, cookie и данные POST:
 * 0=everywhere, 1=unencrypted sites, 2=nowhere ***/
   // user_pref("browser.sessionstore.privacy_level", 2);
// 1022: отключить возобновление сеанса после сбоя
   // user_pref("browser.sessionstore.resume_from_crash", false);
/* 1023: минимальный интервал между сохранениями сеанса
 * Увеличение может помочь на старых машинах и уменьшит запись на диск.
 * Default is 15000 (15 secs). Try 30000 (30 secs), 60000 (1 min) etc
 * [SETUP-CHROME] Это также может повлиять на запись "недавно закрытых вкладок":
 * быстро открытая и закрытая вкладка не успеет записаться ***/
   // user_pref("browser.sessionstore.interval", 15000);
   // user_pref("browser.sessionstore.interval.idle", 3600000);
/* 1024: disable automatic Firefox start and session restore after reboot [FF62+] [WINDOWS]
 * отключить автозапуск Firefox и восстановление сеанса после перезагрузки системы ***/
user_pref("toolkit.winRegisterApplicationRestart", false);

/** FAVICONS ***/
/* 1030: disable favicons in shortcuts
 * URL shortcuts use a cached randomly named .ico file which is stored in your
 * profile/shortcutCache directory. The .ico remains after the shortcut is deleted.
 * If set to false then the shortcuts use a generic Firefox icon ***/
   // user_pref("browser.shell.shortcutFavicons", false);
/* 1031: disable favicons in history and bookmarks
 * Stored as data blobs in favicons.sqlite, these don't reveal anything that your
 * actual history (and bookmarks) already do. Your history is more detailed, so
 * control that instead; e.g. disable history, clear history on close, use PB mode
 * [NOTE] favicons.sqlite is sanitized on Firefox close, not in-session ***/
   // user_pref("browser.chrome.site_icons", false);
/* 1032: disable favicons in web notifications ***/
   // user_pref("alerts.showFavicons", false); // [DEFAULT: false]

/*** [SECTION 1200]: HTTPS (SSL/TLS / OCSP / CERTS / HPKP / CIPHERS)
   CIPHERS могут быть использованы при снятия отпечатков на стороне сервера
   [TEST] https://www.ssllabs.com/ssltest/viewMyClient.html
   [TEST] https://browserleaks.com/ssl
   [TEST] https://ja3er.com/
   [1] https://www.securityartwork.es/2017/02/02/tls-client-fingerprinting-with-bro/
***/
user_pref("_user.js.parrot", "1200 syntax error: the parrot's a stiff!");
/** SSL (Secure Sockets Layer) / TLS (Transport Layer Security) ***/
/* 1201: require safe negotiation
 * Блокирует соединения с серверами, которые не поддерживают RFC 5746 [2], поскольку они
 * потенциально уязвимы для атаки MiTM [3]. Сервер *без* RFC 5746 может быть защищен от атаки
 * если он отключает повторные переговоры, но проблема в том, что браузер не может этого знать.
 * Установка этого pref в true-единственный способ для браузера гарантировать, что не будет
 * никаких небезопасных повторных переговоров на канале между браузером и сервером.
 * [STATS] SSL Labs (July 2021) reports over 99% of sites have secure renegotiation [4]
 * [1] https://wiki.mozilla.org/Security:Renegotiation
 * [2] https://tools.ietf.org/html/rfc5746
 * [3] https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2009-3555
 * [4] https://www.ssllabs.com/ssl-pulse/ ***/
user_pref("security.ssl.require_safe_negotiation", true);
/* 1202: control TLS versions with min and max
 * 1=TLS 1.0, 2=TLS 1.1, 3=TLS 1.2, 4=TLS 1.3
 * [WARNING] Leave these at default, otherwise you alter your TLS fingerprint.
 * [1] https://www.ssllabs.com/ssl-pulse/ ***/
   // user_pref("security.tls.version.min", 3); // [DEFAULT: 3]
   // user_pref("security.tls.version.max", 4);
/* 1203: enforce TLS 1.0 and 1.1 downgrades as session only ***/
user_pref("security.tls.version.enable-deprecated", false); // [DEFAULT: false]
/* 1204: disable SSL session tracking [FF36+]
 * ID SSL сеанса уникальны, хранятся до 24 часов (или дольше при атаках продления)
 * [NOTE] Не исп. в PB режиме, изолированы при использовании FPI (4001) и/или контейнеров.
 * В FF85+ они изолированы по умолчанию (privacy.partition.network_state)
 * [WARNING] Затратно и пассивное снятие отпечатков практически не приносит пользы.
 * Предотвращение отслеживания этим методом не затрагивает IP и текущие идентификаторы. ***/
   // user_pref("security.ssl.disable_session_identifiers", true); // [HIDDEN PREF]
// 1205: disable SSL Error Reporting [ПРИМ] есть в политиках
user_pref("security.ssl.errorReporting.enabled", false);
/* 1206: disable TLS1.3 0-RTT (round-trip time) [FF51+]
 * [1] https://github.com/tlswg/tls13-spec/issues/1001
 * [2] https://blog.cloudflare.com/tls-1-3-overview-and-q-and-a/ ***/
user_pref("security.tls.enable_0rtt_data", false);

/** OCSP (Online Certificate Status Protocol)
    [1] https://scotthelme.co.uk/revocation-is-broken/
    [2] https://blog.mozilla.org/security/2013/07/29/ocsp-stapling-in-firefox/
***/
/* 1211: контроль использования OCSP выборки (для подтверждения текущего действия сертификатов)
 * 0=disabled, 1=enabled (default), 2=enabled for EV certificates only
 * OCSP (не сшитый) пропускает информацию о сайтах которые вы посещаете в CA (центр сертификации)
 * Это компромисс между безопасностью (проверка) и конфиденциальностью (утечка информации в CA)
 * [NOTE] Этот преф управляет только выборкой OCSP и не влияет на сшивание OCSP
 * [1] https://en.wikipedia.org/wiki/Ocsp ***/
user_pref("security.OCSP.enabled", 1);
/* 1212: set OCSP fetch failures (non-stapled, see 1211) to hard-fail [SETUP-WEB]
 * Когда нет доступа к центру сертификации, Firefox просто продолжает соединение (=soft-fail)
 * Установка этого префа в true заставит Firefox разорвать соединение (=hard-fail)
 * Soft-fail не имеет смысла при сбое связи OCSP: вы не знаете действителен ли сертификат или
 * отозван, или вы атакованы (злонамеренная блокировка серверов OCSP).
 * [ПРИМ] Если включен, то возможно именно он мешает префу network.trr.mode=3 ***/
   // user_pref("security.OCSP.require", true);

/** CERTS / HPKP (HTTP Public Key Pinning) ***/
/* 1220: disable or limit SHA-1 certificates
 * 0=all SHA1 certs are allowed
 * 1=all SHA1 certs are blocked
 * 2=deprecated option that now maps to 1
 * 3=only allowed for locally-added roots (e.g. anti-virus)
 * 4=only allowed for locally-added roots or for certs in 2015 and earlier
 * [SETUP-CHROME] При отключении некоторые устройства "человек в середине" (в том числе, антивирусы и их сканеры)
 * могут не суметь подключиться к HTTPS-сайтам. SHA-1 *почти* устарел. ***/
user_pref("security.pki.sha1_enforcement_level", 1);
/* 1221: disable Windows 8.1's Microsoft Family Safety cert [FF50+] [WINDOWS]
 * 0=disable detecting Family Safety mode and importing the root
 * 1=only attempt to detect Family Safety mode (don't import the root)
 * 2=detect Family Safety mode and import the root ***/
user_pref("security.family_safety.mode", 0);
/* 1222: disable intermediate certificate caching (fingerprinting attack vector) [FF41+] [RESTART]
 * [NOTE] This affects login/cert/key dbs. The effect is all credentials are session-only.
 * Сохраненные логины и пароли будут недоступны. Сбросьте настройки и перезапустите, чтобы вернуть их.
 * [1] https://shiftordie.de/blog/2017/02/21/fingerprinting-firefox-users-with-cached-intermediate-ca-certificates-fiprinca/ ***/
   // user_pref("security.nocertdb", true); // [HIDDEN PREF]
/* 1223: enable strict pinning
 * PKP (Public Key Pinning) 0=disabled 1=allow user MiTM (such as your antivirus), 2=strict
 * [SETUP-WEB] Если у вас антивирус главный, то переключите значение на по умолчанию =1 ***/
user_pref("security.cert_pinning.enforcement_level", 2);
/* 1224: enable CRLite [FF73+]
 * In FF84+ it covers valid certs and in mode 2 doesn't fall back to OCSP
 * [1] https://bugzilla.mozilla.org/buglist.cgi?bug_id=1429800,1670985
 * [2] https://blog.mozilla.org/security/tag/crlite/ ***/
user_pref("security.remote_settings.crlite_filters.enabled", true);
user_pref("security.pki.crlite_mode", 2);

/** MIXED CONTENT ***/
/* 1240: отключить небезопасный активный контент на https страницах
 * если раскомментировать часть контента страниц будет недоступна,
 * например, скриншоты юзеров с http хостов на https сайтах\форумах
 * [1] https://gitlab.torproject.org/tpo/applications/tor-browser/-/issues/21323 ***/
   // user_pref("security.mixed_content.block_active_content", true); // [DEFAULT: true]
// 1241: отключить небезопасный пассивный контент (например, изображения) на страницах https [SETUP-WEB]
   // user_pref("security.mixed_content.block_display_content", true);
/* 1244: включить режим только HTTPS [FF76+]
 * Если "https_only_mode" (all windows) = true, то "https_only_mode_pbm" (private windows only) игнорируется
 * [SETTING] to add site exceptions: Padlock>HTTPS-Only mode>On/Off/Off temporarily
 * [SETTING] Privacy & Security>HTTPS-Only Mode
 * [TEST] http://example.com [upgrade]
 * [TEST] http://neverssl.org/ [no upgrade]
 * [ПРИМ] Если по https сайт недоступен, открывается заглушка с вопросом "перейти на http".
 * Отключите HTTPS Everywhere и Smart HTTPS, иначе включать это смысла нет.
 * Но заглушка появляется где попало, в том числе на https сайтах, так как многие из них
 * используют перенаправление по http, пример - https://forum.mozilla-russia.org,
 * после авторизации или при отправке сообщения.
 * Что бы мимнимизировать, но не убрать полностью, этот глюк, переключите 1246 в false или
 * увеличте задержку http запроса. Для меня режим неработоспособен, остаюсь на Smart HTTPS
 * [1] https://bugzilla.mozilla.org/1613063 [META] ***/
   // user_pref("dom.security.https_only_mode", true); // [FF76+]
   // user_pref("dom.security.https_only_mode_pbm", true); // [FF80+]
// 1245: enable HTTPS-Only mode for local resources [FF77+]
   // user_pref("dom.security.https_only_mode.upgrade_local", true); // [FF77+]
/* 1246: disable HTTP background requests [FF82+]
 * При попытке обновления, если сервер не отвечает, firefox отправляет HTTP-запросы,
 * чтобы проверить, поддерживает ли сервер HTTPS или нет. Только для "https_only_mode".
 * Это делается для того, чтобы избежать тайм-аута, который занимает 90 секунд.
 * [1] https://bugzilla.mozilla.org/buglist.cgi?bug_id=1642387,1660945 ***/
   // user_pref("dom.security.https_only_mode_send_http_background_request", false);
/* [ПРИМ] Время задержки send_http_background_request, если включен 1246.
 * чем медленнее ваше соединение или сетевой отклик, тем больше нужно ставить ***/
user_pref("dom.security.https_only_fire_http_request_background_timer_ms", 6000); // по умолчанию 3000 (т.е. 3 сек)
/* 1247: treat .onion as a secure context [FF60+] [TOR]
 * [NOTE] Firefox cannot access .onion sites by default: it is strongly recommended you just use Tor Browser
 * [1] https://bugzilla.mozilla.org/1382359 ***/
   // user_pref("dom.securecontext.whitelist_onions", true);

/** CIPHERS [WARNING: не подлежит редактированию]
 * Это шифры, перечисленные в разделе "Наборы шифров" [1], которые либо используют SHA-1 и CBC,
 * и/или не имеют Perfect Forward Secrecy [3], и/или имеют другие недостатки, такие как размер ключа 128
 * [1] https://browserleaks.com/ssl
 * [2] https://en.wikipedia.org/wiki/Key_size
 * [3] https://en.wikipedia.org/wiki/Forward_secrecy
 * Удалил эту секцию ***/
 
/** UI (User Interface) ***/
// 1270: предупреждение на "замке" для "сломанной безопасности" (если 1201 = false)
user_pref("security.ssl.treat_unsafe_negotiation_as_broken", true);
/* 1271: диалог "добавить исключение безопасности" для предупреждений SSL
 * 0=do neither 1=pre-populate url 2=pre-populate url + pre-fetch cert (default) ***/
user_pref("browser.ssl_override_behavior", 1);
/* 1272: отображение доп. информации на страницах предупреждений о небезопасном подключении,
 * работает только тогда, когда можно добавить исключение ***/
user_pref("browser.xul.error_pages.expert_bad_cert", true);
// 1273: display "insecure" icon on HTTP sites
   // user_pref("security.insecure_connection_icon.enabled", true); // [FF59+] [DEFAULT: true]
// and "Not Secure" text
user_pref("security.insecure_connection_text.enabled", false); // [FF60+] [DEFAULT: true]

/*** [SECTION 1400]: FONTS ***/
user_pref("_user.js.parrot", "1400 syntax error: the parrot's bereft of life!");
/* 1401: запретить веб-сайтам выбирать шрифты (0=block, 1=allow)
 * [ПРИМ] Просто изуродует все сайты
 * [WARNING] DO NOT USE: in FF80+ RFP covers this, and non-RFP users should use font vis (4620)
 * [SETTING] General>Language and Appearance>Fonts & Colors>Advanced>Allow pages to choose... ***/
   // user_pref("browser.display.use_document_fonts", 0);
// 1403: disable icon fonts (glyphs) and local fallback rendering
   // user_pref("gfx.downloadable_fonts.enabled", false); // [FF41+]
   // user_pref("gfx.downloadable_fonts.fallback_delay", -1);
// 1404: disable rendering of SVG OpenType fonts
   // user_pref("gfx.font_rendering.opentype_svg.enabled", false);
/* 1408: disable graphite
 * Graphite has had many critical security issues in the past [1]
 * [1] https://www.mozilla.org/security/advisories/mfsa2017-15/#CVE-2017-7778
 * [2] https://en.wikipedia.org/wiki/Graphite_(SIL) ***/
user_pref("gfx.font_rendering.graphite.enabled", false);
/* 1409: limit system font exposure to a whitelist [FF52+] [RESTART]
 * [ПРИМ] Перечислить шрифты. Изуродует сайты с шрифтами не из списка.
 * [NOTE] In FF81+ the whitelist **overrides** RFP's font visibility (see 4620)
 * [WARNING] DO NOT USE: in FF80+ RFP covers this, and non-RFP users should use font vis (4620)
 * [1] https://bugzilla.mozilla.org/1121643 ***/
   // user_pref("font.system.whitelist", ""); // [HIDDEN PREF]

/*** [SECTION 1600]: HEADERS / REFERERS
     Только *cross domain* рефереры нуждаются в контроле: оставьте в покое 1601, 1602, 1605 и 1606
     ---
     [ПРИМ] Если параметр 1601 держать =1, но тогда поломаются очень редкие сайты, например,
     https://userstyles.org. Расширения этот параметр НЕ контролируют.
     Параметр 1602 лучше регулировать расширением, иначе ожидайте поломок, например, общие
     правила Referer Modifier "любой" = обрезать, "тот же" = оставить и далее настраивать
     индивидуальные правила (или не настраивать, так как вроде ничего не ломается)
     https://addons.mozilla.org/ru/firefox/addon/referer-modifier
     
     Излишне строгое переопределение CROSS ORIGIN тоже ломает сайты, рекомендации читайте ниже.
     ---
                    full URI: https://example.com:8888/foo/bar.html?id=1234
       scheme+host+port+path: https://example.com:8888/foo/bar.html
            scheme+host+port: https://example.com:8888
     ---
     [1] https://feeding.cloud.geek.nz/posts/tweaking-referrer-for-privacy-in-firefox/
***/
user_pref("_user.js.parrot", "1600 syntax error: the parrot rests in peace!");
/* 1601: ALL: control when images/links send a referer
 * когда изображениям и (или только) ссылкам отправлять реферер
 * 0=never, 1=send only when links are clicked, 2=for links and images (default) ***/
   // user_pref("network.http.sendRefererHeader", 1); // [DEFAULT: 2]
/* 1602: ALL: control the amount of information to send
 * объем отправляемой информации
 * [ПРИМ] Более гибко можно настроить расширением
 * 0=send full URI (default), 1=scheme+host+port+path, 2=scheme+host+port ***/
   // user_pref("network.http.referer.trimmingPolicy", 2); // [DEFAULT: 0]
/* 1603: CROSS ORIGIN: куда отправлять реферер
 * 0=always (default), 1=only if base domains match, 2=only if hosts match
 * [SETUP-WEB] [ПРИМ] =2 вызывает проблемы со старыми модемами/роутерами
 * и некоторыми сайтами (vimeo, icloud, tiktok ...), пробуйте =1
 * [CHECK] ***/
   // user_pref("network.http.referer.XOriginPolicy", 1);
/* 1604: CROSS ORIGIN: объем отправляемой информации [FF52+]
 * 0=send full URI (default), 1=scheme+host+port+path, 2=scheme+host+port
 * [CHECK] ***/
   // user_pref("network.http.referer.XOriginTrimmingPolicy", 2);
/* 1605: ALL: disable spoofing a referer
 * [WARNING] Do not set this to true, as spoofing effectively disables the anti-CSRF
 * (Cross-Site Request Forgery) protections that some sites may rely on ***/
   // user_pref("network.http.referer.spoofSource", false); // [DEFAULT: false]
/* 1606: ALL: set the default Referrer Policy [FF59+]
 * 0=no-referer, 1=same-origin, 2=strict-origin-when-cross-origin, 3=no-referrer-when-downgrade
 * [NOTE] Это только значение по умолчанию, оно может быть отменено политикой сайта.
 ***/
   // user_pref("network.http.referer.defaultPolicy", 2); // [DEFAULT: 2 FF87+]
   // user_pref("network.http.referer.defaultPolicy.pbmode", 2); // [DEFAULT: 2]
/* 1607: hide (not spoof) referrer when leaving a .onion domain [FF54+] [TOR]
 * [NOTE] Firefox cannot access .onion sites by default: it is strongly recommended you just use Tor Browser
 * [1] https://bugzilla.mozilla.org/1305144 ***/
   // user_pref("network.http.referer.hideOnionSource", true);
/* 1610: ALL: enable the DNT (Do Not Track) HTTP header
 * [NOTE] DNT применяется с улучшенной защитой от отслеживания независимо от этого префа
 * [SETTING] Privacy & Security>Enhanced Tracking Protection>Send websites a "Do Not Track" signal... ***/
   // user_pref("privacy.donottrackheader.enabled", true);

/*** [SECTION 1700]: CONTAINERS
     If you want to *really* leverage containers, we highly recommend Temporary Containers [2].
     Read the article by the extension author [3], and check out the github wiki/repo [4].
     [1] https://wiki.mozilla.org/Security/Contextual_Identity_Project/Containers
     [2] https://addons.mozilla.org/firefox/addon/temporary-containers/
     [3] https://medium.com/@stoically/enhance-your-privacy-in-firefox-with-temporary-containers-33925cd6cd21
     [4] https://github.com/stoically/temporary-containers/wiki
***/
user_pref("_user.js.parrot", "1700 syntax error: the parrot's bit the dust!");
/* 1701: enable Container Tabs setting in preferences (see 1702) [FF50+]
 * [1] https://bugzilla.mozilla.org/1279029 ***/
user_pref("privacy.userContext.ui.enabled", true);
/* 1702: enable Container Tabs [FF50+]
 * [SETTING] General>Tabs>Enable Container Tabs ***/
user_pref("privacy.userContext.enabled", true);
/* 1703: set behaviour on "+ Tab" button to display container menu on left click [FF74+]
 * [NOTE] Меню всегда отображается при долгом нажатии ЛКМ или щелчке ПКМ
 * [SETTING] General>Tabs>Enable Container Tabs>Settings>Select a container for each new tab ***/
   // user_pref("privacy.userContext.newTabContainerOnLeftClick.enabled", true);

/*** [SECTION 1800]: PLUGINS ***/
user_pref("_user.js.parrot", "1800 syntax error: the parrot's pushing up daisies!");
/* 1820: disable GMP (Gecko Media Plugins)
 * Больше см. в секции OpenH264 в конце файла ***/
user_pref("media.gmp-provider.enabled", false);
/* 1825: disable widevine CDM (Content Decryption Module)
 * [NOTE] This is covered by the EME master switch (1830) ***/
user_pref("media.gmp-widevinecdm.visible", false);
user_pref("media.gmp-widevinecdm.enabled", false);
/* 1830: disable all DRM content (EME: Encryption Media Extension)
 * EME-free - переключить если пользуетесь кодеком
 * [SETUP-WEB] e.g. Netflix, Amazon Prime, Hulu, HBO, Disney+, Showtime, Starz, DirectTV
 * [SETTING] General>DRM Content>Play DRM-controlled content
 * [TEST] https://bitmovin.com/demos/drm
 ***/
user_pref("media.eme.enabled", false);

/*** [SECTION 2000]: MEDIA / CAMERA / MIC ***/
user_pref("_user.js.parrot", "2000 syntax error: the parrot's snuffed it!");
/* 2001: disable WebRTC (Web Real-Time Communication)
 * [SETUP-WEB] WebRTC сливает налево ваш реальный IP-адрес под VPN и прокси.
 * false - cломает возможность общения в режиме реального времени ***/
user_pref("media.peerconnection.enabled", false);
/* 2002: limit WebRTC IP leaks if using WebRTC
 * In FF70+ these settings match Mode 4 (Mode 3 in older versions)
 * [TEST] https://browserleaks.com/webrtc ***/
user_pref("media.peerconnection.ice.default_address_only", true);
user_pref("media.peerconnection.ice.no_host", true); // [FF51+]
user_pref("media.peerconnection.ice.proxy_only_if_behind_proxy", true); // [FF70+]
/* 2010: disable WebGL (Web Graphics Library)
 * [SETUP-WEB] Когда отключено, могут сломаться некоторые сайты. Включение дает
 * высокую энтропию, особенно с readPixels(). Также см. RFP (4501) ***/
user_pref("webgl.disabled", true);
user_pref("webgl.enable-webgl2", false);
// 2012: limit WebGL
user_pref("webgl.disable-fail-if-major-performance-caveat", true); // [DEFAULT: true FF86+]
// 2022: disable screensharing
user_pref("media.getusermedia.screensharing.enabled", false);
user_pref("media.getusermedia.browser.enabled", false);
user_pref("media.getusermedia.audiocapture.enabled", false);
/* 2024: разрешения по умолчанию для Camera/Microphone [FF58+]
 * 0=always ask (default), 1=allow, 2=block
 * [SETTING] исключения для отдельных сайтов настраиваются: Ctrl+I>Permissions>Use the Camera/Microphone
 * [SETTING] менеджер исключений: Options>Privacy & Security>Permissions>Camera/Microphone>Settings
 * [CHECK] ***/
   // user_pref("permissions.default.camera", 2);
   // user_pref("permissions.default.microphone", 2);
/* 2030: отключить, насколько это возможно, автозапуск мультимедиа HTML5 [FF63+]
 * 0=Allow all, 1=Block non-muted media (default in FF67+), 2=Prompt (removed in FF66), 5=Block all (FF69+)
 * [NOTE] Исключения можно установить в разрешениях для сайта
 * (Информация о странице [Ctrl+I] >> Разрешения)
 * [SETTING] Privacy & Security>Permissions>Autoplay>Settings>Default for all websites ***/
user_pref("media.autoplay.default", 5);
/* 2031: отключить автозапуск мультимедиа HTML5 при взаимодействии с сайтом [FF78+]
 * 0=sticky (default), 1=transient, 2=user
 * [NOTE] Если у вас возникли проблемы с некоторыми видеосайтами, то добавьте исключение (see 2030)
 * [ПРИМ] Автор рекомендует 2, но тогда ломается воспроизведение по клику на некоторых сайтах,
 * а исключения превращают такой сайт в нон-стоп шарманку ***/
user_pref("media.autoplay.blocking_policy", 1);

/*** [SECTION 2200]: WINDOW MEDDLING & LEAKS / POPUPS ***/
user_pref("_user.js.parrot", "2200 syntax error: the parrot's 'istory!");
// 2202: запретить скриптам перемещать и изменять размер ОТКРЫТЫХ окон
user_pref("dom.disable_window_move_resize", true);
/* 2203: открывать ссылки во вкладках, даже если они нацелены на новое окно
 * Это останавливает ресайз вредоносных окон и некоторые утечки разрешения экрана.
 * Вы все еще можете щелкнуть правой кнопкой мыши ссылку и открыть ее в новом окне.
 * [TEST] https://arkenfox.github.io/TZP/tzp.html#screen ***/
user_pref("browser.link.open_newwindow", 3); // 1=most recent window or tab 2=new window, 3=new tab
user_pref("browser.link.open_newwindow.restriction", 0);
/* 2204: disable Fullscreen API (requires user interaction) to prevent screen-resolution leaks
 * [NOTE] Вы все еще сможете вручную переключить полноэкранное состояние браузера (F11), но
 * этот преф отключит встроенные полноэкранные эл. управления видео/игрой, например на youtube
 * [TEST] https://arkenfox.github.io/TZP/tzp.html#screen ***/
   // user_pref("full-screen-api.enabled", false);
/* 2210: блокировать всплывающие окна
 * [SETTING] Privacy & Security>Permissions>Block pop-up windows ***/
user_pref("dom.disable_open_during_load", true);
/* 2212: ограничить события, вызывающие всплывающие окна [SETUP-WEB], по умолчанию используются:
 * change click dblclick auxclick mousedown mouseup pointerdown pointerup notificationclick reset submit touchend contextmenu ***/
user_pref("dom.popup_allowed_events", "click dblclick mousedown pointerdown");

/*** [SECTION 2300]: WEB WORKERS ***/
/**  Worker - это "фоновая задача" JS, выполняемая в глобальном контексте.
     Workers могут порождать новых workers (должны иметь одинаковое происхождение и схему),
     включая сервисных и общих workers. Общие workers могут использоваться несколькими сценариями
     и взаимодействовать между контекстами (windows / tabs / iframes) и даже управлять кэшем. ***/
user_pref("_user.js.parrot", "2300 syntax error: the parrot's off the twig!");
/* 2302: disable service workers [FF32, FF44-compat]
 * Service workers по сути действуют как прокси между веб-приложениями, браузером и сетью,
 * управляются и сами управляют веб-страницами с которыми связаны, перехватывая и изменяя
 * запросы, и кэшируя ресурсы.
 * [NOTE] API Service worker скрыты (в Firefox) и не могут быть использованы в режиме PB.
 * [NOTE] Service workers работают только по HTTPS и не имеют доступа к DOM.
 * [SETUP-WEB] Отключение service workers приведет к поломке некоторых редких сайтов.
 * Этот преф требует true для service worker уведомлений (2304), push-уведомлений (2305)
 * и service worker кэша (2740). Если вы переключаете этот преф, то проверьте и эти настройки ***/
user_pref("dom.serviceWorkers.enabled", false);
// 2304: disable Web Notifications
   // user_pref("dom.webnotifications.enabled", false); // [FF22+]
   // user_pref("dom.webnotifications.serviceworker.enabled", false); // [FF44+]
// 2305: disable Push Notifications [FF44+]
user_pref("dom.push.enabled", false);
   // user_pref("dom.push.userAgentID", "");
/* 2306: set a default permission for Notifications (both 2304 and 2305) [FF58+]
 * 0=always ask (default), 1=allow, 2=block
 * [NOTE] Если включен 2305, то это лучше оставить (default), отпечатки можно снять через API разрешений
 * [SETTING] to add site exceptions: Ctrl+I>Permissions>Receive Notifications
 * [SETTING] to manage site exceptions: Options>Privacy & Security>Permissions>Notifications>Settings ***/
   // user_pref("permissions.default.desktop-notification", 2);

/*** [SECTION 2400]: DOM (DOCUMENT OBJECT MODEL) & JAVASCRIPT ***/
user_pref("_user.js.parrot", "2400 syntax error: the parrot's kicked the bucket!");
/* 2401: disable website control over browser right-click context menu
 * [NOTE] Shift-Right-Click will always bring up the browser right-click context menu 
 * [ПРИМ] Контекстное меню будет вызываться где попало, например в сайдбарах расширений.
 * Лучше воспользоваться скриптом. ***/
   // user_pref("dom.event.contextmenu.enabled", false);
/* 2402: отключение доступа сайтов к буферу обмена [SETUP-HARDEN]
 * [NOTE] Поломает функционал копирования\вставки сайтов типа Outlook, Twitter, Facebook, Wordpress
 * [WARNING] В FF88 или ниже, с включенным clipboardevents, если параметры "middlemouse.paste"
 * и "general.AutoScroll" имеют значение true, буфер обмена может утечь.
 * По крайней мере, один должен быть false. [1]
 * [1] https://bugzilla.mozilla.org/1528289 ***/
   // user_pref("dom.event.clipboardevents.enabled", false);
/* 2404: disable clipboard commands (cut/copy) from "non-privileged" content [FF41+]
 * this disables document.execCommand("cut"/"copy") to protect your clipboard. ***/
   // user_pref("dom.allow_cut_copy", false);
/* 2405: отключить диалог подтверждения об уходе со страницы
 * Не предотвращает JS утечку события закрытия страницы. ***/
user_pref("dom.disable_beforeunload", true);
// 2414: disable shaking the screen
user_pref("dom.vibrator.enabled", false);
/* 2420: disable asm.js [FF22+] [SETUP-PERF]
 * [6] https://rh0dev.github.io/blog/2017/the-return-of-the-jit/ ***/
user_pref("javascript.options.asmjs", false);
/* 2422: disable WebAssembly [FF52+]
 * Все чаще обнаруживаются уязвимости, в том числе известные и исправленные в собственных программах
 * несколько лет назад [2]. WASM обладает мощным низкоуровневым доступом, что делает некоторые атаки
 * (brute-force) и уязвимости более возможными
 * [STATS] ~0,2% сайтов, около половины из которых предназначены для крипто-майнинга и вредоносной рекламы
 * [ПРИМ] Ломает некоторые сайты, например https://bin.snopyta.org/ , но пока только он и попался ***/
user_pref("javascript.options.wasm", false);
/* 2429: включить (ограниченную, но достаточную) защиту window.opener [FF65+]
 * Делает rel=noopener скрытым для target=_blank, когда атрибут rel не установлен ***/
user_pref("dom.targetBlankNoOpener.enabled", true); // [DEFAULT: true FF79+]

/*** [SECTION 2500]: HARDWARE FINGERPRINTING ***/
user_pref("_user.js.parrot", "2500 syntax error: the parrot's shuffled off 'is mortal coil!");
// 2502: disable Battery Status API (недоступен сайтам и расширениям)
   // user_pref("dom.battery.enabled", false);
/* 2508: disable hardware acceleration to reduce graphics fingerprinting [SETUP-HARDEN]
 * [WARNING] Влияет на рендеринг текста (шрифты будут выглядеть иначе), влияет на производительность
 * видео, а также на части Quantum, использующие графический процессор, по мере их развертывания.
 * [SETTING] General>Performance>Custom>Use hardware acceleration when available
 * [1] https://wiki.mozilla.org/Platform/GFX/HardwareAcceleration ***/
   // user_pref("gfx.direct2d.disabled", true); // [WINDOWS]
   // user_pref("layers.acceleration.disabled", true);
/* 2510: disable Web Audio API [FF51+]
 * [1] https://bugzilla.mozilla.org/1288359 ***/
user_pref("dom.webaudio.enabled", false);
/* 2517: disable Media Capabilities API [FF63+]
 * [WARNING] This *may* affect media performance if disabled, no one is sure
 * [1] https://github.com/WICG/media-capabilities
 * [2] https://wicg.github.io/media-capabilities/#security-privacy-considerations ***/
   // user_pref("media.media-capabilities.enabled", false);
/* 2520: disable virtual reality devices
 * Optional protection depending on your connected devices
 * [1] https://developer.mozilla.org/docs/Web/API/WebVR_API ***/
   // user_pref("dom.vr.enabled", false);
/* 2521: set a default permission for Virtual Reality (see 2520) [FF73+]
 * 0=always ask (default), 1=allow, 2=block
 * [SETTING] to add site exceptions: Ctrl+I>Permissions>Access Virtual Reality Devices
 * [SETTING] to manage site exceptions: Options>Privacy & Security>Permissions>Virtual Reality>Settings ***/
   // user_pref("permissions.default.xr", 2);
/* 2522: disable/limit WebGL (Web Graphics Library)
 * [SETUP-WEB] When disabled, will break some websites. When enabled, provides high entropy,
 * especially with readPixels(). Some of the other entropy is lessened with RFP (see 4501)
 * [1] https://www.contextis.com/resources/blog/webgl-new-dimension-browser-exploitation/
 * [2] https://security.stackexchange.com/questions/13799/is-webgl-a-security-concern ***/
user_pref("webgl.disabled", true);
user_pref("webgl.enable-webgl2", false);
user_pref("webgl.disable-fail-if-major-performance-caveat", true); // [DEFAULT: true FF86+]

/*** [SECTION 2600]: MISCELLANEOUS ***/
user_pref("_user.js.parrot", "2600 syntax error: the parrot's run down the curtain!");
/* 2601: prevent accessibility services from accessing your browser [RESTART]
 * [SETTING] Privacy & Security>Permissions>Prevent accessibility services from accessing your browser
 * Запретить "службам поддержки доступности" доступ к вашему браузеру ***/
user_pref("accessibility.force_disabled", 1);
// 2602: disable sending additional analytics to web servers
user_pref("beacon.enabled", false);
// 2603: remove temp files opened with an external application
user_pref("browser.helperApps.deleteTempFileOnExit", true);
// 2604: отключить создание thumbnail в папке профиля ***/
user_pref("browser.pagethumbnails.capturing_disabled", true); // [HIDDEN PREF]
// 2606: disable UITour backend so there is no chance that a remote page can use it
user_pref("browser.uitour.enabled", false);
user_pref("browser.uitour.url", "");
/* 2611: disable middle mouse click opening links from clipboard
 * отключить СКМ для открытия ссылок из буфера обмена ***/
   // user_pref("middlemouse.contentLoadURL", false);
/* 2615: disable websites overriding Firefox's keyboard shortcuts [FF58+]
 * 0 (default) or 1=allow, 2=block
 * [SETTING] to add site exceptions: Ctrl+I>Permissions>Override Keyboard Shortcuts ***/
   // user_pref("permissions.default.shortcuts", 2);
// 2616: удалить специальные разрешения для определенных доменов Mozilla [FF35+]
user_pref("permissions.manager.defaultsUrl", "");
// 2617: удалить белый список веб-каналов
user_pref("webchannel.allowObject.urlWhitelist", "");
/* 2619: use Punycode in Internationalized Domain Names to eliminate possible spoofing
 * Firefox has *some* protections, but it is better to be safe than sorry
 * [SETUP-WEB] Нежелательно для не латинского алфавита, стандартные IDN также кодируются punycoded
 * [TEST] https://www.xn--80ak6aa92e.com/ (www.apple.com) ***/
   // user_pref("network.IDN_show_punycode", true);
/* 2620: enforce PDFJS, disable PDFJS scripting [SETUP-CHROME]
 * Этот параметр определяет, доступна ли опция "Отображать в Firefox" в приведенном ниже параметре,
 * а также определяет, обрабатываются ли PDF-файлы в браузере или внешне ("Ask "или" Open With")
 * [SETTING] General>Applications>Portable Document Format (PDF) ***/
   // user_pref("pdfjs.disabled", false); // [DEFAULT: false]
// Отключить выполнение JavaScript в PDF-документах
user_pref("pdfjs.enableScripting", false); // [FF86+]
/* 2621: disable links launching Windows Store on Windows 8/8.1/10 [WINDOWS]
 * отключить запуск ссылок Windows Store на Windows 8/8.1/10 ***/
   // user_pref("network.protocol-handler.external.ms-windows-store", false);
/* 2622: enforce no system colors; they can be fingerprinted
 * [SETTING] General>Language and Appearance>Fonts and Colors>Colors>Use system colors
 * [CHECK] ***/
   // user_pref("browser.display.use_system_colors", false); // [DEFAULT: false]
/* 2623: disable permissions delegation [FF73+]
 * В настоящее время применяется к геолокации, разрешениям на камеру, микрофон и общий доступ к экрану,
 * а также полноэкранным запросам. Означает, что любые запросы будут показывать/использовать
 * их правильное стороннее происхождение ***/
user_pref("permissions.delegation.enabled", false);
/* 2624: enable "window.name" protection [FF82+]
 * Если на вкладку загружена новая страница другого домена, то window.name устанавливается в "пусто".
 * При возврате исходной страницы строка восстанавливается. Предотвращает некоторые межсайтовые атаки.
 * [TEST] https://arkenfox.github.io/TZP/tests/windownamea.html ***/
user_pref("privacy.window.name.update.enabled", true); // [DEFAULT: true FF86+]
// 2625: disable bypassing 3rd party extension install prompts [FF82+]
user_pref("extensions.postDownloadThirdPartyPrompt", false);
/* 2626: enforce non-native widget theme
 * Security: removes/reduces system API calls, e.g. win32k API [1]
 * Fingerprinting: provides a uniform look and feel across platforms [2]
 * [1] https://bugzilla.mozilla.org/1381938
 * [2] https://bugzilla.mozilla.org/1411425 ***/
user_pref("widget.non-native-theme.enabled", true); // [DEFAULT: true FF89+]

/*** DOWNLOADS ***/
/* 2650: препятствовать загрузке на рабочий стол
 * 0=desktop, 1=downloads (default), 2=last used
 * [SETTING] To set your default "downloads": General>Downloads>Save files to ***/
   // user_pref("browser.download.folderList", 2);
/* 2651: всегда спрашивать, где сохранить
 * [SETUP-CHROME] На Android это блокирует долгое нажатие и сохранение изображений
 * [SETTING] General>Downloads>Always ask you where to save files ***/
   // user_pref("browser.download.useDownloadDir", false);
// 2652: отключить добавление загрузок в список "последние документы" системы
user_pref("browser.download.manager.addToRecentDocs", false);
/* 2654: disable "open with" in download dialog [FF50+] [SETUP-HARDEN]
 * Полезно включить, когда браузер изолирован (например, через AppArmor)
 * таким образом, что ему запрещено запускать внешние приложения
 * [WARNING] This may interfere with some users' workflow or methods ***/
   // user_pref("browser.download.forbid_open_with", true);

/** EXTENSIONS ***/
/* 2660: lock down allowed extension directories
 * [SETUP-CHROME] Это отключит расширения, языковые пакеты, темы и любые другие XPI,
 * установленные вне каталогов профилей и приложения ***/
user_pref("extensions.enabledScopes", 5); // [HIDDEN PREF]
user_pref("extensions.autoDisableScopes", 15); // [DEFAULT: 15]
// 2662: отключить ограничения webextension для определенных доменов Mozilla (you also need 4503) [FF60+]
user_pref("extensions.webextensions.restrictedDomains", "");

/** SECURITY ***/
/* 2680: enforce CSP (Content Security Policy)
 * [NOTE] CSP является очень важной и широко распространенной функцией безопасности. Не отключайте его!
 * [1] https://developer.mozilla.org/docs/Web/HTTP/CSP ***/
user_pref("security.csp.enable", true); // [DEFAULT: true]
// 2684: задержка безопасности на некоторые подтверждения, например, установить, открыть/сохранить
user_pref("security.dialog_enable_delay", 1000); // [DEFAULT: 1000]

/*** [SECTION 2700]: PERSISTENT STORAGE
     Data SET by websites including
            cookies : profile\cookies.sqlite
       localStorage : profile\webappsstore.sqlite
          indexedDB : profile\storage\default
           appCache : profile\OfflineCache
     serviceWorkers :

     [NOTE] indexedDB и serviceWorkers недоступны в режиме приватного просмотра
     [NOTE] Блокировка файлов cookie также блокирует доступ сайтов к localStorage (и sessionStorage),
     indexedDB, sharedWorker и serviceWorker (а следовательно и worker-у кэша и уведомлений).
     Если вы устанавливаете сайту исключение для cookies ("разрешить" или "разрешить на сессию"),
     то все перечисленное становится доступным для сайтов, за исключением shared/service workers,
     для него настройка cookies *должна* быть "Разрешить". ***/
user_pref("_user.js.parrot", "2700 syntax error: the parrot's joined the bleedin' choir invisible!");
/* 2701: disable 3rd-party cookies and site-data [SETUP-WEB]
 * 0 = Принимать куки и данные сайта,
 * 1 = Блокировать все сторонние куки,
 * 2 = Блокировать все куки,
 * 3 = Блокировать куки с не посещенных сайтов,
 * 4 = Блокировать кросс-сайты и соц-медиа трекеры (default FF69+)
 * 5 = (Изолировать все) Cross-site cookies (TCP: Total Cookie Protection / dFPI: dynamic FPI) [1] (FF86+)
 * Вариант 5 с включенным FPI (4001) игнорируется и не отображается, вместо него используется вариант 4
 * [NOTE] В разрешениях для сайта можно установить исключения или использовать расширение
 * [NOTE] Категория "custom" гарантирует соблюдение префов Enhanced Tracking Protection
 * [SETTING] Privacy & Security>Enhanced Tracking Protection>Custom>Cookies
 * [1] https://blog.mozilla.org/security/2021/02/23/total-cookie-protection/
 * [CHECK] ***/
   // user_pref("network.cookie.cookieBehavior", 1);
user_pref("browser.contentblocking.category", "custom");
/* 2702: устанавливать сторонние cookie (если включено в 2701) только для сеанса
   [NOTE] .sessionOnly отменяет .nonsecureSessionOnly кроме случая когда .sessionOnly=false,
    а .nonsecureSessionOnly=true. Это позволяет сохранять HTTPS-куки на постоянку,
    а HTTP-куки только до конца сеанса.***/
user_pref("network.cookie.thirdparty.sessionOnly", true);
user_pref("network.cookie.thirdparty.nonsecureSessionOnly", true); // [FF58+]
/* 2703: удалять куки и данные сайта при закрытии (см. [SECTION 2800])
 * 0=keep until they expire (default), 2=keep until you close Firefox
 * [NOTE] преф отключается (но не изменяется), если вы блокируете все cookie (2701 = 2)
 * [SETTING] Privacy & Security>Cookies and Site Data>Delete cookies and site data when Firefox is closed ***/
   // user_pref("network.cookie.lifetimePolicy", 2);
/* 2710: enable Enhanced Tracking Protection (ETP) in all windows
 * [SETTING] Privacy & Security>Enhanced Tracking Protection>Custom>Tracking content
 * [SETTING] to add site exceptions: Urlbar>ETP Shield
 * [SETTING] to manage site exceptions: Options>Privacy & Security>Enhanced Tracking Protection>Manage Exceptions ***/
user_pref("privacy.trackingprotection.enabled", true);
/* 2711: включить списки блокировки ETP ***/
user_pref("privacy.trackingprotection.socialtracking.enabled", true);
   // user_pref("privacy.trackingprotection.cryptomining.enabled", true); // [DEFAULT: true]
   // user_pref("privacy.trackingprotection.fingerprinting.enabled", true); // [DEFAULT: true]
/* 2730: disable offline cache (appCache)
 * [NOTE] В FF90+ возможность хранения была удалена (1694662)
 * Так что параметр ни на что не влияет. Оставил для сброса старых настроек ***/
user_pref("browser.cache.offline.enable", false);
/* 2740: disable service worker cache and cache storage
 * [NOTE] Можно просто очищать кэш service worker при закрытии Firefox (see 2803)
 * Сами service worker отключены в (2302) ***/
   // user_pref("dom.caches.enabled", false);
/* 2750: disable Storage API [FF51+]
 * The API gives sites the ability to find out how much space they can use, how much
 * they are already using, and even control whether or not they need to be alerted
 * before the user agent disposes of site data in order to make room for other things.
 ***/
   // user_pref("dom.storageManager.enabled", false);
/* 2755: disable Storage Access API [FF65+]
 * [1] https://developer.mozilla.org/docs/Web/API/Storage_Access_API ***/
   // user_pref("dom.storage_access.enabled", false);
/* 2760: enable Local Storage Next Generation (LSNG) [FF65+] 
 * Бесполезный параметр - отключить его можно, только если в config.js
 * добавить - dom.storage.next_gen_auto_enabled_by_cause1=false. ***/
user_pref("dom.storage.next_gen", true);

/*** [SECTION 2800]: SHUTDOWN
     Очистка при закрытии не использует исключения из настроек "Приватность и защита > Куки и данные сайтов" (1681701)
     - Если вы хотите сохранить куки некоторых сайтов (исключение "Разрешить") и, по желанию,
       другие данные сайтов, но очищать все остальное при закрытии, то вам нужно установить,
       в этой секции ниже, "cookie". и, по желанию, "offlineApps" в значение =false,
       а время жизни cookie в секции 2703 в значение =2
     Вы должны установить значения в соответствии с тем, что вам больше всего подходит.
     - "Данные автономных веб-сайтов" включают в себя: appCache (2730), localStorag (2720),
       кэш service worker (2740) и QuotaManager (IndexedDB, asm-cache).
     - В обоих префах 2803 + 2804 "загрузка" и "история" объединены в интерфейсе Firefox как
       "История просмотра и загрузки", и их значения будут синхронизированы
***/
user_pref("_user.js.parrot", "2800 syntax error: the parrot's bleedin' demised!");
/* 2802: включить очистку при завершении работы Firefox (see 2803)
 * [SETTING] Privacy & Security>History>Custom Settings>Clear history when Firefox closes ***/
   // user_pref("privacy.sanitize.sanitizeOnShutdown", true);
/* 2803: элементы для очистки при завершении работы (если 2802 = true) [SETUP-CHROME]
 * [NOTE] Если 'history' - true, загрузки также будут очищены
 * [SETTING] Privacy & Security>History>Custom Settings>Clear history when Firefox closes>Settings
 * [CHECK]-all ***/
   // user_pref("privacy.clearOnShutdown.cache", true);
   // user_pref("privacy.clearOnShutdown.cookies", true);
   // user_pref("privacy.clearOnShutdown.downloads", true); // see note above
   // user_pref("privacy.clearOnShutdown.formdata", true); // Form & Search History
   // user_pref("privacy.clearOnShutdown.history", true); // Browsing & Download History
   // user_pref("privacy.clearOnShutdown.offlineApps", true); // Offline Website Data
   // user_pref("privacy.clearOnShutdown.sessions", true); // Active Logins
   // user_pref("privacy.clearOnShutdown.siteSettings", false); // Site Preferences
/* 2804: сброс элементов при очистке по Ctrl-Shift-Del (to match 2803) [SETUP-CHROME]
 * Firefox помнит последний выбор, это будет возвращать указанные значения при каждом запуске.
 * [NOTE] Если 'history' - true, загрузки также будут очищены
 * [CHECK]-all, кроме паролей и загрузок ***/
   // user_pref("privacy.cpd.cache", true);
   // user_pref("privacy.cpd.cookies", true);
   // user_pref("privacy.cpd.downloads", true); // not used, see note above
   // user_pref("privacy.cpd.formdata", true); // Form & Search History
   // user_pref("privacy.cpd.history", true); // Browsing & Download History
   // user_pref("privacy.cpd.offlineApps", true); // Offline Website Data
   // user_pref("privacy.cpd.passwords", false); // this is not listed
   // user_pref("privacy.cpd.sessions", true); // Active Logins
   // user_pref("privacy.cpd.siteSettings", false); // Site Preferences
/* 2805: очистить данные восстановления сеанса при любой очистке [FF34+]
 * [NOTE] Не требуется, если восстановление сеанса не используется (0102) или уже очищено с историей (2803)
 * [NOTE] privacy.clearOnShutdown.openWindows предотвращает возобновление после сбоя (см. 1022)
 * [NOTE] privacy.cpd.openWindows имеет ошибку, из-за которой открывается дополнительное окно ***/
   // user_pref("privacy.clearOnShutdown.openWindows", true);
   // user_pref("privacy.cpd.openWindows", true);
/* 2806: сброс по умолчанию "диапазона времени для очистки" в "очистить недавнюю историю" (see 2804)
 * Firefox помнит последний выбор, это будет возвращать указанное значение при каждом запуске.
 * 0=everything, 1=last hour, 2=last two hours, 3=last four hours,
 * 4=today, 5=last five minutes, 6=last twenty-four hours
 * [NOTE] Значения 5 + 6 не перечислены в выпадающем списке ***/
user_pref("privacy.sanitize.timeSpan", 0);

/*** [SECTION 4000]: FPI (FIRST PARTY ISOLATION)
   1278037 - indexedDB (FF51+)
   1277803 - favicons (FF52+)
   1264562 - OCSP cache (FF52+)
   1268726 - Shared Workers (FF52+)
   1316283 - SSL session cache (FF52+)
   1317927 - media cache (FF53+)
   1323644 - HSTS and HPKP (FF54+)
   1334690 - HTTP Alternative Services (FF54+)
   1334693 - SPDY/HTTP2 (FF55+)
   1337893 - DNS cache (FF55+)
   1344170 - blob: URI (FF55+)
   1300671 - data:, about: URLs (FF55+)
   1473247 - IP addresses (FF63+)
   1492607 - postMessage with targetOrigin "*" (requires 4002) (FF65+)
   1542309 - top-level domain URLs when host is in the public suffix list (FF68+)
   1506693 - pdfjs range-based requests (FF68+)
   1330467 - site permissions (FF69+)
   1534339 - IPv6 (FF73+)
   1721858 - WebSocket (FF92+)
***/
user_pref("_user.js.parrot", "4000 syntax error: the parrot's pegged out");
/* 4001: enable First Party Isolation [FF51+]
 * [SETUP-WEB] Может нарушить междоменные логины и функции небольшого числа сайтов.
 * [ПРИМ] Важный преф, ограничивающий отслеживание истории открытых сайтов ***/
user_pref("privacy.firstparty.isolate", true);
/* 4002: принудительное ограничение FPI для window.opener [FF54 +]
 * [NOTE] Установка этого значения в false может уменьшить вероятность поломки в 4001
 * FF65 + блокирует postMessage с targetOrigin "*", если originAttributes не совпадают.
 * Чтобы уменьшить вероятность поломки, игнорирует originAttribute первичного домена (FPD).
 * Второй преф разрешает связь, только если (FPD) также совпадает (еще больше ломает). ***/
   // user_pref("privacy.firstparty.isolate.restrict_opener_access", false); // [DEFAULT: true]
   // user_pref("privacy.firstparty.isolate.block_post_message", true); // [DEFAULT: false]
/* 4003: enable scheme with FPI [FF78+]
 * [NOTE] Experimental: existing data and site permissions are incompatible
 * and some site exceptions may not work e.g. HTTPS-only mode (see 1244) ***/
   // user_pref("privacy.firstparty.isolate.use_site", true);

/*** [SECTION 4500]: RFP (RESIST FINGERPRINTING)
   RFP охватывает широкий спектр текущих решений по снятию отпечатков.
   Это покупка по принципу "все или ничего": вы не можете выбирать, какие части вам нужны

   [WARNING] НЕ используйте расширения для изменения уже защищенных метрик RFP
   [WARNING] НЕ используйте префы в разделе 4600 совместно с RFP, так как они могут мешать

   [ПРИМ] Активация "этого нечто" сделает браузер практически непригодным для использования.
   Все это в той или иной степени и без такого ущерба для юзабельности, решается с помощью
   специальных расширений типа CanvasBlocker или Canvas Defender.

   Так что основной преф RPF отключен в этой версии документа, а остальные оставлены
   совсем не с целью защиты от снятия отпечатков.
***/
user_pref("_user.js.parrot", "4500 syntax error: the parrot's popped 'is clogs");
/* 4501: enable privacy.resistFingerprinting [FF41+]
 * [SETUP-WEB] RFP can cause the odd website to break in strange ways, and has a few side affects,
 * but is largely robust nowadays. Give it a try. Your choice. Also see 4504 (letterboxing).
 * [1] https://bugzilla.mozilla.org/418986 ***/
user_pref("privacy.resistFingerprinting", false);
/* 4503: disable mozAddonManager Web API [FF57+]
 * [NOTE] На FF60+ cовместно с (2662) заставит работать расширения на AMO и т.п.
 * привилегированных страницах (например, переводчики). В итоге функционал удаления,
 * поломается и кнопка установки на AMO всегда бедет в состоянии "Установить...". ***/
user_pref("privacy.resistFingerprinting.block_mozAddonManager", true); // [HIDDEN PREF]
/* 4510: disable showing about:blank as soon as possible during startup [FF60+]
 * Когда значение true (FF62+), не маскирует изменение размера RFP chrome.
 * Если false, то отключает стробоскоп (вспышку белого) при старте браузера или загрузке страницы ***/
user_pref("browser.startup.blankWindow", false);
/* 4520: disable chrome animations [FF77+] [RESTART]
 * [ПРИМ] Отключает плавную отрисовку страницы (старое поведение)
 * Также влияет на поведение мегабара (старое поведение).
 * Так что можно использовать это или изменить мегабар стилем ***/
   // user_pref("ui.prefersReducedMotion", 1); // [HIDDEN PREF]

/*** [SECTION 4600]: RFP ALTERNATIVES
   * Глючная как и сам RFP. При выполнении рекомендаций многое ломается
   * Оставил только некритичное или то что может быть полезным. ***/
user_pref("_user.js.parrot", "4600 syntax error: the parrot's crossed the Jordan");
/* 4605: [2515] disable site specific zoom
 * Масштабирование влияют на разрешение экрана и хорошо детектируется.
 * Это не мешает масштабированию, просто оно не будет запоминаться для сайтов.
 * Масштаб в новых вкладках и окнах сбросится на по умолчанию. ***/
   // user_pref("browser.zoom.siteSpecific", false);
// 4607: [2503] disable giving away network info [FF31+]
user_pref("dom.netinfo.enabled", false); // [DEFAULT: true on Android]
// 4608: [2021] disable the SpeechSynthesis (Text-to-Speech) part of the Web Speech API
user_pref("media.webspeech.synth.enabled", false);
// 4610: [2506] disable video statistics - JS performance fingerprinting [FF25+]
user_pref("media.video_stats.enabled", false);
// 4612: [2505] disable media device enumeration [FF29+]
user_pref("media.navigator.enabled", false);
// 4614: [2522] disable WebGL debug info being available to websites
user_pref("webgl.enable-debug-renderer-info", false);
// FF80+
/* 4618: ограничить видимость шрифтов (non-ANDROID) [FF79+]
 * Uses hardcoded lists with two parts: kBaseFonts + kLangPackFonts [1]
 * 1=only base system fonts, 2=also fonts from optional language packs, 3=also user-installed fonts
 * [NOTE] Bundled fonts are auto-allowed
 * [1] https://searchfox.org/mozilla-central/search?path=StandardFonts*.inc
 * [CHECK]***/
   // user_pref("layout.css.font-visibility.level", 1);
// ***/

/*** [SECTION 4700]: RFP ALTERNATIVES (USER AGENT SPOOFING)
     Это только к сведению. Эти префы недостаточны сами по себе, вам нужно использовать
     RFP (4500) или расширение, а в таком случае эти префы становятся бессмысленными.
     Но если очень хочется то кое что здесь можно переопределить.
***/
user_pref("_user.js.parrot", "4700 syntax error: the parrot's taken 'is last bow");
/* 4701: navigator DOM object overrides
 * [WARNING] DO NOT USE, если не уверены ***/
   // user_pref("general.appname.override", ""); // [HIDDEN PREF]
   // user_pref("general.appversion.override", ""); // [HIDDEN PREF]
   // user_pref("general.buildID.override", ""); // [HIDDEN PREF]
   // user_pref("general.oscpu.override", ""); // [HIDDEN PREF]
   // user_pref("general.platform.override", ""); // [HIDDEN PREF]
   // user_pref("general.useragent.override", ""); // [HIDDEN PREF]

/*** [SECTION 5000]: PERSONAL
     Не связанные с проектом настройки, которые могут оказаться полезными. ***/
user_pref("_user.js.parrot", "5000 syntax error: this is an ex-parrot!");
/* WELCOME & WHAT's NEW NOTICES ***/
user_pref("browser.startup.homepage_override.mstone", "ignore"); // master switch
user_pref("startup.homepage_welcome_url", "");
user_pref("startup.homepage_welcome_url.additional", "");
user_pref("startup.homepage_override_url", ""); // What's New page after updates
/* WARNINGS ***/
user_pref("browser.tabs.warnOnClose", false);
user_pref("browser.tabs.warnOnCloseOtherTabs", false);
user_pref("browser.tabs.warnOnOpen", false);
user_pref("full-screen-api.warning.delay", 0);
user_pref("full-screen-api.warning.timeout", 0);
/* APPEARANCE ***/
   // user_pref("browser.download.autohideButton", false); // [FF57+]
   // есть ниже
/* CONTENT BEHAVIOR ***/
   // user_pref("accessibility.typeaheadfind", true); // enable "Find As You Type"
   // user_pref("clipboard.autocopy", false); // disable autocopy default [LINUX]
   // user_pref("layout.spellcheckDefault", 2); // 0=none, 1-multi-line, 2=multi-line & single-line
/* UX BEHAVIOR ***/
   // user_pref("browser.backspace_action", 2); // 0=previous page, 1=scroll up, 2=do nothing
   // 4 пункта есть ниже
   // user_pref("general.autoScroll", false); // middle-click enabling auto-scrolling [DEFAULT: false on Linux]
   // user_pref("ui.key.menuAccessKey", 0); // disable alt key toggling the menu bar [RESTART]
   // user_pref("view_source.tab", false); // открыать "Исходный код страницы" в новой вкладке [FF68+]
/* UX FEATURES: отключить и скрыть значки и меню ***/
user_pref("browser.messaging-system.whatsNewPanel.enabled", false); // What's New toolbar icon [FF69+]
user_pref("extensions.pocket.enabled", false); // Pocket Account [FF46+]
user_pref("identity.fxaccounts.enabled", false); // Firefox Accounts & Sync [FF60+] [RESTART]
   // user_pref("reader.parse-on-load.enabled", false); // Reader View
/* OTHER ***/
user_pref("browser.bookmarks.max_backups", 2);
user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.addons", false); // disable CFR [FF67+]
// [SETTING] General>Browsing>Recommend extensions as you browse
user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.features", false); // disable CFR [FF67+]
// [SETTING] General>Browsing>Recommend features as you browse
   // user_pref("network.manage-offline-status", false); // see bugzilla 620472 // почти не работает
// игнорируется в обычных версиях (только для ESR, dev и nightly), пофикшено в config.js
   // user_pref("xpinstall.signatures.required", false); // enforced extension signing (Nightly/ESR)

/*************************  ДРУГОЕ ********************************************/
user_pref("_user.js.parrot", "Секция ДРУГОЕ syntax error");

// Параметры до сих пор существуют, отключаем на всякий
user_pref("app.update.BITS.enabled", false);
user_pref("app.update.checkInstallTime", false);
user_pref("app.update.service.enabled", false);
user_pref("app.update.staging.enabled", false);

// Не проверять является ли Firefox браузером по умолчанию при первом запуске
user_pref("browser.shell.didSkipDefaultBrowserCheckOnFirstRun", true);

// Статус загрузки страницы - риск утечки данных при использовании proxi\VPN
user_pref("dom.enable_performance", false);

/* Полная изоляция сайтов и фреймов - экспериментальный и прожорливый режим,
 * блокируем от случайного включения - https://www.comss.ru/page.php?id=7992 ***/
user_pref("fission.autostart", false);
user_pref("gfx.webrender.all", false);

/*** Внешний вид и поведение ***/

// [FF68+] разрешить стили userChrome/userContent (APPEARANCE)
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

/* Использовать или нет атрибуты SVG (false ломает цвет заданный в самих svg),
 * в том числе прозрачность ***/
user_pref("svg.context-properties.content.enabled", true);

// Вернуть пункт конт.меню "Информация об изображении"
user_pref("browser.menu.showViewImageInfo", true);

/* Влияет на перетягивание из браузера в проводник и окна других программ
 * запущенных не от администратора ***/
   // user_pref("browser.launcherProcess.enabled", true); // [HIDDEN PREF]

// Запретить отсоединять нативные вкладки от окна
   // user_pref("browser.tabs.allowTabDetach", false);

// Чинит цвет элементов веб-страниц, при нестандартных темах оформления Windows
   // user_pref("browser.display.document_color_use", 1);

/* Не закрывать меню в панели закладок при открытии закладки по Ctrl+ЛКМ,
 * дает возможность открыть несколько закладок подряд ***/
user_pref("browser.bookmarks.openInTabClosesMenu", false);
// закрывать ли браузер при закрытии последней вкладки (UX BEHAVIOR)
user_pref("browser.tabs.closeWindowWithLastTab", false);
// открывать ли из строки адреса в новой вкладке
user_pref("browser.urlbar.openintab", true);
// открывать ли поиск в новой вкладке 
user_pref("browser.search.openintab", true);
// открывать ли закладки в новой вкладке (UX BEHAVIOR)
user_pref("browser.tabs.loadBookmarksInTabs", true);
// открывать ли закладки в фоне
   // user_pref("browser.tabs.loadBookmarksInBackground", true);

// Выделение нажатой ссылки другим контуром
   // user_pref("browser.display.focus_ring_on_anything", true);

/*** PROTON start ***/
/* Показать пункт в персонализации "Компактные", значки он теперь  не уменьшает,
 * но панели, вкладки и меню делает меньше по высоте ***/
   // user_pref("browser.compactmode.show", true);
// Главный переключатель Proton
   // user_pref("browser.proton.enabled", true);
// остальное
   // user_pref("browser.proton.places-tooltip.enabled", false);
   // user_pref("browser.proton.toolbar.version", 0);
/*** PROTON end ***/

// Зеленый замок в адресной строке для HTTPS без смешанного контента на странице
user_pref("security.secure_connection_icon_color_gray", false);
// Калькулятор в адресной строке, например "7+8" в дроп меню получаем ответ
user_pref("browser.urlbar.suggest.calculator", true);
// Декодирование URL при копированиии из строки адреса (UX BEHAVIOR)
user_pref("browser.urlbar.decodeURLsOnCopy", true);

// Показывать список загрузок при старте загрузки (показывать = false)
   // user_pref("browser.download.panel.shown", false);

// В about:addons открывать "расширения", вместо последней открытой категории
// Лучше использовать в config.js - lockPref(...
   // user_pref("extensions.ui.lastCategory", "addons://list/extension");

// Не показывать в полях ввода пароля блок "Просмотр сохранённых ...."
user_pref("signon.showAutoCompleteFooter", false);

/* Масштабировать только текст страниц =false, иначе все вместе с картинками,
 * эту функция теперь доступна в настройках ***/
   // user_pref("browser.zoom.full", true);

// Домашняя страница
// Не показывать логотип поисковика
   // user_pref("browser.newtabpage.activity-stream.logowordmark.alwaysVisible", false);
/* При вводе в строке поска не переключать фокус на адресную строку и
 * не дублировать поисковые предложения в ней ***/
user_pref("browser.newtabpage.activity-stream.improvesearch.handoffToAwesomebar", false);
// старый дизайн страницы "новой вкладки"
   // user_pref("browser.newtabpage.activity-stream.newNewtabExperience.enabled", false);

// Показывать ли папку "Другие закладки" на панели закладок ( 1-й для 84-, оба для 84.2+, скорее всего временно )
   // user_pref("browser.toolbars.bookmarks.showOtherBookmarks", false);
   // user_pref("browser.toolbars.bookmarks.2h2020", false);

// Темная тема на страницах about:xxxxxx
   // user_pref("browser.in-content.dark-mode", true); // Старое, но пока еще нужен для стилей от Aris-t2
   // user_pref("ui.systemUsesDarkTheme", 1); // [HIDDEN PREF]

// Инструменты разработчика
 // Включение инструментов браузера и удаленной отладки (если не понимаете, то скорее всего вам это не надо)
 // [CHECK]-all
   // user_pref("devtools.chrome.enabled", true);
   // user_pref("devtools.debugger.remote-enabled", true);
user_pref("devtools.debugger.prompt-connection", false); // дурацкое сообщение
   // user_pref("devtools.browsertoolbox.fission", true); // многопроцессная отладка
   // user_pref("devtools.toolbox.selectedTool", "inspector"); // вкладка по умолчанию
 // Темная тема
   // user_pref("devtools.theme", "dark");

/*** Вкладки ***/

/* При восстановлении сеанса - загружать контент восстановленных вкладок,
 * по умолчанию - не загржать и обновлять вкладки только при их выборе */
   // user_pref("browser.sessionstore.restore_on_demand", false); // [DEFAULT: true]
// Обновлять закрепленные вкладки только при их выборе
user_pref("browser.sessionstore.restore_pinned_tabs_on_demand", true);

/* Фокус при закрытии вкладки
 * true  - Если открытая вкладка закрывается, переместить фокус
 * обратно на вкладку, которая ее открыла. (по умолчанию)
 * false - Если открытая вкладка закрывается, переместить фокус
 * на соседнюю правую вкладку, если она существует;
 * в противном случае на соседнюю левую вкладку. ***/
   // user_pref("browser.tabs.selectOwnerOnClose", false);

// Открывать вкладки после текущей
   // user_pref("browser.tabs.insertAfterCurrent", true);
// Открывать связанные вкладки после текущей
user_pref("browser.tabs.insertRelatedAfterCurrent", true);

/*** Miltimedia ***/

// Вся эта секция требует перезапуска браузера
/* Значение TRUE в этом параметре приводит к блеклому отображению цветов в видео
 * Значение FALSE делает недоступными видео выше 1080p на YouTube
 * Может предотвратить подвисание видео при воспроизведении, на некоторых ПК ***/
   // user_pref("media.webm.enabled", false);
/* Для обратного эффекта, если вдруг стало не доступно видео выше 1080p на YouTube
 * можно проверить/переключить эти параметры ***/
   // user_pref("media.mediasource.webm.enabled", true); // По умолчанию в 91b
   // user_pref("media.wmf.dxva.d3d11.enabled", true); // По умолчанию в 91b
   // user_pref("gfx.crash-guard.status.wmfvpxvideo", 2); // Cкрытый (удалить, если не равен 2)
// Так же можно попробовать удалить все строки с gfx.crash-guard.*

// Автозапуск мультимедиа, см. 2030, 2031
/* Дополнительно, если 2031 =1
 * время задержки блокировки автозапуска следующего за текущим ролика ***/
user_pref("dom.user_activation.transient.timeout", 1000);
// Функции автозапуска media помимо 2030 и 2031, можете побаловаться
   // user_pref("dom.media.autoplay.autoplay-policy-api", true);
   // user_pref("media.autoplay.allow-extension-background-pages", false);
   // user_pref("media.autoplay.block-event.enabled", true);
   // user_pref("media.autoplay.block-webaudio", true);

// Скрыть переключатель на видео "картинка в картинке"
   // user_pref("media.videocontrols.picture-in-picture.video-toggle.enabled", false);
// или свернуть его в иконку
user_pref("media.videocontrols.picture-in-picture.video-toggle.has-used", false);

// EME-free - косметика не для EMEfree, но с отключенным кодеком
user_pref("app.partner.mozilla-EMEfree", "mozilla-EMEfree");

// OpenH264 - переключить если НЕ пользуетесь кодеком OpenH264
user_pref("media.gmp-gmpopenh264.enabled", false);
/* Если переключить, то кодек вообще удалится из профиля и about:addons
 * При обратном включении зайдите в about:addons в плагины и обновите его
 * Firefox загрузит его за десяток секунд, размер кодека чуть меньше 1Мб ***/
user_pref("media.gmp-gmpopenh264.visible", false);

// Media cache - для предотврашения смены кривыми расширениями
user_pref("media.cache_size", 512000); // [DEFAULT: 512000]

/*** Память ***/

/* Как часто проверять страницу на изменения. Значения:
 * 0 - один раз за сессию
 * 1 - каждый раз при просмотре страницы
 * 2 - не проверять, использовать кэш браузера
 * 3 - проверять, когда страница устарела (автоматически). ***/
   // user_pref("browser.cache.check_doc_frequency", 3); // [DEFAULT: 3]

/* История вкладок, сохраняется при сохранении сессий.
 * Для приватности, при использовании функции сохранения сессий, можно
 * отключить второй параметр, а для очистки первого использовать автоочистку (2802)
 * или вручную очищать данные перед закрытием браузера. Иначе при восстановлении
 * сессии, тому кто ее восстановит, будет доступна вся ваша история вкладок.
 * Т.е. например, вкладка поваренок.ру, а в ее истории (стрелки вперед-назад)
 * порнохаб и страницы гугла со странными поисковыми запросами. )
 * Это ни как не отразится на истории посещений. ***/

// 1020: История закрытых вкладок для "восстановить закрытую вкладку"
user_pref("browser.sessionstore.max_tabs_undo", 25);
/* История вкладок "вперед<->назад". Минимум 1, практический минимум = 2,
 * так как некоторые страницы используют эту функцию для перенаправления. ***/
user_pref("browser.sessionhistory.max_entries", 10);
/* Максимум страниц с историей "вперед<->назад" для хранения в памяти,
 * -1 = авто (по умолчанию), 0 = отключить, максимум 8.
 * Считается, что эта функция может тормозить браузер. Отключение просто
 * не держит страницы в памяти, а загружает из сети при повторном вызове. ***/
user_pref("browser.sessionhistory.max_total_viewers", 2);

/* Разрешить Windows сбрасывать память на диск, когда Firefox свернут.
 * Зависит от Windows. Разворачивание при этом будет тормозить. ***/
   // user_pref("config.trim_on_minimize", true); // [Создать] Логическое

/*** Сеть - DoH
 * Также см. (1212) и читайте прилагаемый текстовый документ "DoH.txt" ***/

/* Основной переключатель DoH
     1 - чтобы Firefox выбирал самый быстрый вариант (между DoH и стандартным DNS-сервером);
     2 - чтобы технология DoH был выбрана по умолчанию, а ваш стандартный DNS-сервер как резервный;
     3 – чтобы использовать только TRR;
     4 – теневой режим: TRR синхронизируется со стандартным DNS, но результаты берутся только от стандартного;
         ХЗ что это означает, возможно для тестов используется.
     5 – чтобы отключить TRR по выбору;
     0 – чтобы отключить TRR по умолчанию. "Вроде как выпилен в последних релизах";
     По моим тестам, если выбрать 1 или 2, то почти всегда будет работать стандартный DNS-сервер.
     Но у вас может быть иначе. ***/
   // user_pref("network.trr.mode", 3);
/* Учитывать или нет исключения системного HOSTS-файла при соединениях по DoH
 * false - игнорировать, true  - учитывать
 * [CHECK] - для переносного варианта, но не забываем про
 * 0.0.0.0 content-signature-2.cdn.mozilla.net, если есть.
 * Это адрес паразитичиского соединения Firefox, которое никак иначе не отключить. ***/
   // user_pref("network.trr.exclude-etc-hosts", false);

/*** Оптимизация ***/

/* Для каждой вкладки свой процесс
 * При использовании Auto Tab Discard может уменьшить потребление памяти
 * https://addons.mozilla.org/ru/firefox/addon/auto-tab-discard ***/
   // user_pref("dom.ipc.processCount", -1);

/* Новый движок рендеринга, при проблемах с прорисовкой сайтов можно попробовать
 * раскомментировать 2-ой преф, первый преф и так отключен ***/
   // user_pref("gfx.webrender.enabled", false); // [DEFAULT: false]
   // user_pref("gfx.webrender.force-disabled", true); // [DEFAULT: false]

/* END: internal custom pref to test for syntax errors ***/
user_pref("_user.js.parrot", "УСПЕХ: user.js полностью загружен.");
