/******
* Нумерация, если есть, соответствует arkenfox user.js
* date: 30 July 2021
* version 91-alpha
* url: https://github.com/arkenfox/user.js

* При удалении параметра не забудьте сбросить его в about:config
******/

// START: internal custom pref to test for syntax errors
user_pref("_user.js.parrot", "ФИАСКО! user.js загружен не полностью, из-за синтаксической ошибки в нем.");

// 0000: отключить предупреждение при входе в about:config
user_pref("general.warnOnAboutConfig", false); // XHTML version
user_pref("browser.aboutConfig.showWarning", false); // HTML version [FF71+]

/*** [SECTION 0100]: STARTUP ***/
/* 0101: disable default browser check
 * [SETTING] General>Startup>Always check if Firefox is your default browser ***/
user_pref("browser.shell.checkDefaultBrowser", false);
/* 0104: set NEWTAB page
 * true=Activity Stream (default, see 0105), false=blank page
 * [SETTING] Home>New Windows and Tabs>New tabs ***/
   // user_pref("browser.newtabpage.enabled", false);
user_pref("browser.newtab.preload", false);
// 0105a: disable Activity Stream telemetry
user_pref("browser.newtabpage.activity-stream.feeds.telemetry", false);
user_pref("browser.newtabpage.activity-stream.telemetry", false);
/* 0105b: disable Activity Stream Snippets
 * Запускает код с сервера и отправляет информацию обратно на телеметрический сервер
 * [1] https://abouthome-snippets-service.readthedocs.io/ ***/
user_pref("browser.newtabpage.activity-stream.feeds.snippets", false); // [DEFAULT: false FF89+]
// 0105c: disable Activity Stream Top Stories, Pocket-based and/or sponsored content
user_pref("browser.newtabpage.activity-stream.feeds.section.topstories", false);
user_pref("browser.newtabpage.activity-stream.section.highlights.includePocket", false);
user_pref("browser.newtabpage.activity-stream.showSponsored", false);
user_pref("browser.newtabpage.activity-stream.feeds.discoverystreamfeed", false); // [FF66+]
user_pref("browser.newtabpage.activity-stream.showSponsoredTopSites", false); // [FF83+]
/* 0105e: clear default topsites
 * [NOTE] Это не мешает вам добавлять свои собственные ***/
user_pref("browser.newtabpage.activity-stream.default.sites", "");

/*** [SECTION 0300]: QUIET FOX
***/
/* 0301: disable auto-INSTALLING Firefox updates [NON-WINDOWS FF65+]
 * [NOTE] In FF65+ on Windows this SETTING (below) is now stored in a file and the pref was removed
 * [SETTING] General>Firefox Updates>Check for updates but let you choose to install them ***/
user_pref("app.update.auto", false);
/* 0302: disable auto-INSTALLING Firefox updates via a background service [FF90+] [WINDOWS]
 * [SETTING] General>Firefox Updates>Automatically install updates>When Firefox is not running
 * [1] https://support.mozilla.org/kb/enable-background-updates-firefox-windows ***/
user_pref("app.update.background.scheduling.enabled", false);
/* 0303: disable auto-CHECKING for extension and theme updates ***/
   // user_pref("extensions.update.enabled", false);
/* 0304: disable auto-INSTALLING extension and theme updates (after the check in 0303)
 * [SETTING] about:addons>Extensions>[cog-wheel-icon]>Update Add-ons Automatically (toggle) ***/
user_pref("extensions.update.autoUpdateDefault", false);
/* 0308: disable search engine updates (e.g. OpenSearch)
 * [NOTE] Это не влияет на встроенные поисковые системы Mozilla или веб-расширения ***/
user_pref("browser.search.update", false);
// 0320: disable about:addons' Recommendations pane (uses Google Analytics)
user_pref("extensions.getAddons.showPane", false); // [HIDDEN PREF]
// 0321: disable recommendations in about:addons' Extensions and Themes panes [FF68+]
user_pref("extensions.htmlaboutaddons.recommendations.enabled", false);
/* 0330: disable telemetry
 * преф (.unified) влияет на поведение префа (.enabled)
 * IF unified=false then .enabled controls the telemetry module
 * IF unified=true then .enabled ONLY controls whether to record extended data
 * so make sure to have both set as false
 * [NOTE] FF58+ 'toolkit.telemetry.enabled' теперь ЗАБЛОКИРОВАН в prerelease
 * и release сборках (true и false соответственно) ***/
user_pref("toolkit.telemetry.unified", false);
user_pref("toolkit.telemetry.enabled", false); // see [NOTE]
user_pref("toolkit.telemetry.server", "data:,");
user_pref("toolkit.telemetry.archive.enabled", false);
user_pref("toolkit.telemetry.newProfilePing.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.shutdownPingSender.enabled", false); // [FF55+]
user_pref("toolkit.telemetry.updatePing.enabled", false); // [FF56+]
user_pref("toolkit.telemetry.bhrPing.enabled", false); // [FF57+] Background Hang Reporter
user_pref("toolkit.telemetry.firstShutdownPing.enabled", false); // [FF57+]
// 0331: disable Telemetry Coverage
user_pref("toolkit.telemetry.coverage.opt-out", true); // [HIDDEN PREF]
user_pref("toolkit.coverage.opt-out", true); // [FF64+] [HIDDEN PREF]
user_pref("toolkit.coverage.endpoint.base", "");
/* 0340: disable Health Reports
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send technical... data ***/
user_pref("datareporting.healthreport.uploadEnabled", false);
// 0341: disable new data submission, master kill switch [FF41+]
user_pref("datareporting.policy.dataSubmissionEnabled", false);
/* 0342: disable Studies (see 0503)
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to install and run studies ***/
user_pref("app.shield.optoutstudies.enabled", false);
/* 0343: disable personalized Extension Recommendations in about:addons and AMO [FF65+]
 * [NOTE] Этот преф не действует, если 0340 отключен
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to make personalized extension recommendations ***/
user_pref("browser.discovery.enabled", false);
// 0350: disable Crash Reports
user_pref("breakpad.reportURL", "");
user_pref("browser.tabs.crashReporting.sendReport", false); // [FF44+]
user_pref("browser.crashReports.unsubmittedCheck.enabled", false); // [FF51+] [DEFAULT: false]
/* 0351: enforce no submission of backlogged Crash Reports [FF58+]
 * [SETTING] Privacy & Security>Firefox Data Collection & Use>Allow Firefox to send backlogged crash reports  ***/
user_pref("browser.crashReports.unsubmittedCheck.autoSubmit2", false); // [DEFAULT: false]
// 0390: disable Captive Portal detection
user_pref("captivedetect.canonicalURL", "");
user_pref("network.captive-portal-service.enabled", false); // [FF52+]
// 0391: disable Network Connectivity checks [FF65+]
user_pref("network.connectivity-service.enabled", false);

/*** [SECTION 0400]: BLOCKLISTS / SAFE BROWSING (SB) ***/
/** BLOCKLISTS ***/
/* 0401: enforce Firefox blocklist
 * [NOTE] Включает обновления для "отозванных сертификатов"
 * [1] https://blog.mozilla.org/security/2015/03/03/revoking-intermediate-certificates-introducing-onecrl/ ***/
user_pref("extensions.blocklist.enabled", true); // [DEFAULT: true]

/** SAFE BROWSING (SB)
***/
/* 0410: disable SB (Safe Browsing)
 * Это главные переключатели.
 * [SETTING] Privacy & Security>Security>... "Block dangerous and deceptive content" ***/
user_pref("browser.safebrowsing.malware.enabled", false);
user_pref("browser.safebrowsing.phishing.enabled", false);
/* 0411: disable SB checks for downloads (both local lookups + remote)
 * Это главный переключатель для параметров safebrowsing.downloads* (0412, 0413)
 * [SETTING] Privacy & Security>Security>... "Block dangerous downloads" ***/
user_pref("browser.safebrowsing.downloads.enabled", false);
/* 0412: disable SB checks for downloads (remote)
 * Чтобы проверить безопасность некоторых исполняемых файлов, Firefox отправляет
 * некоторую информацию о файле и его происхождении в службу Google Safe Browsing.
 * Служба Safe Browsing, которая помогает Firefox определить, следует ли блокировать файл.
 * [SETUP-SECURITY] Если вам нужна эта защита, то переопределите эти параметры ***/
user_pref("browser.safebrowsing.downloads.remote.enabled", false);
user_pref("browser.safebrowsing.downloads.remote.url", "");
/* 0413: disable SB checks for unwanted software
 * [SETTING] Privacy & Security>Security>... "Warn you about unwanted and uncommon software" ***/
user_pref("browser.safebrowsing.downloads.remote.block_potentially_unwanted", false);
user_pref("browser.safebrowsing.downloads.remote.block_uncommon", false);

/*** [SECTION 0500]: SYSTEM ADD-ONS / EXPERIMENTS
     Префы отключения пунктов меню Pocket и аккаунта Firefox доступны в UX FEATURES (см. 5000) ***/
/* 0503: disable Normandy/Shield [FF60+]
 * телеметрия и стороннее тестирование ***/
user_pref("app.normandy.enabled", false);
user_pref("app.normandy.api_url", "");
// 0505: disable System Add-on updates
user_pref("extensions.systemAddon.update.enabled", false); // [FF62+]
user_pref("extensions.systemAddon.update.url", ""); // [FF44+]
/* 0506: disable PingCentre telemetry (used in several System Add-ons) [FF57+]
 * В настоящее время блокируется'datareporting.healthreport.uploadEnabled' (see 0340) ***/
user_pref("browser.ping-centre.telemetry", false);
// 0518: enforce disabling of Web Compatibility Reporter [FF56+]
user_pref("extensions.webcompat-reporter.enabled", false); // [DEFAULT: false]

/*** [SECTION 0600]: BLOCK IMPLICIT OUTBOUND [not explicitly asked for - e.g. clicked on] ***/
// 0601: disable link prefetching
user_pref("network.prefetch-next", false);
// 0602: disable DNS prefetching
user_pref("network.dns.disablePrefetch", true);
user_pref("network.dns.disablePrefetchFromHTTPS", true); // [DEFAULT: true]
// 0603: disable predictor / prefetching
user_pref("network.predictor.enabled", false);
user_pref("network.predictor.enable-prefetch", false); // [FF48+] [DEFAULT: false]
// 0605: disable link-mouseover opening connection to linked server
user_pref("network.http.speculative-parallel-limit", 0);
// 0606: enforce no "Hyperlink Auditing" (click tracking)
user_pref("browser.send_pings", false); // [DEFAULT: false]
user_pref("browser.send_pings.require_same_host", true);

/*** [SECTION 0700]: HTTP* / TCP/IP / DNS / PROXY / SOCKS etc ***/
// 0704: при использовании SOCKS проксировать DNS-запросы
user_pref("network.proxy.socks_remote_dns", true);

/*** [SECTION 1200]: HTTPS (SSL/TLS / OCSP / CERTS / HPKP / CIPHERS)
***/
// 1205: disable SSL Error Reporting [ПРИМ] есть в политиках
user_pref("security.ssl.errorReporting.enabled", false);

/*** [SECTION 1800]: PLUGINS ***/
/* 1820: disable GMP (Gecko Media Plugins)
 * Больше см. в секции OpenH264 в конце файла ***/
user_pref("media.gmp-provider.enabled", false);
/* 1825: disable widevine CDM (Content Decryption Module)
 * [NOTE] This is covered by the EME master switch (1830) ***/
user_pref("media.gmp-widevinecdm.visible", false);
user_pref("media.gmp-widevinecdm.enabled", false);
/* 1830: disable all DRM content (EME: Encryption Media Extension)
 * EME-free - переключить если пользуетесь кодеком
 * [SETUP-WEB] e.g. Netflix, Amazon Prime, Hulu, HBO, Disney+, Showtime, Starz, DirectTV
 * [SETTING] General>DRM Content>Play DRM-controlled content
 * [TEST] https://bitmovin.com/demos/drm
 ***/
user_pref("media.eme.enabled", false);

/*** [SECTION 2000]: MEDIA / CAMERA / MIC ***/
/* 2001: disable WebRTC (Web Real-Time Communication)
 * [SETUP-WEB] WebRTC сливает налево ваш реальный IP-адрес под VPN и прокси.
 * false - cломает возможность общения в режиме реального времени ***/
user_pref("media.peerconnection.enabled", false);
/* 2002: limit WebRTC IP leaks if using WebRTC
 * In FF70+ these settings match Mode 4 (Mode 3 in older versions)
 * [TEST] https://browserleaks.com/webrtc ***/
user_pref("media.peerconnection.ice.default_address_only", true);
user_pref("media.peerconnection.ice.no_host", true); // [FF51+]
user_pref("media.peerconnection.ice.proxy_only_if_behind_proxy", true); // [FF70+]

/*** [SECTION 2300]: WEB WORKERS ***/
/* 2302: disable service workers [FF32, FF44-compat]
 * Service workers по сути действуют как прокси между веб-приложениями, браузером и сетью,
 * управляются и сами управляют веб-страницами с которыми связаны, перехватывая и изменяя
 * запросы, и кэшируя ресурсы.
 * [NOTE] API Service worker скрыты (в Firefox) и не могут быть использованы в режиме PB.
 * [NOTE] Service workers работают только по HTTPS и не имеют доступа к DOM.
 * [SETUP-WEB] Отключение service workers приведет к поломке некоторых редких сайтов.
 * Этот преф требует true для service worker уведомлений (2304), push-уведомлений (2305)
 * и service worker кэша (2740). Если вы переключаете этот преф, то проверьте и эти настройки ***/
user_pref("dom.serviceWorkers.enabled", false);

/*** [SECTION 2600]: MISCELLANEOUS ***/
// 2602: disable sending additional analytics to web servers
user_pref("beacon.enabled", false);
// 2603: remove temp files opened with an external application
user_pref("browser.helperApps.deleteTempFileOnExit", true);
// 2604: отключить создание thumbnail в папке профиля ***/
user_pref("browser.pagethumbnails.capturing_disabled", true); // [HIDDEN PREF]
// 2606: disable UITour backend so there is no chance that a remote page can use it
user_pref("browser.uitour.enabled", false);
user_pref("browser.uitour.url", "");
// 2616: удалить специальные разрешения для определенных доменов Mozilla [FF35+]
user_pref("permissions.manager.defaultsUrl", "");
// 2617: удалить белый список веб-каналов
user_pref("webchannel.allowObject.urlWhitelist", "");


/** SECURITY ***/
/* 2680: enforce CSP (Content Security Policy)
 * [NOTE] CSP является очень важной и широко распространенной функцией безопасности. Не отключайте его!
 * [1] https://developer.mozilla.org/docs/Web/HTTP/CSP ***/
user_pref("security.csp.enable", true); // [DEFAULT: true]
// 2684: задержка безопасности на некоторые подтверждения, например, установить, открыть/сохранить
user_pref("security.dialog_enable_delay", 1000); // [DEFAULT: 1000]
/*** [SECTION 5000]: PERSONAL
     Не связанные с проектом настройки, которые могут оказаться полезными. ***/
/* WELCOME & WHAT's NEW NOTICES ***/
user_pref("browser.startup.homepage_override.mstone", "ignore"); // master switch
user_pref("startup.homepage_welcome_url", "");
user_pref("startup.homepage_welcome_url.additional", "");
user_pref("startup.homepage_override_url", ""); // What's New page after updates
/* WARNINGS ***/
user_pref("browser.tabs.warnOnClose", false);
user_pref("browser.tabs.warnOnCloseOtherTabs", false);
user_pref("browser.tabs.warnOnOpen", false);
user_pref("full-screen-api.warning.delay", 0);
user_pref("full-screen-api.warning.timeout", 0);
/* UX FEATURES: отключить и скрыть значки и меню ***/
user_pref("browser.messaging-system.whatsNewPanel.enabled", false); // What's New toolbar icon [FF69+]
user_pref("extensions.pocket.enabled", false); // Pocket Account [FF46+]
user_pref("identity.fxaccounts.enabled", false); // Firefox Accounts & Sync [FF60+] [RESTART]
/* OTHER ***/
user_pref("browser.bookmarks.max_backups", 2);
user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.addons", false); // disable CFR [FF67+]
// [SETTING] General>Browsing>Recommend extensions as you browse
user_pref("browser.newtabpage.activity-stream.asrouter.userprefs.cfr.features", false); // disable CFR [FF67+]

/*************************  ДРУГОЕ ********************************************/

// Параметры до сих пор существуют, отключаем на всякий
user_pref("app.update.BITS.enabled", false);
user_pref("app.update.checkInstallTime", false);
user_pref("app.update.service.enabled", false);
user_pref("app.update.staging.enabled", false);

// Не проверять является ли Firefox браузером по умолчанию при первом запуске
user_pref("browser.shell.didSkipDefaultBrowserCheckOnFirstRun", true);

/*** Внешний вид и поведение ***/

// [FF68+] разрешить стили userChrome/userContent (APPEARANCE)
user_pref("toolkit.legacyUserProfileCustomizations.stylesheets", true);

// Домашняя страница
/* При вводе в строке поска не переключать фокус на адресную строку и
 * не дублировать поисковые предложения в ней ***/
user_pref("browser.newtabpage.activity-stream.improvesearch.handoffToAwesomebar", false);

// Темная тема на страницах about:xxxxxx
   // user_pref("browser.in-content.dark-mode", true); // Старое, но пока еще нужен для стилей от Aris-t2
   // user_pref("ui.systemUsesDarkTheme", 1); // [HIDDEN PREF]

// Инструменты разработчика
 // Темная тема
   // user_pref("devtools.theme", "dark");


// EME-free - косметика не для EMEfree, но с отключенным кодеком
user_pref("app.partner.mozilla-EMEfree", "mozilla-EMEfree");

// OpenH264 - переключить если НЕ пользуетесь кодеком OpenH264
user_pref("media.gmp-gmpopenh264.enabled", false);
/* Если переключить, то кодек вообще удалится из профиля и about:addons
 * При обратном включении зайдите в about:addons в плагины и обновите его
 * Firefox загрузит его за десяток секунд, размер кодека чуть меньше 1Мб ***/
user_pref("media.gmp-gmpopenh264.visible", false);

/* END: internal custom pref to test for syntax errors ***/
user_pref("_user.js.parrot", "УСПЕХ: user.js полностью загружен.");
