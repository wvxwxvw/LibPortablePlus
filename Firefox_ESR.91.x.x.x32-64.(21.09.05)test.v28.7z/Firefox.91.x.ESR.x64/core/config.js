// Для установки неподписанных расширений
// Код от Dumby https://forum.mozilla-russia.org/viewtopic.php?pid=780458#p780458
try {(nsvo => {
    var o = Cu.getGlobalForObject(nsvo).Object, {freeze} = o, NEW;
    o.freeze = obj => {
        if (Components.stack.caller.filename != "resource://gre/modules/AppConstants.jsm")
            return freeze(obj);
        obj.MOZ_REQUIRE_SIGNING = false;
        if ((NEW = "MOZ_ALLOW_ADDON_SIDELOAD" in obj))
            lockPref("extensions.experiments.enabled", true);
        else
            obj.MOZ_ALLOW_LEGACY_EXTENSIONS = true,
            lockPref("extensions.legacy.enabled", true);

        return (o.freeze = freeze)(obj);
    }
    lockPref("xpinstall.signatures.required", false);
    lockPref("extensions.langpacks.signatures.required", false);

    nsvo = Cu.import("resource://gre/modules/addons/XPIInstall.jsm", {});
    var shouldVerify = nsvo.shouldVerifySignedState;
    nsvo.shouldVerifySignedState = addon => !addon.id && shouldVerify(addon);

    if (NEW) nsvo.XPIDatabase.isDisabledLegacy = () => false;
})(
    "permitCPOWsInScope" in Cu
        ? Cu.import("resource://gre/modules/WebRequestCommon.jsm", {}) : Cu
);}
catch(ex) {Cu.reportError(ex);}

// Для user_chrome_files от VitaliyV 200925

try {(function() {
//  var {classes: Cc, interfaces: Ci, utils: Cu} = Components; // для FF < 60
    var sandbox = Cu.Sandbox(Cc["@mozilla.org/systemprincipal;1"].createInstance(Ci.nsIPrincipal), {
        wantComponents: true,
        sandboxName: "user_chrome_files"
    });
//  Object.assign(sandbox, {Cc, Ci, Cu}); // для FF < 60
    Cu.evalInSandbox(`
        try {
            Cu.importGlobalProperties(["ChromeUtils"]);
        } catch(ex) {
            if (!("ChromeUtils" in this))
                Object.defineProperty(this, "ChromeUtils", {
                    configurable: true,
                    enumerable: true,
                    value: {
                        import(module, scope = {}) {
                            return Cu.import(module, scope);
                        },
                    },
                    writable: true,
                });
        }
        var {Services} = ChromeUtils.import("resource://gre/modules/Services.jsm");
        var user_chrome_files_sandbox = {
            subScript: {},
            init() {
                Services.obs.addObserver(this, "domwindowopened", false);
                Services.obs.addObserver(this, "profile-after-change", false);
            },
            observe(aSubject, aTopic, aData) {
                ({
                    "domwindowopened": () => {
                        if (!(aSubject instanceof Ci.nsIDOMWindow)) return;
                        aSubject.addEventListener("DOMContentLoaded", () => {
                            var loc = aSubject.location;
                            if (loc && loc.protocol == "chrome:") {
                                try {
                                    this.subScript.user_chrome.loadIntoWindow(aSubject, loc.href);
                                } catch(ex) { }
                            }
                        }, { once: true, capture: true });
                    },
                    "profile-after-change": () => {
                        Services.obs.removeObserver(this, "profile-after-change");
                        var file = Services.dirsvc.get("UChrm", Ci.nsIFile);
                        file.append("user_chrome_files");
                        file.append("user_chrome.manifest");
                        if (!file.exists() || !file.isFile()) {
                            this.removeObs();
                            return;
                        }
                        try {
                            Components.manager.QueryInterface(Ci.nsIComponentRegistrar)
                            .autoRegister(file);
                        } catch(ex) {
                            this.removeObs();
                            return;
                        }

                        try {
                            Services.scriptloader.loadSubScript("chrome://user_chrome_files/content/user_chrome.js", this.subScript, "UTF-8");
                        } catch(ex) {
                            this.removeObs();
                        }
                    },
                })[aTopic]();
            },
            removeObs() {
                Services.obs.removeObserver(this, "domwindowopened");
            },
        };
        user_chrome_files_sandbox.init();
    `, sandbox);
})();} catch(ex) {
    if ("Cu" in globalThis)
        Cu.reportError(ex);
    else
        Components.utils.reportError(ex);
}

// lockPref("extensions.legacy.enabled", true);
// lockPref("xpinstall.signatures.required", false);
// lockPref("extensions.experiments.enabled", true);
// lockPref("extensions.langpacks.signatures.required", false);

// Загружать UCF скрипты в safe mode (режим с отключенными дополнениями)
// lockPref("extensions.user_chrome_files.custom_safemode", false);

// В about:addons, открывать всегда "расширения", вместо последней открытой категории
lockPref("extensions.ui.lastCategory", "addons://list/extension");

// Вернуть уведомление при сохранении закладки
lockPref("browser.bookmarks.editDialog.confirmationHintShowCount", 0);
