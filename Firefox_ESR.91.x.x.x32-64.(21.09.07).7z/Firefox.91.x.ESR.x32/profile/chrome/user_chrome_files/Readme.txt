
https://github.com/VitaliyVstyle/VitaliyVstyle.github.io/tree/master/stylesff/user_chrome_files

В папке custom_scripts находятся скрипты которые при необходимости можно подключить     
в настройках (кнопка «Открыть настройки» или about:user-chrome-files) и добавить свой код.    
В custom_script_win.js уже добавлены коды Special Widgets (интервылы и разделители) и Auto Hide Sidebar,     
их требуется раскомментировать как и в custom_style_user.css для активации.     
После редактирования перезапустить кнопкой «Перезагрузка - ПКМ: Перезапустить и заново создать кэш быстрой загрузки»,     
или в настройках нажмите «Перезапустить*»     

В папке custom_styles находятся custom_style_agent.css, custom_style_user.css и custom_style_author.css которые     
можно подключить в настройках и добавить свой код или импортировать другие файлы стилей через @import url("./myFile.css");     
Стили в основном лучше добавлять в custom_style_user.css, а те что не сработают в custom_style_agent.css     
например стиль для скроллбара или тултипов.     
