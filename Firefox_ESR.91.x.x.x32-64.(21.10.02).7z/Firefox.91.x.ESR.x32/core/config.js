// Для установки неподписанных расширений
// Код от Dumby https://forum.mozilla-russia.org/viewtopic.php?pid=780458#p780458
try {(nsvo => {
    var o = Cu.getGlobalForObject(nsvo).Object, {freeze} = o, NEW;
    o.freeze = obj => {
        if (Components.stack.caller.filename != "resource://gre/modules/AppConstants.jsm")
            return freeze(obj);
        obj.MOZ_REQUIRE_SIGNING = false;
        if ((NEW = "MOZ_ALLOW_ADDON_SIDELOAD" in obj))
            lockPref("extensions.experiments.enabled", true);
        else
            obj.MOZ_ALLOW_LEGACY_EXTENSIONS = true,
            lockPref("extensions.legacy.enabled", true);

        return (o.freeze = freeze)(obj);
    }
    lockPref("xpinstall.signatures.required", false);
    lockPref("extensions.langpacks.signatures.required", false);

    nsvo = Cu.import("resource://gre/modules/addons/XPIInstall.jsm", {});
    var shouldVerify = nsvo.shouldVerifySignedState;
    nsvo.shouldVerifySignedState = addon => !addon.id && shouldVerify(addon);

    if (NEW) nsvo.XPIDatabase.isDisabledLegacy = () => false;
})(
    "permitCPOWsInScope" in Cu
        ? Cu.import("resource://gre/modules/WebRequestCommon.jsm", {}) : Cu
);}
catch(ex) {Cu.reportError(ex);}

// Для user_chrome_files от VitaliyV 210928

(async () => {
    var sandbox = Cu.Sandbox(Cc["@mozilla.org/systemprincipal;1"].createInstance(Ci.nsIPrincipal), {
        wantComponents: true,
        sandboxName: "UserChromeFiles",
        wantGlobalProperties: ["ChromeUtils"],
    });
    Cu.evalInSandbox(`
        var { Services } = ChromeUtils.import("resource://gre/modules/Services.jsm");
        var user_chrome_files_sandbox = {
            init() {
                Services.obs.addObserver(this, "domwindowopened");
                Services.obs.addObserver(this, "profile-after-change");
            },
            observe(aWindow, aTopic, aData) {
                Services.obs.removeObserver(this, "profile-after-change");
                this.observe = (window, topic, data) => {
                    if (!(window instanceof Ci.nsIDOMChromeWindow)) return;
                    var docElementInserted = e => {
                        var win = e.target.defaultView;
                        if (win instanceof Ci.nsIDOMChromeWindow)
                            user_chrome.initWindow(win);
                    };
                    window.windowRoot.addEventListener("DOMDocElementInserted", docElementInserted, true);
                    window.addEventListener("load", e => {
                        window.addEventListener("unload", e => {
                            window.windowRoot.removeEventListener("DOMDocElementInserted", docElementInserted, true);
                        }, { once: true });
                    }, { once: true });
                };
                var file = Services.dirsvc.get("UChrm", Ci.nsIFile);
                file.append("user_chrome_files");
                file.append("user_chrome.manifest");
                if (!file.exists() || !file.isFile()) {
                    this.removeObs();
                    return;
                }
                try {
                    Components.manager.QueryInterface(Ci.nsIComponentRegistrar)
                    .autoRegister(file);

                    Services.scriptloader.loadSubScript("chrome://user_chrome_files/content/user_chrome.js", globalThis, "UTF-8");
                } catch(ex) {
                    this.removeObs();
                    return;
                }
                if (aTopic === "domwindowopened")
                    this.observe(aWindow, aTopic, aData);
            },
            removeObs() {
                Services.obs.removeObserver(this, "domwindowopened");
            },
        };
        user_chrome_files_sandbox.init();
    `, sandbox);
})();

// lockPref("xpinstall.signatures.required", false);
// lockPref("extensions.experiments.enabled", true);
// lockPref("extensions.langpacks.signatures.required", false);

// Загружать UCF скрипты в safe mode (режим с отключенными дополнениями)
// lockPref("extensions.user_chrome_files.custom_safemode", false);

// В about:addons, открывать всегда "расширения", вместо последней открытой категории
lockPref("extensions.ui.lastCategory", "addons://list/extension");

// Вернуть уведомление при сохранении закладки
lockPref("browser.bookmarks.editDialog.confirmationHintShowCount", 0);
