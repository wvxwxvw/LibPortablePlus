  
[VitaliyVstyle.github.io](https://github.com/VitaliyVstyle/VitaliyVstyle.github.io/tree/master/stylesff/user_chrome_files)
  
#### Описание:  
UserChromeFiles - это файлы JavaScript и CSS в профиле, и директории установки Firefox.  
Этот метод основан на функции autoconfig доступной в Firefox.  
  
Добавляет:  
	Дополнительную панель  
	Вертикальную панель  
	Нижнюю панель  
	Некоторые служебные кнопки на панели  
	Special Widgets (интервылы и разделители)  
	Auto Hide Sidebar  
	В настройках UserChromeFiles (кнопка «Открыть настройки» или about:user-chrome-files)  
	можно настроить параметры панелей или отключить их  
  
UserChromeFiles можно использовать как загрузчик скриптов и стилей.  
В папке custom_scripts находятся файлы JavaScript которые можно подключить и/или добавить другие.  
Для детальной настройки смотрите файлы CustomStylesScripts.jsm и CustomStylesScriptsChild.jsm.  
Все доп. стили и скрипты подключаются в этих двух файлах, а также в интефейсе настроек UserChromeFiles.  
  
После редактирования скриптов необходимо перезапустить браузер очистив кэш запуска Firefox, например:  
	кнопкой «Перезагрузка» - «ПКМ: Перезапустить и заново создать кэш быстрого запуска»,  
	или в настройках UserChromeFiles нажмите «Перезапустить *»,  
	или это можно сделать в about:support.  
  
Cкрипты для UserChromeFiles можно найти на форуме [mozilla-russia.org](https://forum.mozilla-russia.org/viewtopic.php?pid=792702#p792702)  
Папка custom_styles используется для различных файлов CSS, которые подключаются там же где и скрипты  
в CustomStylesScripts.jsm и CustomStylesScriptsChild.jsm ...  
  