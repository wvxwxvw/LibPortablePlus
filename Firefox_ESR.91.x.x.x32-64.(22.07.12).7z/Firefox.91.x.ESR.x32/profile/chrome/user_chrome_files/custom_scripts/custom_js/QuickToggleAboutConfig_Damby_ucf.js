// Этот скрипт можно использовать для создания кнопок с помощью CustomizableUI.createWidget

// Quick Toggle от Damby - Быстрое переключение параметров about:config

(async (name, id, func) => {
	if (name == "Object") return CustomizableUI.createWidget(func());
	var win = name == "Window", g = Components.utils.import("resource://gre/modules/Services.jsm", {});
	if (g[id]) {if (win) return;} else g[id] = func();
	if (win) return CustomizableUI.createWidget(g[id]);
	addDestructor(r => r[5] == "e" && delete g[id]);
	g[id].onCreated(this);
})(this.constructor.name, "QuickToggleAboutConfigSettings", () => {

	var {prefs} = Services, db = prefs.getDefaultBranch("");
	var pv = parseInt(Services.appinfo.platformVersion);
	var xul_ns = "http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul";

//=============================================================================

	// ЛКМ по пункту - переключает параметр на userChoice
	// или между userChoice и userAlt (если второй есть)
	//
	// Ctrl+ЛКМ или ПКМ по пункту - сброс параметра по-умолчанию FF
	// или его удаление, если параметр добавлен польз-лем\расширением\скриптом
	//
	// Первый символ в названии
	//	! Может сломать что-то на сайтах (см. user.js - 2300, 5504, 5506)
	//	^ Связанный с предыдущим
	//	? Вроде должно быть взаимное влияние статусов FPI <> TCP, но его нет
	//
	// Следующий символ после длинного дефиса, в названии:
	//	"молния"			- перезагрузка,
	//	"песочные часы"		- обновление страницы,
	//	"короткий дефис"	- отсутствие действия
	//
	// userChoice:
	//	ваше значение (зеленая метка)
	//
	// userAlt:
	//	альтернативное ваше значение (желтая метка)
	//
	// Иконки назначаются в 453-455 строках
	//
	// refresh:
	//	false	- перезагрука текущей вкладки
	//	true	- перезагрука текущей вкладки минуя кэш
	//
	// restart:
	//	false	- перезапуск браузера
	//	true	- перезапуск браузера с подтверждением (отмена - отменяет только
	//	перезапуск браузера, преф переключится, но может не применится)
	//
	// Корректность необходимости перезапуска браузера уточнена не для всех
	// параметров.

	// Структуру заполнения смотрите в примерах.
	// Третий блок в значениях - это памятка в подменю, он не обязателен, тем
	// более что значение есть в подсказке (тултипе).
	//
	// Остальное сами...

	var primary = [{

			pref: ["network.proxy.type", "Настройки прокси"],
			userChoice: 5, userAlt: 0, refresh: true,
			values: [
				[0, "Не проксировать", "0"],
				[5, "Системные (IE)", "5"],
				[2, "Авто (proxi.pac)", "2"],
				[1, "Прописанные", "1"],
				[4, "Автоопределение", "4"]
	]},
			null,
	{
			pref: ["browser.zoom.full", "Масштабировать"],
			userChoice: false, userAlt: true, refresh: true,
			values: [[true, "Весь контент"], [false, "Только текст"]]
	},
			null,
	{
			pref: ["permissions.default.image", "Загружать web-графику"],
			userChoice: 1, userAlt: 2, refresh: true,
			values: [
				[1, "Да", "1"],
				[3, "С сайта", "3"],
				[2, "Нет", "2"]
	]},
			null,
	{
			pref: ["intl.accept_languages", "Язык для веб-страниц"],
			userChoice: "en-US, en", userAlt: "ru-RU, ru, en-US, en", refresh: true,
			values: [
				["en-US, en", "EN"],
				["en-US, en, ru-RU, ru", "EN, RU"],
        ["ru-RU, ru, en-US, en", "RU, EN"]
	]},{
			pref: ["javascript.use_us_english_locale", "Язык для javascript (глобально)"],
			userChoice: true, restart: true,
			values: [[true, "en-US"]]
	},{
			pref: ["browser.search.region", "Регион поиска"],
			userChoice: "US", restart: true,
			values: [["US", "US"], ["RU", "RU"]]
	},{
			pref: ["geo.enabled", "Геолокация"],
			userChoice: false, userAlt: true, restart: true,
			values: [[true, "Да"], [false, "Нет"]]
	},
			null,
	{
			pref: ["security.mixed_content.block_active_content", "Активный смешанный контент"],
			userChoice: true, userAlt: false, refresh: true,
			values: [[true, "Нет"], [false, "Да"]]
	},{
			pref: ["security.ssl.require_safe_negotiation", "! Безопасный SSL"],
			userChoice: true, restart: true,
			values: [[true, "Да"], [false, "Нет"]]
	},{
			pref: ["network.http.referer.XOriginPolicy", "! XO Referer - когда"],
			userChoice: 1, userAlt: 2, refresh: true,
			values: [
				[0, "Всегда", "0"],
				[1, "При совп. домена", "1"],
				[2, "При совп. хоста", "2"]
	]},{
			pref: ["network.http.referer.XOriginTrimmingPolicy", "! XO Referer - какой"],
			userChoice: 2, userAlt: 1, refresh: true,
			values: [
				[0, "Полный URL", "0"],
				[2, "scheme+host+port", "2"],
				[1, "scheme+host+port+path", "1"]
	]},
			null,
	{
			pref: ["privacy.firstparty.isolate", "(FPI) First Party Isolation"],
			userChoice: true, userAlt: false, refresh: true,
			values: [[true, "Да"], [false, "Нет"]]
	},{
			pref: ["privacy.firstparty.isolate.restrict_opener_access", "^ Огр. FPI для window.opener"],
			userChoice: false, userAlt: true, refresh: true,
			values: [[true, "Да"], [false, "Нет"]]
	},{
			pref: ["privacy.partition.network_state", "(TCP) Total Cookie Protection"],
			userChoice: true, userAlt: false, refresh: true,
			values: [[true, "Да"], [false, "Нет"]]
	},
			null,
	{
			pref: ["browser.contentblocking.category", "Схема защиты"],
			userChoice: "custom", userAlt: "strict", refresh: true,
			values: [
				["custom", "Персональная"],
				["standard", "Стандартная"],
				["strict", "Строгая"]
	]},{
			pref: ["network.cookie.cookieBehavior", "Cookies"],
			userChoice: 1, userAlt: 5, refresh: true,
			values: [
				[1, "Блокир. все сторонние"],
				[3, "Блокир. с не посещенных"],
				[4, "Блокир. межсайтовые трекеры"],
				[5, "Блок. трекеры + изоляция (TCP)"],
				[2, "Блокировать все куки"],
				[0, "Принимать все куки"]
	]},
			null,
	{
			pref: ["network.cookie.lifetimePolicy", "Хранить cookies"],
			userChoice: 0, userAlt: 2,
			values: [[2, "До закрытия Fx"], [0, "До срока годности"]]
	},{
			pref: ["browser.sessionstore.privacy_level", "Сохр. доп. данные в сессиях"],
			userChoice: 2, userAlt: 0,
			values: [[2, "Нет"], [0, "Да"], [1, "На http сайтах"]]
	},
			null,
	{
			pref: ["privacy.sanitize.sanitizeOnShutdown", "Очистка при закрытии"],
			userChoice: true, userAlt: false,
			values: [[true, "Включена"], [false, "Отключена"]]
	},{
			pref: ["browser.startup.page", "При запуске открывать"],
			userChoice: 1, userAlt: 3,
			values: [
				[1, "Домашняя", "1"],
				[3, "Последние", "3"],
				[2, "Посещенные", "2"],
				[0, "Пустая", "0"]
	]}
];

//=============================================================================

	var secondary = [{
			pref: ["network.trr.uri", "DoH DNS провайдер"],
			userChoice: "https://firefox.dns.nextdns.io/",
			userAlt: "https://dns.google/dns-query",
			refresh: true,
			values: [
				["https://mozilla.cloudflare-dns.com/dns-query", "Cloudflare"],
				["https://dns.comss.one/dns-query", "Comss DNS"],
				["https://dns.google/dns-query", "Google DNS"],
				["https://firefox.dns.nextdns.io/", "NextDNS"]
	]},{
			pref: ["network.trr.mode", "DoH DNS (режим trr)"],
			userChoice: 3, userAlt: 0, refresh: true,
			values: [
				[3, "Строгий"],
				[2, "DoH первым"],
				[5, "Явно отключен"],
				[0, "Отключен"]
	]},{
			pref: ["network.trr.exclude-etc-hosts", "DoH учитывает HOSTS"],
			userChoice: true, userAlt: false, restart: true,
			values: [[true, "Да"], [false, "Нет"]]
	},
			null,
	{
		pref: ["dom.serviceWorkers.enabled", "! ServiceWorkers"],
			userChoice: false, userAlt: true, restart: true,
			values: [[true, "Да"], [false, "Нет"]]
	},{
			pref: ["dom.caches.enabled", "^ SW кэш и storage"],
			userChoice: false, userAlt: true,
			values: [[true, "Включен"], [false, "Отключен"]]
	},{
			pref: ["dom.push.enabled", "^ SW уведомления"],
			userChoice: false, userAlt: true,
			values: [[true, "Включен"], [false, "Отключен"]]
	},
			null,
	{
			pref: ["javascript.options.asmjs", "! ASM.JS уязвимость"],
			userChoice: false, userAlt: true, refresh: true,
			values: [[true, "Да"], [false, "Нет"]]
	},{
			pref: ["javascript.options.wasm", "! WebAssembly"],
			userChoice: false, userAlt: true, refresh: true,
			values: [[true, "Да"], [false, "Нет"]]
	},
			null,
	{
			pref: ["browser.display.use_document_fonts", "Загружать web-шрифты"],
			userChoice: 1, refresh: true,
			values: [[1, "Да"], [0, "Нет"]]
	},{
			pref: ["layout.css.font-visibility.level", "Видимость лок.шрифтов"],
			userChoice: 1, refresh: true,
			values: [
				[1, "Базовые"],
				[2, "+доп.яз.пак."],
				[3, "+уст.польз."],
	]},{
			pref: ["browser.display.document_color_use", "Загружать цвета сайтов"],
			userChoice: 0, refresh: true,
			values: [
				[0, "Авто", "0"],
				[1, "Всегда", "1"],
				[2, "Никогда", "2"]
	]},
			null,
	{
			pref: ["ui.prefersReducedMotion", "Анимация chrome"],
			userChoice: 1, userAlt: 0,
			values: [[1, "Отключена"], [0, "Включена"]]
	},{
			pref: ["gfx.webrender.enabled", "! Web render"],
			userChoice: false, userAlt: true, refresh: true,
			values: [[true, "Включен"], [false, "Отключен"]]
	},{
			pref: ["gfx.webrender.force-disabled", "^ Web render (force-disabled)"],
			userChoice: true, userAlt: false, refresh: true,
			values: [[true, "Да"], [false, "Нет"]]
	},{
			pref: ["gfx.webrender.software", "^ Web render (bug for W7)"],
			userChoice: false, userAlt: true, restart: true,
			values: [[true, "Включен"], [false, "Отключен"]]
	},
			null,
	{
			pref: ["media.autoplay.default", "Автозапуск медиа"],
			userChoice: 5, refresh: true,
			values: [
				[5, "Блокировать", "5"],
				[1, "Блок. аудио", "1"],
				[0, "Разрешить", "0"]
	]},{
			pref: ["media.autoplay.blocking_policy", "Автозапуск (политика)"],
			userChoice: 1, userAlt: 2, refresh: true,
			values: [
				[1, "Временная", "1"],
				[2, "Действие?", "2"],
				[0, "Постоянная", "0"]
	]},{
			pref: ["media.webm.enabled", "WebM (видео >1080p)"],
			userChoice: false, userAlt: true, restart: true,
			values: [[true, "Включен"], [false, "Отключен"]]
	},
			null,
	{
			pref: ["dom.disable_open_during_load", "Блокировать всплывающие окна"],
			userChoice: true, userAlt: false, refresh: true,
			values: [[true, "Да"], [false, "Нет"]]
	},{
			pref: ["dom.popup_allowed_events", "Триггеры всплывающих окон"],
			userChoice: "click dblclick mousedown pointerdown", refresh: true,
			values: [["click dblclick mousedown pointerdown", "Свои"]]
	}
	];

	return {
		id: "QuickToggleAboutConfigSettings",
		label: "Quick Toggle Settings",
		tooltiptext: "Quick Toggle Settings\n\nДва меню - вызываются по ЛКМ и ПКМ\n\nЛКМ по пункту:\nпереключает параметр на userChoice или между\nuserChoice и userAlt (если последний назначен)\n\nПКМ по пункту:\nсброс параметра к значению по умолчанию Fx,\nили его удаление, если параметр добавленный\n\nСимвол после длинного дефиса - индикатор:\n	 '↯' - перезагрузка\n	 '⧖' - обновление страницы\n	 '-' - отсутствие действия\n\nПодробнее в файле скрипта.",
		localized: false,
		image: "chrome://user_chrome_files/content/custom_styles/svg/QuickToggle.svg",
		onCreated(btn) {
			btn.setAttribute("image", this.image);
			var doc = btn.ownerDocument;

			btn.btn = true;
			btn.domParent = null;
			btn.popups = new btn.ownerGlobal.Array();
			this.createPopup(doc, btn, "primary", primary);
			this.createPopup(doc, btn, "secondary", secondary);
			this.createCloseMenusOption(doc, btn);

			btn.linkedObject = this;
			for(var type of ["command", "contextmenu"])
				btn.setAttribute("on" + type, `linkedObject.${type}(event)`);
		},
		createPopup(doc, btn, name, data) {
			var popup = doc.createElementNS(xul_ns, "menupopup");
			var prop = name + "Popup";
			btn.popups.push(btn[prop] = popup);
			popup.id = this.id + "-" + prop;
			for (var type of ["popupshowing", "click"])
				popup.setAttribute("on" + type, `parentNode.linkedObject.${type}(event)`);
			for(var obj of data) popup.append(this.createElement(doc, obj));
			btn.append(popup);
		},
		map: {b: "Bool", n: "Int", s: "String"},
		createElement(doc, obj) {
			if (!obj) return doc.createElementNS(xul_ns, "menuseparator");
			var pref = doc.ownerGlobal.Object.create(null), node, img, bool;
			for(var [key, val] of Object.entries(obj)) {
				if (key == "pref") {
					var [apref, lab, akey, ttt] = val;
					pref.pref = apref; pref.lab = lab || apref;
					if (ttt) pref.ttt = ttt;
				}
				else if (key == "image") img = val, pref.img = true;
				else if (key != "values") pref[key] = val;
				else pref.hasVals = true;
			}
			var type = prefs.getPrefType(pref.pref);
			var str = this.map[type == prefs.PREF_INVALID
				? obj.values ? (typeof obj.values[0][0])[0] : "b"
				: type == prefs.PREF_BOOL ? "b" : type == prefs.PREF_INT ? "n" : "s"
			];
			pref.get = prefs[`get${str}Pref`];
			pref.set = prefs[`set${str}Pref`];

			node = doc.createElementNS(xul_ns, "menu");
			node.className = "menu-iconic";
			node.setAttribute("closemenu", "none");
			img && node.setAttribute("image", img);
			akey && node.setAttribute("accesskey", akey);
			(node.pref = pref).vals = doc.ownerGlobal.Object.create(null);
			this.createRadios(doc,
				str.startsWith("B") && !pref.hasVals ? [[true, "true"], [false, "false"]] : obj.values,
				node.appendChild(doc.createElementNS(xul_ns, "menupopup"))
			);
			if ("userChoice" in obj) pref.noAlt = !("userAlt" in obj);
			return node;
		},
		createCloseMenusOption(doc, btn) {
			var pn = this.closePref = "QuickToggleAboutConfigSettings.closeMenus";
			var data = [null, {
				pref: [pn, "Автозакрытие этого меню"], values: [[true, "Да"], [false, "Нет"]]
			}];
			var setCloseMenus = e => {
				e.stopPropagation();
				var trg = e.target, {pref, val} = trg, updPopup = true, clear;
				switch(e.type) {
					case "command": pref = (trg = trg.closest("menu")).pref; updPopup = false; break;
					case "click": if (e.button) return; break;
					case "contextmenu": e.preventDefault(); clear = pref;
				}
				if (!pref) return;
				if (clear) prefs.clearUserPref(pn);
				else if (!updPopup && val === pref.val) return;
				else pref.set(pn, val !== undefined ? val : !pref.val);
				this.upd(trg);
				updPopup && this.popupshowing(null, trg.querySelector("menupopup"));
			}
			(this.createCloseMenusOption = (doc, btn) => {
				for(var obj of data)
					btn.secondaryPopup.append(this.createElement(doc, obj));
				var m = btn.secondaryPopup.lastChild;
				m.style.cssText = "fill: lightblue !important; list-style-image: url(chrome://browser/skin/menu.svg) !important;";
				m.setAttribute("oncommand", "setCloseMenus(event)");
				m.onclick = m.oncontextmenu = m.setCloseMenus = setCloseMenus;
			})(doc, btn);
		},
		UserChoiceImg: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAHqSURBVDhPpVJBTxNBGH1LLakxVEJQQIkhlZCAJDYR/BGScNCDwZMcuEji2ZP+BD14MCGciDEaEw8e1At3QGLlwAUOFtm6tut2uwtb2t3p8GbZ0iXlVF/y5ttkv+/Nmzej5XI5/A+6otoxTh1ks9mwhniJHvRiBAHXLjRIEy7yeIqjqAPNuXYHS5jGVby7PTT27eHo7Or9zL3Va/19Xyj5FsuYjLpOcdbBG9xFGh+fZRaGJ5O3tB7tMrcXcGQZP+pb8tXuyjpdPcA89HYHynYazxdvzg5nkgOapFsPNleXP+uY6L6hzYxMT+EC5vCVa4SWAM880Ju4cyVxUXNkERUeuyJLIR1+O6wTqcEEUngEA5eiqZgAAxtMpfur0sIBLA7+hS2NkK5UGVpsqgEJjLMkT4biAkzbE27D5u7/ZAFWSB1l0iRtUokyEj+aCBEXMHcOA70Y/IElfsMUeyiJPIpBHiZZEvv4Vcsrge9Mi1ZO0BJQ98yw9w4tWT4yYNV1ki78AuyggHLNwLZjC1Txnpl60VRMQD2SBl5sGsHaT88XJd+DEzioCAd6rYpN1xf7Jj5T4BMe00eE9pf4GteZ8Ry6mbYKDDyzxAblP4TDT1BUbc2585+yumd1Vc201ZmV7djObQKdopVBRwCOAVyl9qcQtNEaAAAAAElFTkSuQmCC",
		notUserChoiceImg: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAHqSURBVDhPpVJNSxtRFD1PJ9GMMVpaKyWhRGwRFy7Utv+gVFyUgoWif8Ct+APMsvQX+BuUWhdBcOvSDwi1XVhK0WgmTr4mmphoJvPRe5NnxhLdpAcO9828d869794nXNfF/6BLxo7RqiAcDjciYx3oDwFRBxikT4ey5CtAcg64aZ4ANE1rxDaDLeB176Aae/zx/ZR/NDqEuu1UD39oxsZ2wnIRmwV+8rl7DeLAGzXg+/pidSWivBwVCPQDvH91AfPot/tn6fOedW3NzTT0TYNWD7hsVfWtjH1ZjCjPggImFV25AKpE+xr+6CMxsvzpVXePmE8AipR5Bnzn4bcT0yJoCZSyQDkPXOrEDDHXYG8k0B18/nSBdvukzDPghqlB/xOUi4BBgiIJDUleF0lmVaEo7ngd8EnZP2N0uiolBwXKmksDegrISubovvyPWauR3kPLgBb5q+O8hnMyOD8jJoknTaZPKZLRSQp2+eaA6q9JmWcwTHPWv2cT0E0XGcqos4lkhgz4X7Jql3O1NZNaK2WewSQ9EtqIHcWPd5FybWQNoECNNApkdgmcwv61k47TbDbf0VykrP0hfaPlADAfCmFBERiHQN2sY79UwTqLP1BX+NyDL5HBc+ZR3Xab78xl383cZtAp7o6xAwB/AT+Y7GFJS/NjAAAAAElFTkSuQmCC",
		UserAltImg: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAH7SURBVDhPpVJLa1NBFP5mJolNcrWhtiq9Betjk0VFfNS1O7ciXbQguBDXxR9g3Lnown8g3SqCi24K/gCxVbqogiBaxdyY5nFrkt5H5j7GmZvxphDdxA8+Dgzn+86Zcw4RQuB/QHUcG2kHpmkmUWHtEo6DY55mUCIhYkHQOlXA97vv4esUWJaVxBGDp2Vcz54klakbN69kZ8wZRHHsVT9b7e2tHdFH5eEuPqi8vxqsLWDxmIGX5+8/mMufPkdA8zIBiMMuvNo3sbf+bCt2cWd1V+kHBukMVNuFE3h08d7SXHF6glC4oHFXGnTBmA9j1iBnb9+6xvJYfryIjJYdGaL889TlC1cLkyFhQQek3wThjYSUt8GCX9Iky/JniitGF0WtGhpQgdLEJJvO8AMpUgIbtK/JbflmI0cc2Y0oy/JZLRsaEIKYcCemXgvUlVXdOpj/c0Bnf0BXdhXxQEsSpAZqVU7NtkRPJh5aoAmrCYnzA9SpIbDr4G74Lsihr2VDA7Xn5kdvx2mGgnr7soNaSubXQb0GelUv8lt4Pj8rJ6yRGqgjERyVT68P3rarJIo6HojrJOS2h8Yejb6+OdyIe3i1tIlIy0YP6ckCTCOH5WIJKxmGsnwKeB/bbgcvlHj1Cxoq75+XqKD2rFb1Z9rqz6rto5VHDMZFOoPxAPwGQ077rbKVfhEAAAAASUVORK5CYII=",
		upd(node) {
			var {pref} = node, def = false, user = false, val;
			if (prefs.getPrefType(pref.pref) != prefs.PREF_INVALID) {
				var pn = pref.pref;
				try {val = pref.defVal = db[pref.get.name](pn); def = true}
				catch(ex) {def = false;}
				var user = prefs.prefHasUserValue(pn);
				if (user) try {val = pref.get(pn, undefined);} catch(ex) {}
			}
			if (val == pref.val && def == pref.def && user == pref.user) return;
			pref.val = val; pref.def = def; pref.user = user;
			var exists = def || user;

			var ttt = exists ? val : "Этот преф не существует";
			if (ttt === "") ttt = "[ empty_string ]";
			ttt += "\n" + pref.pref;
			if (pref.ttt) ttt += "\n" + pref.ttt;
			node.tooltipText = ttt;

			var img, alt = "userAlt" in pref && val == pref.userAlt;
			if (alt) img = this.UserAltImg;
			if ("userChoice" in pref)
				if (val == pref.userChoice)
					//node.style.removeProperty("color"),
					img = this.UserChoiceImg;
				else {
					//node.style.setProperty("color", "maroon", "important");
					if (!alt) img = this.notUserChoiceImg;
				}
			if (!pref.img) img
				? node.setAttribute("image", img)
				: node.removeAttribute("image");
			user
				? node.style.setProperty("font-style", "italic", "important")
				: node.style.removeProperty("font-style");

			var {lab} = pref;
			if (exists && pref.hasVals) {
				if (val in pref.vals) var sfx = pref.vals[val] || val;
				else var sfx = user ? "Другое" : "По умолчанию";
				lab += ` ${"restart" in pref ? "— ↯" : "refresh" in pref ? "— ⧖" : "— -"} "${sfx}"`;
			}
			node.setAttribute("label", lab);
		},
		createRadios(doc, vals, popup) {
			for(var arr of vals) {
				if (!arr) {
					popup.append(doc.createElementNS(xul_ns, "menuseparator"));
					continue;
				}
				var [val, lab, key, ttt] = arr;
				var menuitem = doc.createElementNS(xul_ns, "menuitem");
				menuitem.setAttribute("type", "radio");
				menuitem.setAttribute("closemenu", "none");
				menuitem.style.setProperty("font-style", "italic", "important"),
				menuitem.setAttribute("label", popup.parentNode.pref.vals[val] = lab);
				key && menuitem.setAttribute("accesskey", key);
				var tip = menuitem.val = val;
				if (ttt) tip += "\n" + ttt;
				menuitem.tooltipText = tip;
				popup.append(menuitem);
			}
		},
		openPopup(popup) {
			var btn = popup.parentNode;
			if (btn.domParent != btn.parentNode) {
				btn.domParent = btn.parentNode;
				var pos;
				if (btn.matches(".widget-overflow-list > :scope"))
					pos = "after_start";
				else var win = btn.ownerGlobal, {width, height, top, bottom, left, right} =
					btn.closest("toolbar").getBoundingClientRect(), pos = width > height
						? `${win.innerHeight - bottom > top ? "after" : "before"}_start`
						: `${win.innerWidth - right > left ? "end" : "start"}_before`;
				for(var p of btn.popups) p.setAttribute("position", pos);
			}
			popup.openPopup(btn);
		},
 		maybeRestart(node, conf) {
			if (conf && !Services.prompt.confirm(null, this.label, "Перезапустить браузер?")) return;

			var cancel = Cc["@mozilla.org/supports-PRBool;1"].createInstance(Ci.nsISupportsPRBool);
			Services.obs.notifyObservers(cancel, "quit-application-requested", "restart");
			return cancel.data ? Services.prompt.alert(null, this.label, "Запрос на выход отменен.") : this.restart();
		},
		async restart() {
			var meth = Services.appinfo.inSafeMode ? "restartInSafeMode" : "quit";
			Services.startup[meth](Ci.nsIAppStartup.eAttemptQuit | Ci.nsIAppStartup.eRestart);
		},
		regexpRefresh: /^(?:view-source:)?(?:https?|ftp)/,
		maybeRe(node, fe) {
			var {pref} = node;
			if ("restart" in pref) {
				if (this.maybeRestart(node, pref.restart)) return;
			}
			else this.popupshowing(fe, node.parentNode);
			if ("refresh" in pref) {
				var win = node.ownerGlobal;
				if (this.regexpRefresh.test(win.gBrowser.currentURI.spec)) pref.refresh
					? win.BrowserReloadSkipCache() : win.BrowserReload();
			}
		},
		maybeClosePopup(e, trg) {
			!e.ctrlKey && prefs.getBoolPref(this.closePref, undefined)
				&& trg.parentNode.hidePopup();
		},
		command(e) {
			var trg = e.target;
			if (trg.btn) return this.openPopup(trg.primaryPopup);

			var menu = trg.closest("menu"), newVal = trg.val;
			this.maybeClosePopup(e, menu);
			if (newVal != menu.pref.val)
				menu.pref.set(menu.pref.pref, newVal),
				this.maybeRe(menu, true);
		},
		popupshowing(e, trg = e.target) {
			if (trg.state == "closed") return;
			if (trg.id) {
				for(var node of trg.children) {
					if (node.nodeName.endsWith("r")) continue;
					this.upd(node);
					!e && node.open && this.popupshowing(null, node.querySelector("menupopup"));
				}
				return;
			}
			var {pref} = trg.closest("menu"), findChecked = true;

			var findDef = "defVal" in pref;
			var checked = trg.querySelector("[checked]");
			if (checked) {
				if (checked.val == pref.val) {
					if (findDef) findChecked = false;
					else return;
				}
				else checked.removeAttribute("checked");
			}
			if (findDef) {
				var def = trg.querySelector("menuitem:not([style*=font-style]");
				if (def)
					if (def.val == pref.defVal) {
						if (findChecked) findDef = false;
						else return;
					}
					else def.style.setProperty("font-style", "italic", "important");
			}
			for(var node of trg.children) if ("val" in node) {
				if (findChecked && node.val == pref.val) {
					node.setAttribute("checked", true);
					if (findDef) findChecked = false;
					else break;
				}
				if (findDef && node.val == pref.defVal) {
					node.style.removeProperty("font-style");
					if (findChecked) findDef = false;
					else break;
				}
			}
		},
		contextmenu(e) {
			var trg = e.target;
			if (trg.btn) {
				if (e.ctrlKey || e.shiftKey) return;
				if (e.detail == 2) return trg.secondaryPopup.hidePopup();
				this.openPopup(trg.secondaryPopup);
			}
			else if ("pref" in trg) {
				this.maybeClosePopup(e, trg);
				if (trg.pref.user)
					prefs.clearUserPref(trg.pref.pref),
					this.maybeRe(trg);
			}
			e.preventDefault();
		},
		click(e) {
			if (e.button) return;
			var trg = e.target, {pref} = trg;
			if (!pref) return;

			this.maybeClosePopup(e, trg);
			if (!("noAlt" in pref)) return;

			if (pref.val == pref.userChoice)
				if (pref.noAlt) return;
				else  pref.set(pref.pref, pref.userAlt);
			else
				pref.set(pref.pref, pref.userChoice);
			this.maybeRe(trg);
		}
	};
// Скрипт подготовлен специально для сборки Firefox 91 ESR
// https://github.com/wvxwxvw/LibPortablePlus
// wvxwxvw 220622
});