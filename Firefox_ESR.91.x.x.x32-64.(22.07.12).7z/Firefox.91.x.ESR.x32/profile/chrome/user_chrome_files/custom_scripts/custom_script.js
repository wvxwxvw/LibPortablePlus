// Этот скрипт можно использовать например для создания кнопок с помощью CustomizableUI.createWidget

(() => {
    var loadscript = relpath => {
        try {
            Services.scriptloader.loadSubScript(`chrome://user_chrome_files/content/custom_scripts/${relpath}`, globalThis, "UTF-8");
        } catch(e) {}
    };
    // loadscript("custom_js/Mem_Indicator_ucf.js");
    // loadscript("custom_js/ShowBookmarkFolder_ucf.js");
    // и т.д.
})();
